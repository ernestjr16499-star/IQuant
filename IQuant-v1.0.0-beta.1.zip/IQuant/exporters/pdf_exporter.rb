﻿# encoding: UTF-8

begin
  require 'prawn'
  require 'prawn/table'
rescue LoadError
  # Si no está instalada, log y fallback (pero como es opcional, el plugin maneja en html_generator)
end

module IQuant
  module Exporters
    module PdfExporter
      extend self
      
      # ==========================================================================
      # CONFIGURACIÓN DE EXPORTACIÓN PDF
      # ==========================================================================
      
      PDF_OPTIONS = {
        page_size: 'A4',
        page_layout: :portrait,
        margin: [40, 40, 40, 40],
        optimize_objects: true
      }.freeze
      
      FONTS = {
        normal: 'Helvetica',
        bold: 'Helvetica-Bold',
        size_header: 18,
        size_title: 14,
        size_normal: 10,
        size_small: 8
      }.freeze
      
      COLORS = {
        header_bg: [240, 240, 240],
        table_header: [200, 200, 200],
        text: [0, 0, 0],
        accent: [0, 0, 255],
        watermark: [200, 200, 200, 50]  # Con transparencia
      }.freeze
      
      # ==========================================================================
      # VERIFICACIÓN DE PRAWN
      # ==========================================================================
      
      ##
      # Verifica si la gema Prawn está disponible
      #
      def self.prawn_available?
        defined?(Prawn) && defined?(Prawn::Document)
      end
      
      # ==========================================================================
      # EXPORTACIÓN PRINCIPAL
      # ==========================================================================
      
      ##
      # Exporta los datos a PDF
      #
      # @param data [Hash] Datos de la selección (de Calculator.get_selection_stats)
      # @param path [String, nil] Ruta del archivo (si nil, retorna binstring)
      # @return [String, Boolean] Binstring PDF si no path, o true si guardado
      #
      def export(data, path = nil)
        safe_execute('Exportar a PDF') do
          # Verificar si Prawn está disponible
          unless prawn_available?
            UI.messagebox("Para exportar PDF necesitas instalar la gema Prawn.\nAbre Terminal y ejecuta: gem install prawn prawn-table", MB_OK, "Gema faltante") if defined?(UI)
            return false
          end
          
          # Verificar licencia antes de exportar
          if defined?(IQuant::Features::Licensing) && !IQuant::Features::Licensing.can_export?
            IQuant::Utils::Logger.log("No se puede exportar: límite de exportaciones alcanzado o licencia expirada", :warn) if defined?(IQuant::Utils::Logger)
            
            if defined?(UI) && defined?(IQuant::Data::Localization)
              UI.messagebox(IQuant::Data::Localization.t('export_limit_reached', IQuant.current_lang || 'en'))
            end
            return false
          end
          
          lang = IQuant.current_lang || 'en'
          unit = IQuant.current_unit || 'm'
          currency = IQuant.display_currency || 'USD'
          
          # Verificar si se debe agregar watermark
          should_watermark = false
          license_info = {}
          
          if defined?(IQuant::Features::Licensing)
            license_info = IQuant::Features::Licensing.get_license_info
            should_watermark = license_info[:should_watermark] || false
          end
          
          # Generar PDF
          pdf = Prawn::Document.new(PDF_OPTIONS)
          
          # Configurar fuentes
          setup_fonts(pdf)
          
          # Header del reporte
          add_report_header(pdf, lang, should_watermark, license_info)
          
          # Watermark si es necesario (en todas las páginas)
          add_watermark(pdf, lang, should_watermark, license_info)
          
          # Sección de totales
          add_totals_section(pdf, data, lang, unit, currency)
          
          # Breakdown por materiales
          if data[:materials_breakdown]
            add_materials_breakdown(pdf, data[:materials_breakdown], lang, currency)
          end
          
          # Breakdown por categorías
          if data[:categories_breakdown]
            add_categories_breakdown(pdf, data[:categories_breakdown], lang, currency)
          end
          
          # Detalles por ítem
          if data[:items]
            add_items_details(pdf, data[:items], lang, unit, currency)
          end
          
          # Detalles de materiales (desglose)
          if data[:material_details]
            add_material_details(pdf, data[:material_details], lang, unit, currency)
          end
          
          # Footer con info de licencia
          add_footer(pdf, lang, license_info)
          
          # Renderizar
          pdf_content = pdf.render
          
          if path
            # Guardar a archivo
            File.open(path, 'wb') do |file|
              file.write(pdf_content)
            end
            
            # Registrar última ruta de exportación si existe el método
            if IQuant.respond_to?(:last_export_path=)
              IQuant.last_export_path = path
            end
            
            # Registrar exportación
            export_recorded = true
            if defined?(IQuant::Features::Licensing)
              export_recorded = IQuant::Features::Licensing.record_export
            end
            
            if export_recorded
              IQuant::Utils::Logger.log("Exportado a PDF: #{path}", :success) if defined?(IQuant::Utils::Logger)
              
              # Track analytics
              if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                IQuant::Features::Analytics.track_event('export_pdf', { 
                  trial: license_info[:status] == :trial,
                  format: 'pdf',
                  watermark: should_watermark
                })
              end
              
              true
            else
              IQuant::Utils::Logger.log("No se pudo registrar la exportación", :error) if defined?(IQuant::Utils::Logger)
              false
            end
          else
            pdf_content
          end
        end
      rescue => e
        IQuant::Utils::Logger.log("Error en exportación PDF: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
        false
      end
      
      private
      
      ##
      # Configura fuentes
      #
      def setup_fonts(pdf)
        pdf.font_families.update(
          "Helvetica" => {
            normal: "Helvetica",
            bold: "Helvetica-Bold"
          }
        )
        pdf.font FONTS[:normal]
      end
      
      ##
      # Agrega watermark si es necesario
      #
      def add_watermark(pdf, lang, should_watermark, license_info)
        return unless should_watermark && defined?(IQuant::Data::Localization)
        
        pdf.repeat(:all) do
          pdf.transparent(0.1) do  # 10% de opacidad
            pdf.fill_color COLORS[:watermark]
            pdf.font_size 48
            
            # Texto de watermark según estado
            watermark_text = if license_info[:status] == :trial
              IQuant::Data::Localization.t('trial_watermark', lang)
            else
              IQuant::Data::Localization.t('license_expired_watermark', lang)
            end
            
            # Rotar y centrar el watermark
            pdf.rotate(45, origin: [pdf.bounds.width / 2, pdf.bounds.height / 2]) do
              pdf.draw_text watermark_text, 
                at: [pdf.bounds.width / 4, pdf.bounds.height / 2],
                width: pdf.bounds.width / 2
            end
          end
        end
      end
      
      ##
      # Agrega header del reporte
      #
      def add_report_header(pdf, lang, should_watermark, license_info)
        if defined?(IQuant::Data::Localization)
          pdf.text IQuant::Data::Localization.t('report_title', lang), size: FONTS[:size_header], style: :bold, color: COLORS[:accent]
          pdf.text "#{IQuant::Data::Localization.t('generated_on', lang)}: #{Time.now.strftime('%Y-%m-%d %H:%M:%S')}", size: FONTS[:size_small]
        else
          pdf.text "iQuant Report", size: FONTS[:size_header], style: :bold, color: COLORS[:accent]
          pdf.text "Generated on: #{Time.now.strftime('%Y-%m-%d %H:%M:%S')}", size: FONTS[:size_small]
        end
        
        if defined?(IQuant::PLUGIN_VERSION)
          pdf.text "#{IQuant::Data::Localization.t('plugin_version', lang)}: #{IQuant::PLUGIN_VERSION}", size: FONTS[:size_small]
        end
        
        # Información de licencia si es trial
        if should_watermark && license_info[:status] == :trial && defined?(IQuant::Data::Localization)
          pdf.text "#{IQuant::Data::Localization.t('trial_version', lang)} - #{IQuant::Data::Localization.t('exports_remaining', lang)}: #{license_info[:exports_left]}/#{license_info[:trial_exports]}", 
                   size: FONTS[:size_small], 
                   color: COLORS[:watermark]
        end
        
        pdf.move_down 20
      end
      
      ##
      # Agrega sección de totales
      #
      def add_totals_section(pdf, data, lang, unit, currency)
        if defined?(IQuant::Data::Localization)
          pdf.text IQuant::Data::Localization.t('totals_section', lang), size: FONTS[:size_title], style: :bold
        else
          pdf.text "Totals", size: FONTS[:size_title], style: :bold
        end
        
        pdf.move_down 10
        
        if defined?(IQuant::Data::Localization)
          table_data = [
            [IQuant::Data::Localization.t('col_count', lang), data[:count] || 0],
            [IQuant::Data::Localization.t('col_length', lang), "#{format_number(data[:length] || 0)} #{unit}"],
            [IQuant::Data::Localization.t('col_area', lang), "#{format_number(data[:area_surf] || 0)} #{unit}²"],
            [IQuant::Data::Localization.t('col_volume', lang), "#{format_number(data[:volume] || 0)} #{unit}³"],
            [IQuant::Data::Localization.t('col_cost', lang), format_currency(data[:cost] || 0, currency)]
          ]
        else
          table_data = [
            ['Count', data[:count] || 0],
            ['Length', "#{format_number(data[:length] || 0)} #{unit}"],
            ['Area', "#{format_number(data[:area_surf] || 0)} #{unit}²"],
            ['Volume', "#{format_number(data[:volume] || 0)} #{unit}³"],
            ['Cost', format_currency(data[:cost] || 0, currency)]
          ]
        end
        
        pdf.table(table_data, cell_style: { size: FONTS[:size_normal], padding: 5 }) do
          cells.borders = []
          row(0..-1).borders = [:bottom]
          row(0..-1).border_width = 0.5
          row(0..-1).columns(0).font_style = :bold
        end
        
        pdf.move_down 20
      end
      
      ##
      # Agrega breakdown por materiales
      #
      def add_materials_breakdown(pdf, breakdown, lang, currency)
        return if breakdown.empty?
        
        if defined?(IQuant::Data::Localization)
          pdf.text IQuant::Data::Localization.t('materials_breakdown', lang), size: FONTS[:size_title], style: :bold
        else
          pdf.text "Materials Breakdown", size: FONTS[:size_title], style: :bold
        end
        
        pdf.move_down 10
        
        if defined?(IQuant::Data::Localization)
          table_data = [[IQuant::Data::Localization.t('col_material', lang), IQuant::Data::Localization.t('col_cost', lang)]]
        else
          table_data = [['Material', 'Cost']]
        end
        
        breakdown.each do |mat, mat_data|
          table_data << [mat, format_currency(mat_data[:cost] || 0, currency)]
        end
        
        pdf.table(table_data, header: true, cell_style: { size: FONTS[:size_normal], padding: 5 }) do
          row(0).font_style = :bold
          row(0).background_color = COLORS[:table_header]
        end
        
        pdf.move_down 20
      end
      
      ##
      # Agrega breakdown por categorías
      #
      def add_categories_breakdown(pdf, breakdown, lang, currency)
        return if breakdown.empty?
        
        if defined?(IQuant::Data::Localization)
          pdf.text IQuant::Data::Localization.t('categories_breakdown', lang), size: FONTS[:size_title], style: :bold
        else
          pdf.text "Categories Breakdown", size: FONTS[:size_title], style: :bold
        end
        
        pdf.move_down 10
        
        if defined?(IQuant::Data::Localization)
          table_data = [[IQuant::Data::Localization.t('col_category', lang), IQuant::Data::Localization.t('col_cost', lang)]]
        else
          table_data = [['Category', 'Cost']]
        end
        
        breakdown.each do |cat, cat_data|
          display_cat = cat
          if defined?(IQuant::Data) && IQuant::Data.respond_to?(:get_category_name)
            display_cat = IQuant::Data.get_category_name(cat, lang)
          end
          table_data << [display_cat, format_currency(cat_data[:cost] || 0, currency)]
        end
        
        pdf.table(table_data, header: true, cell_style: { size: FONTS[:size_normal], padding: 5 }) do
          row(0).font_style = :bold
          row(0).background_color = COLORS[:table_header]
        end
        
        pdf.move_down 20
      end
      
      ##
      # Agrega detalles por ítem
      #
      def add_items_details(pdf, items, lang, unit, currency)
        return if items.empty?
        
        if defined?(IQuant::Data::Localization)
          pdf.text IQuant::Data::Localization.t('items_details', lang), size: FONTS[:size_title], style: :bold
        else
          pdf.text "Items Details", size: FONTS[:size_title], style: :bold
        end
        
        pdf.move_down 10
        
        if defined?(IQuant::Data::Localization)
          table_data = [[
            IQuant::Data::Localization.t('col_name', lang),
            IQuant::Data::Localization.t('col_material', lang),
            IQuant::Data::Localization.t('col_category', lang),
            IQuant::Data::Localization.t('col_length', lang),
            IQuant::Data::Localization.t('col_area', lang),
            IQuant::Data::Localization.t('col_volume', lang),
            IQuant::Data::Localization.t('col_cost', lang)
          ]]
        else
          table_data = [[
            'Name',
            'Material',
            'Category',
            'Length',
            'Area',
            'Volume',
            'Cost'
          ]]
        end
        
        items.each do |item|
          display_cat = item[:category] || 'Default'
          if defined?(IQuant::Data) && IQuant::Data.respond_to?(:get_category_name)
            display_cat = IQuant::Data.get_category_name(item[:category], lang)
          end
          
          table_data << [
            item[:name] || 'Unnamed',
            item[:material] || 'Default',
            display_cat,
            "#{format_number(item[:length] || 0)} #{unit}",
            "#{format_number(item[:area_surf] || 0)} #{unit}²",
            "#{format_number(item[:volume] || 0)} #{unit}³",
            format_currency(item[:cost] || 0, currency)
          ]
        end
        
        pdf.table(table_data, header: true, cell_style: { size: FONTS[:size_small], padding: 5 }) do
          row(0).font_style = :bold
          row(0).background_color = COLORS[:table_header]
          columns(0..-1).width = (pdf.bounds.width / 7) - 5
        end
        
        pdf.move_down 20
      end
      
      ##
      # Agrega desglose de materiales
      #
      def add_material_details(pdf, details, lang, unit, currency)
        return if details.empty?
        
        if defined?(IQuant::Data::Localization)
          pdf.text IQuant::Data::Localization.t('material_details', lang), size: FONTS[:size_title], style: :bold
        else
          pdf.text "Material Details", size: FONTS[:size_title], style: :bold
        end
        
        pdf.move_down 10
        
        if defined?(IQuant::Data::Localization)
          table_data = [[
            IQuant::Data::Localization.t('col_material', lang),
            IQuant::Data::Localization.t('col_quantity', lang),
            IQuant::Data::Localization.t('col_unit', lang),
            IQuant::Data::Localization.t('col_cost', lang)
          ]]
        else
          table_data = [[
            'Material',
            'Quantity',
            'Unit',
            'Cost'
          ]]
        end
        
        details.each do |mat_name, mat_data|
          table_data << [
            mat_name,
            format_number(mat_data[:quantity] || 0),
            mat_data[:unit] || unit,
            format_currency(mat_data[:cost] || 0, currency)
          ]
        end
        
        pdf.table(table_data, header: true, cell_style: { size: FONTS[:size_normal], padding: 5 }) do
          row(0).font_style = :bold
          row(0).background_color = COLORS[:table_header]
        end
        
        pdf.move_down 20
      end
      
      ##
      # Agrega footer
      #
      def add_footer(pdf, lang, license_info)
        pdf.repeat(:all, dynamic: true) do
          pdf.bounding_box([pdf.bounds.left, pdf.bounds.bottom + 20], width: pdf.bounds.width, height: 20) do
            pdf.font_size FONTS[:size_small]
            
            if defined?(IQuant::Data::Localization) && defined?(IQuant::PLUGIN_NAME)
              pdf.text "#{IQuant::Data::Localization.t('generated_by', lang)} #{IQuant::PLUGIN_NAME} - #{IQuant::Data::Localization.t('page', lang)} #{pdf.page_number}", align: :center
            else
              pdf.text "Generated by iQuant - Page #{pdf.page_number}", align: :center
            end
            
            # Información de licencia en el footer
            if license_info[:should_watermark] && license_info[:status] == :trial && defined?(IQuant::Data::Localization)
              pdf.text "#{IQuant::Data::Localization.t('exports_remaining', lang)}: #{license_info[:exports_left]}", 
                       align: :center, 
                       size: FONTS[:size_small] - 2,
                       color: COLORS[:watermark]
            end
          end
        end
      end
      
      # ==========================================================================
      # HELPERS DE FORMATO
      # ==========================================================================
      
      ##
      # Formatea número con separadores y decimales
      #
      def format_number(value)
        value.to_f.round(4).to_s.gsub(/(\d)(?=(\d{3})+(?!\d))/, '\\1,')
      end
      
      ##
      # Formatea moneda usando CurrencyConverter
      #
      def format_currency(amount, currency)
        if defined?(IQuant::Core::CurrencyConverter) && IQuant::Core::CurrencyConverter.respond_to?(:format_currency)
          IQuant::Core::CurrencyConverter.format_currency(amount, currency)
        else
          "#{format_number(amount)} #{currency}"
        end
      end
      
      # Ejecución segura
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          yield
        end
      end
      
    end
  end
end
