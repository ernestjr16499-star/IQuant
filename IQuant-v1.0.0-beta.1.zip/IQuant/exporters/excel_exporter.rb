﻿# encoding: UTF-8

require 'stringio'

begin
  require 'write_xlsx'
rescue LoadError
  # Si no está instalada, log y fallback (manejar en html_generator)
end

module IQuant
  module Exporters
    module ExcelExporter
      extend self
      
      # ==========================================================================
      # CONFIGURACIÓN DE EXPORTACIÓN EXCEL
      # ==========================================================================
      
      EXCEL_OPTIONS = {
        sheet_name: 'iQuant Report',
        column_widths: [20, 15, 15, 15, 15, 15, 20]
      }.freeze
      
      FORMATS = {
        header: { bold: 1, size: 18, color: 'blue', align: 'center' },
        title: { bold: 1, size: 14, color: 'black' },
        normal: { size: 10, color: 'black' },
        small: { size: 8, color: 'gray' },
        bold: { bold: 1 },
        table_header: { bold: 1, bg_color: 'silver', align: 'center' },
        currency: { num_format: '[$$-409]#,##0.00' },
        number: { num_format: '#,##0.0000' },
        watermark: { color: 'gray', italic: 1, size: 20, rotation: 45 }
      }.freeze
      
      # ==========================================================================
      # VERIFICACIÓN DE WRITEXLSX
      # ==========================================================================
      
      ##
      # Verifica si la gema WriteXLSX está disponible
      #
      def self.writexlsx_available?
        defined?(WriteXLSX) && WriteXLSX.respond_to?(:new)
      end
      
      # ==========================================================================
      # EXPORTACIÓN PRINCIPAL
      # ==========================================================================
      
      ##
      # Exporta los datos a Excel
      #
      # @param data [Hash] Datos de la selección (de Calculator.get_selection_stats)
      # @param path [String, nil] Ruta del archivo (si nil, retorna binstring)
      # @return [String, Boolean] Binstring XLSX si no path, o true si guardado
      #
      def export(data, path = nil)
        safe_execute('Exportar a Excel') do
          # Verificar si WriteXLSX está disponible
          unless writexlsx_available?
            if defined?(UI)
              UI.messagebox("Para exportar Excel necesitas instalar la gema WriteXLSX.\nAbre Terminal y ejecuta: gem install write_xlsx", MB_OK, "Gema faltante")
            end
            return false
          end
          
          # Verificar licencia antes de exportar
          if defined?(IQuant::Features::Licensing) && !IQuant::Features::Licensing.can_export?
            IQuant::Utils::Logger.log("No se puede exportar: límite de exportaciones alcanzado o licencia expirada", :warn) if defined?(IQuant::Utils::Logger)
            
            if defined?(UI) && defined?(IQuant::Data::Localization)
              UI.messagebox(IQuant::Data::Localization.t('export_limit_reached', IQuant.current_lang || 'en'))
            end
            return false
          end
          
          lang = IQuant.current_lang || 'en'
          unit = IQuant.current_unit || 'm'
          currency = IQuant.display_currency || 'USD'
          
          # Verificar si se debe agregar watermark
          should_watermark = false
          license_info = {}
          
          if defined?(IQuant::Features::Licensing)
            license_info = IQuant::Features::Licensing.get_license_info
            should_watermark = license_info[:should_watermark] || false
          end
          
          # Crear workbook temporal en memoria si no path
          io = path.nil? ? StringIO.new : nil
          workbook = WriteXLSX.new(path || io)
          
          # Crear formatos
          formats = create_formats(workbook)
          
          # Crear hoja
          worksheet = workbook.add_worksheet(EXCEL_OPTIONS[:sheet_name])
          
          # Ajustar anchos de columnas
          EXCEL_OPTIONS[:column_widths].each_with_index do |width, col|
            worksheet.set_column(col, col, width)
          end
          
          # Header del reporte
          row = add_report_header(worksheet, formats, lang, should_watermark, license_info)
          
          # Watermark si es necesario
          if should_watermark
            add_watermark(worksheet, formats, lang, license_info, row)
            row += 3  # Ajustar fila después del watermark
          end
          
          # Sección de totales
          row = add_totals_section(worksheet, formats, data, lang, unit, currency, row)
          
          # Breakdown por materiales
          if data[:materials_breakdown]
            row = add_materials_breakdown(worksheet, formats, data[:materials_breakdown], lang, currency, row)
          end
          
          # Breakdown por categorías
          if data[:categories_breakdown]
            row = add_categories_breakdown(worksheet, formats, data[:categories_breakdown], lang, currency, row)
          end
          
          # Detalles por ítem
          if data[:items]
            row = add_items_details(worksheet, formats, data[:items], lang, unit, currency, row)
          end
          
          # Detalles de materiales (desglose)
          if data[:material_details]
            row = add_material_details(worksheet, formats, data[:material_details], lang, unit, currency, row)
          end
          
          # Footer
          add_footer(worksheet, formats, lang, license_info, row)
          
          # Cerrar workbook
          workbook.close
          
          if path
            # Registrar exportación
            export_recorded = true
            if defined?(IQuant::Features::Licensing)
              export_recorded = IQuant::Features::Licensing.record_export
            end
            
            if export_recorded
              IQuant::Utils::Logger.log("Exportado a Excel: #{path}", :success) if defined?(IQuant::Utils::Logger)
              
              # Track analytics
              if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                IQuant::Features::Analytics.track_event('export_excel', { 
                  trial: license_info[:status] == :trial,
                  format: 'excel',
                  watermark: should_watermark
                })
              end
              
              true
            else
              IQuant::Utils::Logger.log("No se pudo registrar la exportación", :error) if defined?(IQuant::Utils::Logger)
              false
            end
          else
            io.string
          end
        end
      rescue => e
        IQuant::Utils::Logger.log("Error en exportación Excel: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
        false
      end
      
      private
      
      ##
      # Crea formatos para el workbook
      #
      def create_formats(workbook)
        Hash[FORMATS.map { |name, opts| [name, workbook.add_format(opts)] }]
      end
      
      ##
      # Agrega watermark si es necesario
      #
      def add_watermark(worksheet, formats, lang, license_info, start_row)
        return unless defined?(IQuant::Data::Localization)
        
        watermark_text = if license_info[:status] == :trial
          IQuant::Data::Localization.t('trial_watermark', lang)
        else
          IQuant::Data::Localization.t('license_expired_watermark', lang)
        end
        
        # Agregar watermark en celda central
        center_col = EXCEL_OPTIONS[:column_widths].length / 2
        worksheet.write(start_row, center_col - 1, watermark_text, formats[:watermark])
        
        # También agregar en otras celdas para mayor visibilidad
        worksheet.write(start_row + 1, 0, "#{IQuant::Data::Localization.t('trial_version', lang)}:", formats[:small])
        if license_info[:status] == :trial
          worksheet.write(start_row + 1, 1, 
            "#{license_info[:exports_left]}/#{license_info[:trial_exports]} #{IQuant::Data::Localization.t('exports_remaining', lang)}", 
            formats[:small])
        end
      end
      
      ##
      # Agrega header del reporte
      #
      def add_report_header(worksheet, formats, lang, should_watermark, license_info)
        if defined?(IQuant::Data::Localization)
          worksheet.merge_range('A1:G1', IQuant::Data::Localization.t('report_title', lang), formats[:header])
          worksheet.write('A2', "#{IQuant::Data::Localization.t('generated_on', lang)}: #{Time.now.strftime('%Y-%m-%d %H:%M:%S')}", formats[:small])
        else
          worksheet.merge_range('A1:G1', 'iQuant Report', formats[:header])
          worksheet.write('A2', "Generated on: #{Time.now.strftime('%Y-%m-%d %H:%M:%S')}", formats[:small])
        end
        
        if defined?(IQuant::PLUGIN_VERSION)
          worksheet.write('A3', "#{IQuant::Data::Localization.t('plugin_version', lang)}: #{IQuant::PLUGIN_VERSION}", formats[:small])
        end
        
        row = 3
        if should_watermark && defined?(IQuant::Data::Localization)
          row += 1
          if license_info[:status] == :trial
            worksheet.write(row, 0, IQuant::Data::Localization.t('trial_version', lang), formats[:small])
            worksheet.write(row, 1, "#{license_info[:exports_left]}/#{license_info[:trial_exports]} #{IQuant::Data::Localization.t('exports_remaining', lang)}", formats[:small])
          else
            worksheet.write(row, 0, IQuant::Data::Localization.t('license_expired', lang), formats[:small])
          end
        end
        
        row + 1
      end
      
      ##
      # Agrega sección de totales
      #
      def add_totals_section(worksheet, formats, data, lang, unit, currency, row)
        if defined?(IQuant::Data::Localization)
          worksheet.write(row, 0, IQuant::Data::Localization.t('totals_section', lang), formats[:title])
        else
          worksheet.write(row, 0, 'Totals', formats[:title])
        end
        
        row += 1
        
        if defined?(IQuant::Data::Localization)
          totals = [
            [IQuant::Data::Localization.t('col_count', lang), data[:count] || 0],
            [IQuant::Data::Localization.t('col_length', lang), "#{format_number(data[:length] || 0)} #{unit}"],
            [IQuant::Data::Localization.t('col_area', lang), "#{format_number(data[:area_surf] || 0)} #{unit}²"],
            [IQuant::Data::Localization.t('col_volume', lang), "#{format_number(data[:volume] || 0)} #{unit}³"],
            [IQuant::Data::Localization.t('col_cost', lang), format_currency(data[:cost] || 0, currency)]
          ]
        else
          totals = [
            ['Count', data[:count] || 0],
            ['Length', "#{format_number(data[:length] || 0)} #{unit}"],
            ['Area', "#{format_number(data[:area_surf] || 0)} #{unit}²"],
            ['Volume', "#{format_number(data[:volume] || 0)} #{unit}³"],
            ['Cost', format_currency(data[:cost] || 0, currency)]
          ]
        end
        
        totals.each do |label, value|
          worksheet.write(row, 0, label, formats[:bold])
          worksheet.write(row, 1, value, formats[:normal])
          row += 1
        end
        
        row + 1
      end
      
      ##
      # Agrega breakdown por materiales
      #
      def add_materials_breakdown(worksheet, formats, breakdown, lang, currency, row)
        return row if breakdown.empty?
        
        if defined?(IQuant::Data::Localization)
          worksheet.write(row, 0, IQuant::Data::Localization.t('materials_breakdown', lang), formats[:title])
        else
          worksheet.write(row, 0, 'Materials Breakdown', formats[:title])
        end
        
        row += 1
        
        if defined?(IQuant::Data::Localization)
          worksheet.write(row, 0, IQuant::Data::Localization.t('col_material', lang), formats[:table_header])
          worksheet.write(row, 1, IQuant::Data::Localization.t('col_cost', lang), formats[:table_header])
        else
          worksheet.write(row, 0, 'Material', formats[:table_header])
          worksheet.write(row, 1, 'Cost', formats[:table_header])
        end
        
        row += 1
        
        breakdown.each do |mat, mat_data|
          worksheet.write(row, 0, mat, formats[:normal])
          worksheet.write(row, 1, format_currency(mat_data[:cost] || 0, currency), formats[:currency])
          row += 1
        end
        
        row + 1
      end
      
      ##
      # Agrega breakdown por categorías
      #
      def add_categories_breakdown(worksheet, formats, breakdown, lang, currency, row)
        return row if breakdown.empty?
        
        if defined?(IQuant::Data::Localization)
          worksheet.write(row, 0, IQuant::Data::Localization.t('categories_breakdown', lang), formats[:title])
        else
          worksheet.write(row, 0, 'Categories Breakdown', formats[:title])
        end
        
        row += 1
        
        if defined?(IQuant::Data::Localization)
          worksheet.write(row, 0, IQuant::Data::Localization.t('col_category', lang), formats[:table_header])
          worksheet.write(row, 1, IQuant::Data::Localization.t('col_cost', lang), formats[:table_header])
        else
          worksheet.write(row, 0, 'Category', formats[:table_header])
          worksheet.write(row, 1, 'Cost', formats[:table_header])
        end
        
        row += 1
        
        breakdown.each do |cat, cat_data|
          display_cat = cat
          if defined?(IQuant::Data) && IQuant::Data.respond_to?(:get_category_name)
            display_cat = IQuant::Data.get_category_name(cat, lang)
          end
          worksheet.write(row, 0, display_cat, formats[:normal])
          worksheet.write(row, 1, format_currency(cat_data[:cost] || 0, currency), formats[:currency])
          row += 1
        end
        
        row + 1
      end
      
      ##
      # Agrega detalles por ítem
      #
      def add_items_details(worksheet, formats, items, lang, unit, currency, row)
        return row if items.empty?
        
        if defined?(IQuant::Data::Localization)
          worksheet.write(row, 0, IQuant::Data::Localization.t('items_details', lang), formats[:title])
        else
          worksheet.write(row, 0, 'Items Details', formats[:title])
        end
        
        row += 1
        
        if defined?(IQuant::Data::Localization)
          headers = [
            IQuant::Data::Localization.t('col_name', lang),
            IQuant::Data::Localization.t('col_material', lang),
            IQuant::Data::Localization.t('col_category', lang),
            IQuant::Data::Localization.t('col_length', lang),
            IQuant::Data::Localization.t('col_area', lang),
            IQuant::Data::Localization.t('col_volume', lang),
            IQuant::Data::Localization.t('col_cost', lang)
          ]
        else
          headers = [
            'Name',
            'Material',
            'Category',
            'Length',
            'Area',
            'Volume',
            'Cost'
          ]
        end
        
        headers.each_with_index do |header, col|
          worksheet.write(row, col, header, formats[:table_header])
        end
        row += 1
        
        items.each do |item|
          display_cat = item[:category] || 'Default'
          if defined?(IQuant::Data) && IQuant::Data.respond_to?(:get_category_name)
            display_cat = IQuant::Data.get_category_name(item[:category], lang)
          end
          
          worksheet.write(row, 0, item[:name] || 'Unnamed', formats[:normal])
          worksheet.write(row, 1, item[:material] || 'Default', formats[:normal])
          worksheet.write(row, 2, display_cat, formats[:normal])
          worksheet.write(row, 3, "#{format_number(item[:length] || 0)} #{unit}", formats[:number])
          worksheet.write(row, 4, "#{format_number(item[:area_surf] || 0)} #{unit}²", formats[:number])
          worksheet.write(row, 5, "#{format_number(item[:volume] || 0)} #{unit}³", formats[:number])
          worksheet.write(row, 6, format_currency(item[:cost] || 0, currency), formats[:currency])
          row += 1
        end
        
        row + 1
      end
      
      ##
      # Agrega desglose de materiales
      #
      def add_material_details(worksheet, formats, details, lang, unit, currency, row)
        return row if details.empty?
        
        if defined?(IQuant::Data::Localization)
          worksheet.write(row, 0, IQuant::Data::Localization.t('material_details', lang), formats[:title])
        else
          worksheet.write(row, 0, 'Material Details', formats[:title])
        end
        
        row += 1
        
        if defined?(IQuant::Data::Localization)
          headers = [
            IQuant::Data::Localization.t('col_material', lang),
            IQuant::Data::Localization.t('col_quantity', lang),
            IQuant::Data::Localization.t('col_unit', lang),
            IQuant::Data::Localization.t('col_cost', lang)
          ]
        else
          headers = [
            'Material',
            'Quantity',
            'Unit',
            'Cost'
          ]
        end
        
        headers.each_with_index do |header, col|
          worksheet.write(row, col, header, formats[:table_header])
        end
        row += 1
        
        details.each do |mat_name, mat_data|
          worksheet.write(row, 0, mat_name, formats[:normal])
          worksheet.write(row, 1, format_number(mat_data[:quantity] || 0), formats[:number])
          worksheet.write(row, 2, mat_data[:unit] || unit, formats[:normal])
          worksheet.write(row, 3, format_currency(mat_data[:cost] || 0, currency), formats[:currency])
          row += 1
        end
        
        row + 1
      end
      
      ##
      # Agrega footer
      #
      def add_footer(worksheet, formats, lang, license_info, row)
        if defined?(IQuant::Data::Localization) && defined?(IQuant::PLUGIN_NAME)
          worksheet.write(row, 0, "#{IQuant::Data::Localization.t('generated_by', lang)} #{IQuant::PLUGIN_NAME}", formats[:small])
        else
          worksheet.write(row, 0, "Generated by iQuant", formats[:small])
        end
        
        if license_info[:should_watermark] && license_info[:status] == :trial && defined?(IQuant::Data::Localization)
          worksheet.write(row + 1, 0, 
            "#{IQuant::Data::Localization.t('exports_remaining', lang)}: #{license_info[:exports_left]}", 
            formats[:small])
        end
      end
      
      # ==========================================================================
      # HELPERS DE FORMATO
      # ==========================================================================
      
      ##
      # Formatea número con separadores y decimales
      #
      def format_number(value)
        value.to_f.round(4)
      end
      
      ##
      # Formatea moneda usando CurrencyConverter
      #
      def format_currency(amount, currency)
        if defined?(IQuant::Core::CurrencyConverter) && IQuant::Core::CurrencyConverter.respond_to?(:format_currency)
          IQuant::Core::CurrencyConverter.format_currency(amount, currency)
        else
          amount.to_f.round(2)
        end
      end
      
      # Ejecución segura
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          yield
        end
      end
      
    end
  end
end
