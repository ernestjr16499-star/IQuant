﻿# encoding: UTF-8

require 'csv'

module IQuant
  module Exporters
    module CsvExporter
      extend self
      
      # ==========================================================================
      # CONFIGURACIÓN DE EXPORTACIÓN CSV
      # ==========================================================================
      
      CSV_OPTIONS = {
        col_sep: ',',
        row_sep: "\n",
        quote_char: '"',
        force_quotes: true,
        encoding: 'UTF-8'
      }.freeze
      
      # ==========================================================================
      # EXPORTACIÓN PRINCIPAL
      # ==========================================================================
      
      ##
      # Exporta los datos a CSV
      #
      # @param data [Hash] Datos de la selección (de Calculator.get_selection_stats)
      # @param path [String, nil] Ruta del archivo (si nil, retorna string)
      # @return [String, Boolean] String CSV si no path, o true si guardado
      #
      def export(data, path = nil)
        safe_execute('Exportar a CSV') do
          # Verificar licencia antes de exportar
          unless can_export?
            IQuant::Utils::Logger.log("No se puede exportar: límite de exportaciones alcanzado o licencia expirada", :warn) if defined?(IQuant::Utils::Logger)
            UI.messagebox(get_localization('export_limit_reached')) if defined?(UI)
            return false
          end
          
          lang = IQuant.current_lang || 'en'
          unit = IQuant.current_unit || 'm'
          currency = IQuant.display_currency || 'USD'
          
          # Verificar si se debe agregar watermark
          license_info = get_license_info
          should_watermark = license_info[:should_watermark]
          
          # Generar contenido CSV
          csv_string = CSV.generate(CSV_OPTIONS) do |csv|
            # Header del reporte
            add_report_header(csv, lang, should_watermark, license_info)
            
            # Sección de totales
            add_totals_section(csv, data, lang, unit, currency)
            
            # Breakdown por materiales
            add_materials_breakdown(csv, data[:materials_breakdown], lang, currency)
            
            # Breakdown por categorías
            add_categories_breakdown(csv, data[:categories_breakdown], lang, currency)
            
            # Detalles por ítem
            add_items_details(csv, data[:items], lang, unit, currency)
            
            # Detalles de materiales (desglose)
            add_material_details(csv, data[:material_details], lang, unit, currency)
            
            # Footer con info de licencia si trial
            add_footer(csv, lang, license_info)
          end
          
          if path
            # Guardar a archivo
            File.open(path, 'w:UTF-8') do |file|
              file.write("\uFEFF")  # BOM para Excel
              file.write(csv_string)
            end
            
            # Actualizar ruta de última exportación si el método existe
            if IQuant.respond_to?(:last_export_path=)
              IQuant.last_export_path = path
            end
            
            # Registrar exportación
            if record_export
              IQuant::Utils::Logger.log("Exportado a CSV: #{path}", :info) if defined?(IQuant::Utils::Logger)
              
              # Track analytics
              if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                IQuant::Features::Analytics.track_event('export_csv', { 
                  trial: license_info[:status] == :trial,
                  format: 'csv'
                })
              end
              
              true
            else
              IQuant::Utils::Logger.log("No se pudo registrar la exportación", :error) if defined?(IQuant::Utils::Logger)
              false
            end
          else
            csv_string
          end
        end
      rescue => e
        IQuant::Utils::Logger.log("Error en exportación CSV: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
        false
      end
      
      # ==========================================================================
      # HELPERS DE ESCAPE CSV
      # ==========================================================================
      
      ##
      # Escapa un campo CSV
      #
      def escape_csv_field(field)
        field = field.to_s
        if field.include?(',') || field.include?('"') || field.include?("\n")
          '"' + field.gsub('"', '""') + '"'
        else
          field
        end
      end
      
      private
      
      ##
      # Agrega header del reporte
      #
      def add_report_header(csv, lang, should_watermark, license_info)
        csv << [get_localization('report_title', lang), Time.now.strftime('%Y-%m-%d %H:%M:%S')]
        csv << [get_localization('plugin_version', lang), IQuant::PLUGIN_VERSION]
        
        # Agregar información de licencia si es trial
        if should_watermark && license_info[:status] == :trial
          csv << [get_localization('trial_version', lang), '']
          csv << [get_localization('exports_remaining', lang), "#{license_info[:exports_left]}/#{license_info[:trial_exports]}"]
          csv << [get_localization('days_remaining', lang), "#{license_info[:days_left]}/#{license_info[:trial_days]}"]
        end
        
        csv << []  # Línea en blanco
      end
      
      ##
      # Agrega sección de totales
      #
      def add_totals_section(csv, data, lang, unit, currency)
        csv << [get_localization('totals_section', lang)]
        csv << [get_localization('col_count', lang), data[:count]]
        csv << [get_localization('col_length', lang), "#{format_number(data[:length])} #{unit}"]
        csv << [get_localization('col_area', lang), "#{format_number(data[:area_surf])} #{unit}²"]
        csv << [get_localization('col_volume', lang), "#{format_number(data[:volume])} #{unit}³"]
        csv << [get_localization('col_cost', lang), format_currency(data[:cost], currency)]
        csv << []  # Línea en blanco
      end
      
      ##
      # Agrega breakdown por materiales
      #
      def add_materials_breakdown(csv, breakdown, lang, currency)
        return if breakdown.empty?
        
        csv << [get_localization('materials_breakdown', lang)]
        csv << [get_localization('col_material', lang), get_localization('col_cost', lang)]
        
        breakdown.each do |mat, mat_data|
          csv << [escape_csv_field(mat), escape_csv_field(format_currency(mat_data[:cost], currency))]
        end
        
        csv << []  # Línea en blanco
      end
      
      ##
      # Agrega breakdown por categorías
      #
      def add_categories_breakdown(csv, breakdown, lang, currency)
        return if breakdown.empty?
        
        csv << [get_localization('categories_breakdown', lang)]
        csv << [get_localization('col_category', lang), get_localization('col_cost', lang)]
        
        breakdown.each do |cat, cat_data|
          display_cat = get_category_name(cat, lang)
          csv << [escape_csv_field(display_cat), escape_csv_field(format_currency(cat_data[:cost], currency))]
        end
        
        csv << []  # Línea en blanco
      end
      
      ##
      # Agrega detalles por ítem
      #
      def add_items_details(csv, items, lang, unit, currency)
        return if items.empty?
        
        csv << [get_localization('items_details', lang)]
        csv << [
          get_localization('col_name', lang),
          get_localization('col_material', lang),
          get_localization('col_category', lang),
          get_localization('col_length', lang),
          get_localization('col_area', lang),
          get_localization('col_volume', lang),
          get_localization('col_cost', lang)
        ]
        
        items.each do |item|
          csv << [
            escape_csv_field(item[:name]),
            escape_csv_field(item[:material] || 'Default'),
            escape_csv_field(get_category_name(item[:category], lang)),
            escape_csv_field("#{format_number(item[:length])} #{unit}"),
            escape_csv_field("#{format_number(item[:area_surf])} #{unit}²"),
            escape_csv_field("#{format_number(item[:volume])} #{unit}³"),
            escape_csv_field(format_currency(item[:cost], currency))
          ]
        end
        
        csv << []  # Línea en blanco
      end
      
      ##
      # Agrega desglose de materiales
      #
      def add_material_details(csv, details, lang, unit, currency)
        return if details.empty?
        
        csv << [get_localization('material_details', lang)]
        csv << [
          get_localization('col_material', lang),
          get_localization('col_quantity', lang),
          get_localization('col_unit', lang),
          get_localization('col_cost', lang)
        ]
        
        details.each do |mat_name, mat_data|
          csv << [
            escape_csv_field(mat_name),
            escape_csv_field(format_number(mat_data[:quantity])),
            escape_csv_field(mat_data[:unit] || unit),
            escape_csv_field(format_currency(mat_data[:cost], currency))
          ]
        end
        
        csv << []  # Línea en blanco
      end
      
      ##
      # Agrega footer
      #
      def add_footer(csv, lang, license_info)
        csv << [get_localization('generated_by', lang), IQuant::PLUGIN_NAME]
        
        # Agregar marca de agua si es trial
        if license_info[:should_watermark]
          if license_info[:status] == :trial
            csv << [get_localization('trial_watermark', lang), "#{license_info[:exports_left]} #{get_localization('exports_remaining', lang)}"]
          else
            csv << [get_localization('license_expired_watermark', lang), '']
          end
        end
      end
      
      # ==========================================================================
      # HELPERS DE FORMATO
      # ==========================================================================
      
      ##
      # Formatea número con separadores y decimales
      #
      def format_number(value)
        value.to_f.round(4).to_s.gsub(/(\d)(?=(\d{3})+(?!\d))/, '\\1,')
      end
      
      ##
      # Formatea moneda usando CurrencyConverter
      #
      def format_currency(amount, currency)
        if defined?(IQuant::Core::CurrencyConverter)
          IQuant::Core::CurrencyConverter.format_currency(amount, currency)
        else
          "#{currency} #{format_number(amount)}"
        end
      end
      
      ##
      # Obtiene nombre de categoría
      #
      def get_category_name(category, lang)
        if defined?(IQuant::Data) && IQuant::Data.respond_to?(:get_category_name)
          IQuant::Data.get_category_name(category, lang)
        else
          category.to_s
        end
      end
      
      ##
      # Obtiene localización
      #
      def get_localization(key, lang = nil)
        lang ||= IQuant.current_lang || 'en'
        if defined?(IQuant::Data::Localization)
          IQuant::Data::Localization.t(key, lang)
        else
          key
        end
      end
      
      ##
      # Verifica si se puede exportar
      #
      def can_export?
        if defined?(IQuant::Features::Licensing)
          IQuant::Features::Licensing.can_export?
        else
          true
        end
      end
      
      ##
      # Obtiene información de licencia
      #
      def get_license_info
        if defined?(IQuant::Features::Licensing)
          IQuant::Features::Licensing.get_license_info
        else
          { status: :licensed, should_watermark: false, exports_left: 0, trial_exports: 0, days_left: 0, trial_days: 0 }
        end
      end
      
      ##
      # Registra una exportación
      #
      def record_export
        if defined?(IQuant::Features::Licensing)
          IQuant::Features::Licensing.record_export
        else
          true
        end
      end
      
      # Ejecución segura
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          begin
            yield
          rescue => e
            puts "Error en #{operation}: #{e.message}" if defined?(IQuant::DEBUG_MODE) && IQuant::DEBUG_MODE
          end
        end
      end
      
    end
  end
end
