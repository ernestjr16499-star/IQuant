﻿# exporters/obj_exporter.rb
# Exportador de modelos 3D en formato OBJ para iQuant v4.1 - creado desde cero

module IQuant
  module Exporters
    module ObjExporter
      extend self
      
      # ==========================================================================
      # CONFIGURACIÓN DE EXPORTACIÓN OBJ
      # ==========================================================================
      
      OBJ_OPTIONS = {
        units: 'meters',           # Unidades de salida
        include_normals: true,     # Incluir normales de vértice
        include_uvs: false,        # Incluir coordenadas UV (si hay texturas)
        triangulate: true,         # Triangular caras
        group_by_material: false,  # Separar por materiales (usar 'usemtl')
        scale_factor: 1.0,         # Factor de escala adicional
        flip_yz: false             # Invertir ejes Y y Z (para algunos sistemas)
      }.freeze
      
      # Encabezado del archivo OBJ
      OBJ_HEADER = <<~OBJ
        # Exported by iQuant v#{IQuant::PLUGIN_VERSION if defined?(IQuant::PLUGIN_VERSION)}
        # Date: #{Time.now.strftime('%Y-%m-%d %H:%M:%S')}
        # Units: #{OBJ_OPTIONS[:units]}
        #
      OBJ
      
      # ==========================================================================
      # MÉTODO PRINCIPAL DE EXPORTACIÓN
      # ==========================================================================
      
      ##
      # Exporta geometría 3D del modelo de SketchUp en formato OBJ (Wavefront)
      #
      # @param entities [Array<Sketchup::Entity>] Array de entidades de SketchUp
      # @param output_path [String] Ruta del archivo de salida (.obj)
      # @param options [Hash] Opciones de exportación (sobrescribe OBJ_OPTIONS)
      # @return [Boolean] True si se exportó exitosamente, False si hubo error
      #
      def export_3d_model(entities, output_path, options = {})
        safe_execute('Exportar modelo 3D a OBJ') do
          # Verificar licencia antes de exportar
          unless can_export?
            log_message("No se puede exportar OBJ: licencia requerida o límite alcanzado", :warn)
            show_license_message
            return false
          end
          
          # Validar parámetros
          return false unless valid_parameters?(entities, output_path)
          
          # Fusionar opciones
          export_options = OBJ_OPTIONS.merge(options)
          
          # Preparar datos para exportación
          obj_data = prepare_obj_data(entities, export_options)
          
          # Generar contenido OBJ
          obj_content = generate_obj_content(obj_data, export_options)
          
          # Guardar archivo
          if save_obj_file(obj_content, output_path)
            # Registrar exportación
            if record_export
              log_message("Modelo 3D exportado exitosamente: #{output_path}", :success)
              
              # Track analytics si está disponible
              if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                IQuant::Features::Analytics.track_event('export_obj', {
                  vertex_count: obj_data[:vertices].size,
                  face_count: obj_data[:faces].size,
                  entity_count: entities.size
                })
              end
              
              true
            else
              log_message("Exportación OBJ completada pero no se pudo registrar", :warn)
              false
            end
          else
            log_message("Error al guardar archivo OBJ: #{output_path}", :error)
            false
          end
        end
      end
      
      ##
      # Exporta la selección actual de SketchUp a un archivo OBJ
      # Método de conveniencia para usar desde la UI
      #
      # @return [Boolean] True si se exportó exitosamente
      #
      def export
        safe_execute('Exportar selección a OBJ') do
          # Obtener selección actual
          model = Sketchup.active_model
          selection = model.selection
          
          if selection.empty?
            UI.messagebox("Selecciona al menos un objeto para exportar a OBJ")
            log_message("No hay selección para exportar a OBJ", :warn)
            return false
          end
          
          # Solicitar ruta de archivo
          output_path = UI.savepanel(
            "Exportar modelo 3D (OBJ)",
            default_export_directory,
            "modelo.obj"
          )
          
          return false unless output_path
          
          # Asegurar extensión .obj
          output_path = File.extname(output_path).downcase == '.obj' ? 
                        output_path : "#{output_path}.obj"
          
          # Exportar
          success = export_3d_model(selection.to_a, output_path)
          
          if success && File.exist?(output_path)
            # Mostrar mensaje de éxito
            UI.messagebox("Modelo exportado exitosamente:\n#{output_path}")
            
            # Abrir carpeta contenedora (opcional)
            # UI.openURL("file://#{File.dirname(output_path)}")
          end
          
          success
        end
      end
      
      private
      
      # ==========================================================================
      # PREPARACIÓN DE DATOS OBJ
      # ==========================================================================
      
      ##
      # Prepara los datos para exportación OBJ
      #
      def prepare_obj_data(entities, options)
        log_message("Preparando datos OBJ para #{entities.size} entidades", :info)
        
        # Inicializar contenedores de datos
        obj_data = {
          vertices: [],      # [ [x,y,z], ... ]
          normals: [],       # [ [nx,ny,nz], ... ]
          uvs: [],           # [ [u,v], ... ] (si hay texturas)
          faces: [],         # [ [v_idx, n_idx, uv_idx], ... ] por vértice de cara
          materials: {},     # { material_name: { faces: [face_indices], ... } }
          groups: {}         # { group_name: { faces: [face_indices], ... } }
        }
        
        # Recorrer entidades recursivamente
        process_entities(entities, Geom::Transformation.new, obj_data, options)
        
        log_message("Datos OBJ preparados: #{obj_data[:vertices].size} vértices, #{obj_data[:faces].size} caras", :info)
        obj_data
      end
      
      ##
      # Procesa entidades recursivamente
      #
      def process_entities(entities, transform, obj_data, options, parent_name = nil)
        entities.each do |entity|
          next if entity.deleted?
          
          case entity
          when Sketchup::Group, Sketchup::ComponentInstance
            # Procesar grupo/componente recursivamente
            group_name = entity.respond_to?(:name) && !entity.name.empty? ? 
                         entity.name : "Group_#{entity.entityID}"
            
            # Transformación compuesta
            entity_transform = transform * entity.transformation
            
            # Procesar entidades internas
            process_entities(
              entity.definition.entities, 
              entity_transform, 
              obj_data, 
              options, 
              group_name
            )
            
          when Sketchup::Face
            # Procesar cara
            process_face(entity, transform, obj_data, options, parent_name)
            
          when Sketchup::Edge
            # Opcional: procesar aristas como líneas (no común en OBJ)
            # process_edge(entity, transform, obj_data, options)
            
          else
            # Otros tipos de entidades (ignorar por ahora)
            next
          end
        end
      end
      
      ##
      # Procesa una cara individual
      #
      def process_face(face, transform, obj_data, options, group_name = nil)
        begin
          # Obtener malla triangulada si es necesario
          mesh = if options[:triangulate]
                   face.mesh(7)  # Triangulada con normales
                 else
                   face.mesh(0)  # Polígonos originales
                 end
          
          # Material de la cara
          material_name = face.material ? 
                          face.material.display_name : 
                          'Default'
          
          # Obtener offset actual de índices
          vertex_offset = obj_data[:vertices].size
          normal_offset = obj_data[:normals].size
          uv_offset = obj_data[:uvs].size
          
          # Procesar vértices
          mesh.points.each do |point|
            # Transformar a coordenadas globales
            global_point = point.transform(transform)
            
            # Convertir unidades (SketchUp usa pulgadas internamente)
            converted_point = convert_units(
              [global_point.x, global_point.y, global_point.z], 
              options
            )
            
            obj_data[:vertices] << converted_point
          end
          
          # Procesar normales
          if options[:include_normals] && mesh.normals
            mesh.normals.each do |normal|
              # Transformar normal (solo rotación, sin traslación)
              global_normal = normal.transform(transform)
              global_normal.normalize!
              
              obj_data[:normals] << [global_normal.x, global_normal.y, global_normal.z]
            end
          end
          
          # Procesar UVs (si hay texturas y se solicitan)
          if options[:include_uvs] && mesh.uvs
            mesh.uvs.each do |uv|
              obj_data[:uvs] << [uv.x, uv.y]
            end
          end
          
          # Procesar polígonos/caras
          (1..mesh.count_polygons).each do |polygon_index|
            polygon = mesh.polygon_at(polygon_index)
            next unless polygon
            
            # Crear entrada de cara OBJ
            face_entry = []
            
            polygon.each do |vertex_index|
              # Los índices en OBJ son 1-based
              v_idx = vertex_offset + vertex_index.abs
              n_idx = options[:include_normals] ? (normal_offset + vertex_index.abs) : nil
              uv_idx = options[:include_uvs] ? (uv_offset + vertex_index.abs) : nil
              
              # Formato: f v1 v2 v3  o  f v1//vn1 v2//vn2 v3//vn3  o  f v1/vt1/vn1 v2/vt2/vn2 v3/vt3/vn3
              if uv_idx && n_idx
                face_entry << "#{v_idx}/#{uv_idx}/#{n_idx}"
              elsif n_idx
                face_entry << "#{v_idx}//#{n_idx}"
              else
                face_entry << v_idx.to_s
              end
            end
            
            # Añadir cara a los datos
            face_index = obj_data[:faces].size
            obj_data[:faces] << face_entry
            
            # Registrar material si estamos agrupando por material
            if options[:group_by_material]
              obj_data[:materials][material_name] ||= { faces: [] }
              obj_data[:materials][material_name][:faces] << face_index
            end
            
            # Registrar grupo si hay nombre de grupo
            if group_name
              obj_data[:groups][group_name] ||= { faces: [] }
              obj_data[:groups][group_name][:faces] << face_index
            end
          end
          
        rescue => e
          log_message("Error procesando cara #{face.entityID}: #{e.message}", :error)
        end
      end
      
      # ==========================================================================
      # GENERACIÓN DE CONTENIDO OBJ
      # ==========================================================================
      
      ##
      # Genera el contenido del archivo OBJ
      #
      def generate_obj_content(obj_data, options)
        lines = []
        
        # Encabezado
        lines << OBJ_HEADER
        
        # Información de escala y unidades
        lines << "# Units converted from SketchUp inches to #{options[:units]}"
        lines << "# Vertex count: #{obj_data[:vertices].size}"
        lines << "# Face count: #{obj_data[:faces].size}"
        lines << "#"
        
        # Vértices
        lines << "# Vertices"
        obj_data[:vertices].each do |vertex|
          # Formato: v x y z [w] (w es coordenada homogénea, opcional)
          if options[:flip_yz]
            # Algunos sistemas intercambian Y y Z
            lines << sprintf("v %.6f %.6f %.6f", vertex[0], vertex[2], vertex[1])
          else
            lines << sprintf("v %.6f %.6f %.6f", vertex[0], vertex[1], vertex[2])
          end
        end
        lines << ""
        
        # Normales (si se incluyen)
        if options[:include_normals] && !obj_data[:normals].empty?
          lines << "# Vertex normals"
          obj_data[:normals].each do |normal|
            lines << sprintf("vn %.6f %.6f %.6f", normal[0], normal[1], normal[2])
          end
          lines << ""
        end
        
        # Coordenadas de textura (UVs) si se incluyen
        if options[:include_uvs] && !obj_data[:uvs].empty?
          lines << "# Texture coordinates"
          obj_data[:uvs].each do |uv|
            lines << sprintf("vt %.6f %.6f", uv[0], uv[1])
          end
          lines << ""
        end
        
        # Grupos (si hay)
        if !obj_data[:groups].empty?
          obj_data[:groups].each do |group_name, group_data|
            lines << "g #{sanitize_obj_name(group_name)}"
            lines << "# Group: #{group_name} (#{group_data[:faces].size} faces)"
            
            # Caras de este grupo
            group_data[:faces].each do |face_index|
              face = obj_data[:faces][face_index]
              lines << "f #{face.join(' ')}" if face
            end
            
            lines << ""
          end
        else
          # Materiales (si se agrupan por material)
          if options[:group_by_material] && !obj_data[:materials].empty?
            obj_data[:materials].each do |material_name, material_data|
              lines << "usemtl #{sanitize_obj_name(material_name)}"
              lines << "# Material: #{material_name}"
              
              material_data[:faces].each do |face_index|
                face = obj_data[:faces][face_index]
                lines << "f #{face.join(' ')}" if face
              end
              
              lines << ""
            end
          else
            # Todas las caras juntas
            lines << "# Faces"
            obj_data[:faces].each do |face|
              lines << "f #{face.join(' ')}" if face
            end
          end
        end
        
        # Material library (si hay materiales)
        if options[:group_by_material] && !obj_data[:materials].empty?
          lines << ""
          lines << "# Material library"
          lines << "mtllib #{generate_material_library(obj_data[:materials])}"
        end
        
        lines.join("\n")
      end
      
      ##
      # Genera archivo de materiales MTL (simplificado)
      #
      def generate_material_library(materials)
        # Esto es un placeholder básico
        # En una implementación real, se extraerían las propiedades del material
        mtl_content = "# Material library for iQuant export\n#\n"
        
        materials.each_key do |material_name|
          mtl_content << "\nnewmtl #{sanitize_obj_name(material_name)}\n"
          mtl_content << "Ka 0.8 0.8 0.8\n"  # Ambient
          mtl_content << "Kd 0.8 0.8 0.8\n"  # Diffuse
          mtl_content << "Ks 0.5 0.5 0.5\n"  # Specular
          mtl_content << "Ns 32.0\n"         # Shininess
          mtl_content << "d 1.0\n"           # Dissolve (opacity)
          mtl_content << "illum 2\n"         # Illumination model
        end
        
        mtl_content
      end
      
      # ==========================================================================
      # UTILIDADES DE ARCHIVO Y CONVERSIÓN
      # ==========================================================================
      
      ##
      # Guarda el contenido OBJ en un archivo
      #
      def save_obj_file(content, output_path)
        begin
          # Asegurar que el directorio existe
          ensure_export_directory(output_path)
          
          # Guardar archivo
          File.write(output_path, content)
          
          # Verificar que se guardó correctamente
          if File.exist?(output_path) && File.size(output_path) > 0
            log_message("Archivo OBJ guardado: #{output_path} (#{File.size(output_path)} bytes)", :info)
            true
          else
            log_message("Error: Archivo OBJ no se guardó correctamente", :error)
            false
          end
          
        rescue Errno::EACCES => e
          log_message("Permiso denegado para escribir: #{output_path}", :error)
          false
        rescue => e
          log_message("Error guardando archivo OBJ: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Convierte unidades de pulgadas (SketchUp) a la unidad de salida
      #
      def convert_units(point, options)
        x, y, z = point
        
        # Factor de conversión de pulgadas a la unidad objetivo
        conversion_factor = case options[:units].downcase
                           when 'meters', 'm'
                             0.0254  # Pulgadas a metros
                           when 'centimeters', 'cm'
                             2.54    # Pulgadas a centímetros
                           when 'millimeters', 'mm'
                             25.4    # Pulgadas a milímetros
                           when 'feet', 'ft'
                             1.0/12.0 # Pulgadas a pies
                           else
                             1.0     # Mantener pulgadas
                           end
        
        # Aplicar factor y escala adicional
        scale = options[:scale_factor] || 1.0
        factor = conversion_factor * scale
        
        [x * factor, y * factor, z * factor]
      end
      
      ##
      # Asegura que el directorio de exportación exista
      #
      def ensure_export_directory(file_path)
        dir = File.dirname(file_path)
        
        if defined?(IQuant::Utils::FileManager)
          IQuant::Utils::FileManager.ensure_directory(dir)
        else
          require 'fileutils'
          FileUtils.mkdir_p(dir) unless Dir.exist?(dir)
        end
      end
      
      ##
      # Directorio de exportación por defecto
      #
      def default_export_directory
        if defined?(IQuant::PLUGIN_DIR)
          File.join(IQuant::PLUGIN_DIR, 'exports')
        else
          File.join(Dir.home, 'Documents', 'iQuant_Exports')
        end
      end
      
      ##
      # Sanitiza nombres para formato OBJ (sin espacios o caracteres especiales)
      #
      def sanitize_obj_name(name)
        name.to_s.gsub(/[^\w\-\.]/, '_')[0..50]  # Limitar longitud
      end
      
      # ==========================================================================
      # VALIDACIONES Y LICENCIAS
      # ==========================================================================
      
      ##
      # Verifica si se puede exportar (licencia)
      #
      def can_export?
        if defined?(IQuant::Features::Licensing)
          IQuant::Features::Licensing.can_export?
        else
          true  # Permitir si no hay sistema de licencias
        end
      end
      
      ##
      # Registra la exportación en el sistema de licencias
      #
      def record_export
        if defined?(IQuant::Features::Licensing)
          IQuant::Features::Licensing.record_export
        else
          true  # Siempre éxito si no hay sistema de licencias
        end
      end
      
      ##
      # Muestra mensaje de licencia si es necesario
      #
      def show_license_message
        if defined?(UI) && defined?(IQuant::Data::Localization)
          UI.messagebox(IQuant::Data::Localization.t('export_limit_reached', IQuant.current_lang || 'en'))
        elsif defined?(UI)
          UI.messagebox("Export limit reached or license required.")
        end
      end
      
      ##
      # Valida los parámetros de entrada
      #
      def valid_parameters?(entities, output_path)
        if entities.nil? || entities.empty?
          log_message("No hay entidades para exportar", :warn)
          return false
        end
        
        if output_path.to_s.empty?
          log_message("Ruta de salida no especificada", :error)
          return false
        end
        
        # Verificar que al menos algunas entidades sean geométricas
        has_geometry = entities.any? do |entity|
          entity.is_a?(Sketchup::Face) || 
          entity.is_a?(Sketchup::Group) || 
          entity.is_a?(Sketchup::ComponentInstance)
        end
        
        unless has_geometry
          log_message("No hay geometría válida para exportar", :warn)
          return false
        end
        
        true
      end
      
      # ==========================================================================
      # LOGGING Y MANEJO DE ERRORES
      # ==========================================================================
      
      ##
      # Registra un mensaje en el log
      #
      def log_message(message, level = :info)
        if defined?(IQuant::Utils::Logger)
          IQuant::Utils::Logger.log("ObjExporter: #{message}", level)
        elsif defined?(IQuant::DEBUG_MODE) && IQuant::DEBUG_MODE
          puts "[ObjExporter #{level.to_s.upcase}] #{message}"
        end
      end
      
      ##
      # Ejecución segura
      #
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          begin
            yield
          rescue => e
            log_message("Error en #{operation}: #{e.message}", :error)
            nil
          end
        end
      end
      
    end
  end
end
