# encoding: UTF-8

module IQuant

  # ==========================================================================
  # VARIABLES DE MÓDULO (para dialog_manager y UI)
  # ==========================================================================
  
  class << self
    attr_accessor :current_lang, :current_unit, :dialog, 
                  :base_currency, :display_currency, :analytics_enabled,
                  :auto_refresh_enabled
  end

  # ==========================================================================
  # INFORMACIÓN DEL PLUGIN
  # ==========================================================================

  PLUGIN_NAME    = "IQuant"
  PLUGIN_VERSION = "1.0.0-beta.1"
  PLUGIN_AUTHOR  = "IQuant Team"
  PLUGIN_DESC    = "Professional Quantity Surveying for SketchUp"

  # ==========================================================================
  # CLAVES PARA ATTRIBUTEDICTIONARIES
  # ==========================================================================

  PREFS_KEY   = "IQuant_Prefs"
  DICT_COST   = "IQuant_CostRules"
  DICT_WEIGHT = "IQuant_WeightRules"
  DICT_DOSIF  = "IQuant_DosifRules"
  DICT_CATS   = "IQuant_Categories"

  # ==========================================================================
  # DIRECTORIOS
  # ==========================================================================

  # Directorio base del plugin (ya establecido en IQuant.rb)
  # PLUGIN_DIR se define en IQuant.rb dinámicamente
  # NOTA: NO definas PLUGIN_DIR aquí - se define en iQuant.rb

  # ==========================================================================
  # CONFIGURACIÓN DE COMPORTAMIENTO
  # ==========================================================================

  DEBUG_MODE = false
  LOG_TO_FILE = false
  LOG_LEVEL = :info

  # ==========================================================================
  # LICENSING & ANALYTICS CONSTANTS
  # ==========================================================================

  TRIAL_DAYS = 14
  TRIAL_EXPORTS = 10
  ANALYTICS_ENABLED_DEFAULT = false

  # ==========================================================================
  # FACTORES DE CONVERSIÓN DE UNIDADES (DESDE PULGADAS INTERNAS DE SKETCHUP)
  # ==========================================================================

  UNIT_FACTORS = {
    "mm"   => 25.4,
    "cm"   => 2.54,
    "m"    => 0.0254,
    "in"   => 1.0,
    "ft"   => 0.0833333,
    "yd"   => 0.0277778
  }

  DEFAULT_UNIT = "m"
  DEFAULT_CURRENCY = "USD"
  DEFAULT_DECIMAL_PLACES = 2

  # ==========================================================================
  # ARCHIVOS Y EXPORTACIONES
  # ==========================================================================

  # Directorios definidos dinámicamente (ver IQuant.rb)
  LOGS_DIR    = File.join(PLUGIN_DIR, 'logs')     if defined?(PLUGIN_DIR)
  EXPORTS_DIR = File.join(PLUGIN_DIR, 'exports')  if defined?(PLUGIN_DIR)
  TEMP_DIR    = File.join(PLUGIN_DIR, 'temp')     if defined?(PLUGIN_DIR)
  CONFIG_DIR  = File.join(PLUGIN_DIR, 'config')   if defined?(PLUGIN_DIR)

  CSV_ENCODING  = "UTF-8"
  CSV_DELIMITER = ";"

  # ==========================================================================
  # UI SETTINGS
  # ==========================================================================

  DIALOG_WIDTH  = 900
  DIALOG_HEIGHT = 700
  MIN_DIALOG_WIDTH  = 600
  MIN_DIALOG_HEIGHT = 500

  # ==========================================================================
  # PERFORMANCE & CACHE
  # ==========================================================================

  VOLUME_CACHE_EXPIRY = 60  # segundos
  MAX_ENTITIES_PER_CALCULATION = 10000
  ENABLE_PERFORMANCE_MONITORING = false

  # ==========================================================================
  # MATERIALES Y DOSIFICACIONES
  # ==========================================================================

  DEFAULT_DENSITY = 2400  # kg/m³ para concreto

  # ==========================================================================
  # NETWORKING
  # ==========================================================================

  API_TIMEOUT = 10  # segundos
  MAX_RETRIES = 3
  LICENSING_SERVER_URL = "https://api.iquant.app/license"
  ANALYTICS_SERVER_URL = "https://api.iquant.app/analytics"

  # ==========================================================================
  # HELPERS DE RUTAS
  # ==========================================================================

  def self.assets_path(*args)
    File.join(PLUGIN_DIR, 'assets', *args) if defined?(PLUGIN_DIR)
  end

  def self.icons_path(*args)
    assets_path('icons', *args)
  end

  def self.data_path(*args)
    File.join(PLUGIN_DIR, 'data', *args) if defined?(PLUGIN_DIR)
  end

end
