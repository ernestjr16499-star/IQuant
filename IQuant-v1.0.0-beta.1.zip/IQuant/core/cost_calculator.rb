# encoding: UTF-8

require 'json'

module IQuant
  module Core
    module CostCalculator
      extend self
      
      # ==========================================================================
      # CÁLCULO DE COSTOS CON DESGLOSE DETALLADO
      # ==========================================================================
      
      ##
      # Calcula el costo con desglose detallado de materiales
      #
      # @param vol [Float] Volumen en pulgadas cúbicas
      # @param area [Float] Área en pulgadas cuadradas
      # @param len [Float] Longitud en pulgadas
      # @param instance_count [Integer] Cantidad de instancias
      # @param rule [Hash] Regla de costo
      # @return [Array<Float, Hash>] Tupla con costo total y detalles
      #
      def calculate_cost_with_details(vol, area, len, instance_count, rule)
        return [0.0, {}] unless rule
        
        # Validar entrada de cálculo
        input_validation = if defined?(IQuant::Utils::Validator)
          IQuant::Utils::Validator.validate_calculation_input(
            volume: vol, area: area, length: len, instance_count: instance_count
          )
        else
          { valid: true, errors: [] }
        end
        
        unless input_validation[:valid]
          IQuant::Utils::Logger.log("Invalid calculation input: #{input_validation[:errors].join(', ')}", :error) if defined?(IQuant::Utils::Logger)
          return [0.0, {}]
        end
        
        type = rule[:type].to_s
        calc_method = rule[:calc_method]
        value = rule[:value].to_f

        unit_factor = IQuant::UNIT_FACTORS[IQuant.current_unit]

        case type
        
        when 'len'
          # ============================================
          # CÁLCULO POR LONGITUD (Cables, Tubos, Cabillas, Purlines)
          # ============================================
          calculate_length_cost(len, unit_factor, calc_method, rule)
        
        when 'area'
          # ============================================
          # CÁLCULO POR ÁREA (Pisos, Azulejos, Tejas)
          # ============================================
          calculate_area_cost(area, unit_factor, calc_method, rule)
        
        when 'vol'
          # ============================================
          # CÁLCULO POR VOLUMEN (Hormigón, Bloques, Rellenos)
          # ============================================
          calculate_volume_cost(vol, unit_factor, calc_method, rule)
        
        when 'unit'
          # ============================================
          # CÁLCULO POR UNIDADES DISCRETAS (Codos, Válvulas, Piezas)
          # ============================================
          calculate_discrete_cost(instance_count, value, rule)
        
        else
          [0.0, {}]
        end
      end
      
      # ==========================================================================
      # CÁLCULOS POR TIPO DE MEDIDA
      # ==========================================================================
      
      ##
      # Calcula costo por longitud
      #
      def calculate_length_cost(len, unit_factor, calc_method, rule)
        length_in_unit = len * unit_factor
        
        if calc_method == 'linear_stock'
          # Validar regla de material lineal
          validation = if defined?(IQuant::Utils::Validator)
            IQuant::Utils::Validator.validate_linear_stock_rule(rule)
          else
            { errors: [] }
          end
          
          unless validation[:errors].empty?
            IQuant::Utils::Logger.log("Invalid linear stock rule: #{validation[:errors].join(', ')}", :error) if defined?(IQuant::Utils::Logger)
            return [0.0, {}]
          end
          
          # Modo: Se vende en tiras/rollos de X metros
          stock_length = rule[:stock_length].to_f
          price_per_stock = rule[:price_per_stock].to_f
          
          # Convertir longitud a metros para cálculo
          length_meters = length_in_unit
          if IQuant.current_unit != 'm'
            length_meters = len * IQuant::UNIT_FACTORS['m']
          end
          
          # Calcular cantidad de tiras necesarias
          stock_units_needed = (length_meters / stock_length).ceil
          total_cost = stock_units_needed * price_per_stock
          
          details = {
            rule[:item_name] || 'linear_material' => {
              quantity: stock_units_needed,
              unit: "tiras de #{stock_length}m",
              cost: total_cost,
              info: "Longitud total: #{length_meters.round(2)}m"
            }
          }
          
          # Aplicar conversión de moneda si es necesario
          total_cost, details = apply_currency_conversion(total_cost, details)
          
          [total_cost, details]
        else
          # Modo simple: precio por metro lineal
          cost = rule[:value].to_f * length_in_unit
          details = {
            rule[:item_name] || 'linear_material' => {
              quantity: length_in_unit,
              unit: IQuant.current_unit,
              cost: cost
            }
          }
          
          # Aplicar conversión de moneda si es necesario
          cost, details = apply_currency_conversion(cost, details)
          
          [cost, details]
        end
      end
      
      ##
      # Calcula costo por área
      #
      def calculate_area_cost(area, unit_factor, calc_method, rule)
        area_in_unit = area * (unit_factor ** 2)
        
        if calc_method == 'tiles'
          # Validar regla de tejas
          validation = if defined?(IQuant::Utils::Validator)
            IQuant::Utils::Validator.validate_tiles_rule(rule)
          else
            { errors: [] }
          end
          
          unless validation[:errors].empty?
            IQuant::Utils::Logger.log("Invalid tiles rule: #{validation[:errors].join(', ')}", :error) if defined?(IQuant::Utils::Logger)
            return [0.0, {}]
          end
          
          # Modo: Tejas/Losetas vendidas por unidad
          tile_length = rule[:tile_length].to_f / 100.0  # en metros
          tile_width = rule[:tile_width].to_f / 100.0    # en metros
          tile_area = tile_length * tile_width
          price_per_tile = rule[:price_per_tile].to_f
          
          # Convertir área a m²
          area_m2 = area_in_unit
          if IQuant.current_unit != 'm'
            area_m2 = area * (IQuant::UNIT_FACTORS['m'] ** 2)
          end
          
          # Calcular cantidad de tejas/losetas (con 5% de desperdicio)
          tiles_needed = (area_m2 / tile_area * 1.05).ceil
          total_cost = tiles_needed * price_per_tile
          
          details = {
            rule[:item_name] || 'tiles' => {
              quantity: tiles_needed,
              unit: 'unidades',
              cost: total_cost,
              info: "Área cubierta: #{area_m2.round(2)}m²"
            }
          }
          
          # Aplicar conversión de moneda si es necesario
          total_cost, details = apply_currency_conversion(total_cost, details)
          
          [total_cost, details]
        else
          # Modo simple: precio por m²
          cost = rule[:value].to_f * area_in_unit
          details = {
            rule[:item_name] || 'area_material' => {
              quantity: area_in_unit,
              unit: "#{IQuant.current_unit}²",
              cost: cost
            }
          }
          
          # Aplicar conversión de moneda si es necesario
          cost, details = apply_currency_conversion(cost, details)
          
          [cost, details]
        end
      end
      
      ##
      # Calcula costo por volumen
      #
      def calculate_volume_cost(vol, unit_factor, calc_method, rule)
        case calc_method
        when 'solid'
          calculate_solid_cost_with_details(vol, rule, unit_factor)
        when 'masonry'
          calculate_masonry_cost_with_details(vol, rule, unit_factor)
        when 'fill_material'
          calculate_fill_cost_with_details(vol, rule, unit_factor)
        else
          # Modo simple: precio por m³
          volume_in_unit = vol * (unit_factor ** 3)
          cost = rule[:value].to_f * volume_in_unit
          details = {
            rule[:item_name] || 'volume_material' => {
              quantity: volume_in_unit,
              unit: "#{IQuant.current_unit}³",
              cost: cost
            }
          }
          
          # Aplicar conversión de moneda si es necesario
          cost, details = apply_currency_conversion(cost, details)
          
          [cost, details]
        end
      end
      
      ##
      # Calcula costo por unidades discretas
      #
      def calculate_discrete_cost(instance_count, value, rule)
        cost = instance_count * value
        
        details = {
          rule[:item_name] || 'discrete_unit' => {
            quantity: instance_count,
            unit: 'unidades',
            cost: cost
          }
        }
        
        # Aplicar conversión de moneda si es necesario
        cost, details = apply_currency_conversion(cost, details)
        
        [cost, details]
      end
      
      # ==========================================================================
      # CÁLCULOS ESPECIALIZADOS
      # ==========================================================================
      
      ##
      # Calcula el costo de mampostería con desglose detallado de materiales
      #
      # @param volume [Float] Volumen del muro en pulgadas cúbicas
      # @param rule [Hash] Regla de mampostería
      # @param unit_factor [Float] Factor de conversión de unidades
      # @return [Array<Float, Hash>] Tupla con costo total y detalles
      #
      def calculate_masonry_cost_with_details(volume, rule, unit_factor)
        # Validar regla de mampostería
        validation = if defined?(IQuant::Utils::Validator)
          IQuant::Utils::Validator.validate_masonry_rule(rule)
        else
          { errors: [], warnings: [] }
        end
        
        unless validation[:errors].empty?
          IQuant::Utils::Logger.log("Invalid masonry rule: #{validation[:errors].join(', ')}", :error) if defined?(IQuant::Utils::Logger)
          return [0.0, {}]
        end
        
        # Mostrar advertencias si existen
        unless validation[:warnings].empty?
          validation[:warnings].each do |warning|
            IQuant::Utils::Logger.log("Masonry rule warning: #{warning}", :warn) if defined?(IQuant::Utils::Logger)
          end
        end
        
        # Convertir volumen a m³
        volume_m3 = volume * (unit_factor ** 3)
        
        # Convertir dimensiones de cm a metros
        l = rule[:brick_length].to_f / 100.0      # Largo del bloque (horizontal)
        w = rule[:brick_width].to_f / 100.0       # ESPESOR DEL MURO (ancho del bloque)
        t = rule[:brick_thickness].to_f / 100.0   # Alto del bloque (vertical)
        j = rule[:joint_thickness].to_f / 100.0   # Espesor de la junta

        # ✅ CORRECCIÓN CRÍTICA: El espesor del muro es el ANCHO del bloque (w)
        wall_thickness = w
        wall_area = volume_m3 / wall_thickness

        # Dimensiones con junta
        l_with_joint = l + j
        t_with_joint = t + j
        
        # Bloques por m² de superficie de muro (usa largo y alto del bloque)
        blocks_per_m2 = 1.0 / (l_with_joint * t_with_joint)

        # Cantidad de bloques (con 3% de desperdicio)
        blocks_count = (wall_area * blocks_per_m2 * 1.03).ceil
        blocks_cost = blocks_count * rule[:brick_price].to_f

        # Volumen de mortero (aproximado 25% del volumen total)
        mortar_volume = volume_m3 * 0.25

        # Costo del mortero según dosificación
        mortar_details = calculate_mortar_cost_details(
          mortar_volume, 
          rule[:mortar_dosage], 
          rule[:mortar_prices]
        )
        mortar_cost = mortar_details.values.sum { |d| d[:cost] }

        total_cost = blocks_cost + mortar_cost
        
        # Preparar detalles con información adicional
        details = {
          'blocks' => { 
            quantity: blocks_count, 
            unit: 'unidades', 
            cost: blocks_cost,
            info: "Bloque #{(l*100).round}×#{(w*100).round}×#{(t*100).round}cm (Espesor del muro: #{(w*100).round}cm)"
          }
        }
        mortar_details.each { |k, v| details[k] = v }

        # Aplicar conversión de moneda si es necesario
        total_cost, details = apply_currency_conversion(total_cost, details)
        
        [total_cost, details]
      end
      
      ##
      # Calcula el costo del mortero según dosificación
      #
      # @param volume [Float] Volumen de mortero en m³
      # @param dosage_type [String] Tipo de dosificación
      # @param prices [Hash] Precios de materiales
      # @return [Hash] Desglose de materiales del mortero
      #
      def calculate_mortar_cost_details(volume, dosage_type, prices)
        dosage = if defined?(IQuant::Data::DOSAGE_LIBRARY)
          IQuant::Data::DOSAGE_LIBRARY[dosage_type]
        else
          nil
        end
        
        return {} unless dosage

        details = {}
        
        # Cemento
        if dosage['cement_kg_per_m3'] && prices['cement_per_bag']
          cement_kg = volume * dosage['cement_kg_per_m3']
          bag_weight = prices['bag_weight'].to_f
          cement_bags = (cement_kg / bag_weight).ceil
          cement_cost = cement_bags * prices['cement_per_bag'].to_f
          
          details['cement'] = {
            quantity: cement_bags,
            unit: "bolsas (#{bag_weight}kg)",
            cost: cement_cost
          }
        end

        # Arena
        if dosage['sand_m3_per_m3'] && prices['sand_per_m3']
          sand_m3 = volume * dosage['sand_m3_per_m3']
          sand_cost = sand_m3 * prices['sand_per_m3'].to_f
          
          details['sand'] = {
            quantity: sand_m3,
            unit: 'm³',
            cost: sand_cost
          }
        end

        # Grava (solo para hormigón)
        if dosage['gravel_m3_per_m3'] && prices['gravel_per_m3']
          gravel_m3 = volume * dosage['gravel_m3_per_m3']
          gravel_cost = gravel_m3 * prices['gravel_per_m3'].to_f
          
          details['gravel'] = {
            quantity: gravel_m3,
            unit: 'm³',
            cost: gravel_cost
          }
        end

        # Agua
        if dosage['water_l_per_m3'] && prices['water_per_m3']
          water_m3 = volume * dosage['water_l_per_m3'] / 1000.0
          water_cost = water_m3 * prices['water_per_m3'].to_f
          
          details['water'] = {
            quantity: water_m3,
            unit: 'm³',
            cost: water_cost
          }
        end

        details
      end
      
      ##
      # Calcula el costo de masa sólida (hormigón/mortero)
      #
      # @param volume [Float] Volumen en pulgadas cúbicas
      # @param rule [Hash] Regla de masa sólida
      # @param unit_factor [Float] Factor de conversión de unidades
      # @return [Array<Float, Hash>] Tupla con costo total y detalles
      #
      def calculate_solid_cost_with_details(volume, rule, unit_factor)
        volume_m3 = volume * (unit_factor ** 3)
        dosage_type = rule[:dosage_type]
        
        if dosage_type == 'custom'
          # Validar regla de sólido personalizado
          validation = if defined?(IQuant::Utils::Validator)
            IQuant::Utils::Validator.validate_solid_rule(rule)
          else
            { errors: [] }
          end
          
          unless validation[:errors].empty?
            IQuant::Utils::Logger.log("Invalid solid rule: #{validation[:errors].join(', ')}", :error) if defined?(IQuant::Utils::Logger)
            return [0.0, {}]
          end
          
          # Precio personalizado por m³
          cost = volume_m3 * rule[:value].to_f
          details = { 
            'solid_mass' => { 
              quantity: volume_m3, 
              unit: 'm³', 
              cost: cost 
            } 
          }
          
          # Aplicar conversión de moneda si es necesario
          cost, details = apply_currency_conversion(cost, details)
          
          [cost, details]
        else
          # Dosificación predefinida
          details = calculate_mortar_cost_details(
            volume_m3, 
            dosage_type, 
            rule[:material_prices]
          )
          cost = details.values.sum { |d| d[:cost] }
          
          # Aplicar conversión de moneda si es necesario
          cost, details = apply_currency_conversion(cost, details)
          
          [cost, details]
        end
      end
      
      ##
      # Calcula el costo de material de relleno por volumen (m³)
      #
      # @param volume [Float] Volumen en pulgadas cúbicas
      # @param rule [Hash] Regla de relleno
      # @param unit_factor [Float] Factor de conversión de unidades
      # @return [Array<Float, Hash>] Tupla con costo total y detalles
      #
      def calculate_fill_cost_with_details(volume, rule, unit_factor)
        # Validar regla de material de relleno
        validation = if defined?(IQuant::Utils::Validator)
          IQuant::Utils::Validator.validate_fill_material_rule(rule)
        else
          { errors: [] }
        end
        
        unless validation[:errors].empty?
          IQuant::Utils::Logger.log("Invalid fill material rule: #{validation[:errors].join(', ')}", :error) if defined?(IQuant::Utils::Logger)
          return [0.0, {}]
        end
        
        # Convertir volumen a m³
        volume_m3 = volume * (unit_factor ** 3)
        
        # Precio por m³
        price_per_m3 = rule[:price_per_m3].to_f
        
        # Costo total
        total_cost = volume_m3 * price_per_m3
        
        details = {
          rule[:item_name] || 'fill_material' => {
            quantity: volume_m3,
            unit: 'm³',
            cost: total_cost,
            info: "Volumen de relleno: #{volume_m3.round(3)} m³"
          }
        }
        
        # Aplicar conversión de moneda si es necesario
        total_cost, details = apply_currency_conversion(total_cost, details)
        
        [total_cost, details]
      end
      
      # ==========================================================================
      # CONVERSIÓN DE MONEDA (NUEVO MÉTODO)
      # ==========================================================================
      
      ##
      # Aplica conversión de moneda al costo y detalles si es necesario
      #
      # @param cost [Float] Costo en moneda base
      # @param details [Hash] Detalles del costo
      # @return [Array<Float, Hash>] Costo y detalles convertidos
      #
      def apply_currency_conversion(cost, details)
        # Verificar si hay monedas configuradas
        return [cost, details] unless IQuant.display_currency && IQuant.base_currency
        
        # Si la moneda de visualización es diferente a la base, convertir
        unless IQuant.display_currency == IQuant.base_currency
          IQuant::Utils::ErrorHandler.safe_execute('Currency Conversion in Cost Calculator') do
            # Convertir costo total
            converted_cost = IQuant::Core::CurrencyConverter.convert(
              cost, 
              IQuant.base_currency, 
              IQuant.display_currency
            )
            
            # Convertir cada detalle de material si tiene costo
            converted_details = {}
            details.each do |item_name, detail|
              converted_detail = detail.dup
              
              if detail[:cost] && detail[:cost] > 0
                converted_detail[:cost] = IQuant::Core::CurrencyConverter.convert(
                  detail[:cost],
                  IQuant.base_currency,
                  IQuant.display_currency
                )
              end
              
              # Agregar información de moneda original si es diferente
              if IQuant.base_currency != IQuant.display_currency
                converted_detail[:original_currency] = IQuant.base_currency
                converted_detail[:original_cost] = detail[:cost] if detail[:cost]
              end
              
              converted_details[item_name] = converted_detail
            end
            
            IQuant::Utils::Logger.log("Costos convertidos de #{IQuant.base_currency} a #{IQuant.display_currency}", :debug) if defined?(IQuant::Utils::Logger)
            
            return [converted_cost, converted_details]
          end
        end
        
        # Si no hay conversión necesaria o hubo error, retornar original
        [cost, details]
      end
      
      # ==========================================================================
      # GESTIÓN DE REGLAS
      # ==========================================================================
      
      ##
      # Guarda una regla de costo en el diccionario de atributos
      #
      # @param target [String] Objetivo (capa o material)
      # @param dict_name [String] Nombre del diccionario
      # @param type [String] Tipo de regla ('vol', 'area', 'len', 'unit')
      # @param value [Float] Valor base de la regla
      # @param extra [Hash] Parámetros adicionales
      # @return [Boolean] True si se guardó correctamente
      #
      def save_rule(target, dict_name, type, value, extra = {})
        return false if target.nil? || target.to_s.strip.empty?
        
        # Validar tipo de regla
        unless defined?(IQuant::Utils::Validator) && IQuant::Utils::Validator.validate_rule_type(type)
          IQuant::Utils::Logger.log("Invalid rule type: #{type}", :error) if defined?(IQuant::Utils::Logger)
          return false
        end
        
        # Validar valor
        unless defined?(IQuant::Utils::Validator) && IQuant::Utils::Validator.validate_positive_float(value, allow_zero: true)
          IQuant::Utils::Logger.log("Invalid rule value: #{value}", :error) if defined?(IQuant::Utils::Logger)
          return false
        end
        
        # Validar método de cálculo si existe
        calc_method = extra[:calc_method]
        if calc_method && defined?(IQuant::Utils::Validator) && !IQuant::Utils::Validator.validate_calc_method(calc_method)
          IQuant::Utils::Logger.log("Invalid calculation method: #{calc_method}", :error) if defined?(IQuant::Utils::Logger)
          return false
        end
        
        # Validar regla completa
        rule_data = { type: type, value: value }.merge(extra)
        validation = if defined?(IQuant::Utils::Validator)
          IQuant::Utils::Validator.validate_rule(rule_data)
        else
          { valid: true, errors: [], warnings: [] }
        end
        
        unless validation[:valid]
          error_msg = if defined?(IQuant::Utils::Validator)
            IQuant::Utils::Validator.format_validation_errors(validation)
          else
            "Validation failed"
          end
          IQuant::Utils::Logger.log("Rule validation failed:\n#{error_msg}", :error) if defined?(IQuant::Utils::Logger)
          return false
        end
        
        # Mostrar advertencias si existen
        unless validation[:warnings].empty?
          validation[:warnings].each do |warning|
            IQuant::Utils::Logger.log("Rule warning: #{warning}", :warn) if defined?(IQuant::Utils::Logger)
          end
        end
        
        begin
          model = Sketchup.active_model
          dict = model.attribute_dictionary(dict_name, true)

          data = { 'type' => type, 'value' => value.to_f }
          data.merge!(extra) unless extra.empty?

          dict[target] = data.to_json

          IQuant::Utils::Logger.log("Regla guardada: #{target} → #{type}: #{value}", :info) if defined?(IQuant::Utils::Logger)
          return true
        rescue => e
          IQuant::Utils::Logger.log("Error guardando regla: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
          return false
        end
      end
      
      ##
      # Elimina una regla guardada
      #
      # @param target [String] Nombre de la regla (capa o material)
      # @param dict_name [String] Nombre del diccionario
      # @return [Boolean] True si se eliminó correctamente
      #
      def delete_rule(target, dict_name)
        return false if target.nil? || target.to_s.strip.empty?
        
        begin
          model = Sketchup.active_model
          dict = model.attribute_dictionary(dict_name)
          return false unless dict
          
          unless dict[target]
            IQuant::Utils::Logger.log("Regla no encontrada: #{target}", :warn) if defined?(IQuant::Utils::Logger)
            return false
          end
          
          dict.delete_attribute(target)
          
          IQuant::Utils::Logger.log("Regla eliminada: #{target}", :info) if defined?(IQuant::Utils::Logger)
          return true
        rescue => e
          IQuant::Utils::Logger.log("Error eliminando regla: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
          return false
        end
      end
      
      ##
      # Obtiene una regla específica
      #
      # @param layer [String] Nombre de la capa
      # @param mat [String] Nombre del material
      # @param dict_name [String] Nombre del diccionario
      # @return [Hash, nil] Regla encontrada o nil
      #
      def get_rule(layer, mat, dict_name)
        model = Sketchup.active_model
        dict = model.attribute_dictionary(dict_name)
        return nil unless dict

        # Prioridad: Capa > Material
        json = dict[layer] || dict[mat]
        return nil unless json

        begin
          rule = JSON.parse(json, symbolize_names: true)
          
          # Validar la regla obtenida
          validation = if defined?(IQuant::Utils::Validator)
            IQuant::Utils::Validator.validate_rule(rule)
          else
            { valid: true, errors: [] }
          end
          
          unless validation[:valid]
            IQuant::Utils::Logger.log("Invalid rule found in dictionary: #{validation[:errors].join(', ')}", :warn) if defined?(IQuant::Utils::Logger)
            return nil
          end
          
          rule
        rescue => e
          IQuant::Utils::Logger.log("Error parseando regla: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
          nil
        end
      end
      
      ##
      # Lista todas las reglas guardadas
      #
      # @param dict_name [String] Nombre del diccionario
      # @return [Hash] Hash con todas las reglas
      #
      def list_rules(dict_name)
        model = Sketchup.active_model
        dict = model.attribute_dictionary(dict_name)
        return {} unless dict
        
        rules = {}
        dict.each_pair do |key, value|
          begin
            rule = JSON.parse(value)
            
            # Validar cada regla
            validation = if defined?(IQuant::Utils::Validator)
              IQuant::Utils::Validator.validate_rule(rule)
            else
              { valid: true, errors: [] }
            end
            
            if validation[:valid]
              rules[key] = rule
            else
              IQuant::Utils::Logger.log("Skipping invalid rule #{key}: #{validation[:errors].join(', ')}", :warn) if defined?(IQuant::Utils::Logger)
            end
          rescue => e
            IQuant::Utils::Logger.log("Error parseando regla #{key}: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
          end
        end
        
        rules
      end
      
      ##
      # Exporta reglas a un archivo JSON
      #
      # @param dict_name [String] Nombre del diccionario
      # @param filepath [String] Ruta del archivo de destino
      # @return [Boolean] True si se exportó correctamente
      #
      def export_rules(dict_name, filepath)
        rules = list_rules(dict_name)
        File.write(filepath, JSON.pretty_generate(rules))
        IQuant::Utils::Logger.log("Reglas exportadas: #{filepath}", :info) if defined?(IQuant::Utils::Logger)
        true
      rescue => e
        IQuant::Utils::Logger.log("Error exportando reglas: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
        false
      end
      
      ##
      # Importa reglas desde un archivo JSON
      #
      # @param dict_name [String] Nombre del diccionario
      # @param filepath [String] Ruta del archivo de origen
      # @return [Boolean] True si se importó correctamente
      #
      def import_rules(dict_name, filepath)
        json_content = File.read(filepath)
        rules = JSON.parse(json_content)
        
        # Validar cada regla antes de importar
        invalid_count = 0
        rules.each do |target, rule_data|
          validation = if defined?(IQuant::Utils::Validator)
            IQuant::Utils::Validator.validate_rule(rule_data)
          else
            { valid: true, errors: [] }
          end
          
          unless validation[:valid]
            IQuant::Utils::Logger.log("Skipping invalid rule #{target}: #{validation[:errors].join(', ')}", :warn) if defined?(IQuant::Utils::Logger)
            invalid_count += 1
            rules.delete(target)
          end
        end
        
        model = Sketchup.active_model
        dict = model.attribute_dictionary(dict_name, true)
        
        count = 0
        rules.each do |target, rule_data|
          dict[target] = rule_data.to_json
          count += 1
        end
        
        IQuant::Utils::Logger.log("#{count} reglas importadas desde: #{filepath}", :info) if defined?(IQuant::Utils::Logger)
        IQuant::Utils::Logger.log("#{invalid_count} reglas inválidas omitidas", :warn) if invalid_count > 0 && defined?(IQuant::Utils::Logger)
        true
      rescue => e
        IQuant::Utils::Logger.log("Error importando reglas: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
        false
      end
      
      # ==========================================================================
      # UTILIDADES
      # ==========================================================================
      
      ##
      # Obtiene capas y materiales disponibles en el modelo
      #
      # @return [Hash] Hash con arrays de capas y materiales
      #
      def get_layers_and_materials
        model = Sketchup.active_model
        
        layers = []
        model.layers.each { |layer| layers << layer.name }
        
        materials = []
        model.materials.each { |mat| materials << mat.display_name }
        
        { layers: layers, materials: materials }
      end
      
      ##
      # Valida los datos de una regla antes de guardar
      #
      # @param type [String] Tipo de regla
      # @param value [Float] Valor
      # @param extra [Hash] Datos extra
      # @return [Hash] Resultado de validación
      #
      def validate_rule_data(type, value, extra = {})
        rule_data = { type: type, value: value }.merge(extra)
        
        if defined?(IQuant::Utils::Validator)
          IQuant::Utils::Validator.validate_rule(rule_data)
        else
          { valid: true, errors: [], warnings: [] }
        end
      end
      
      ##
      # Genera un reporte de todas las reglas
      #
      # @param dict_name [String] Nombre del diccionario
      # @return [String] Reporte formateado
      #
      def generate_rules_report(dict_name)
        rules = list_rules(dict_name)
        
        # Obtener moneda para formatear
        display_currency = IQuant.display_currency || IQuant.base_currency || 'USD'
        
        report = []
        report << "=" * 80
        report << "REPORTE DE REGLAS DE COSTO - iQuant v#{IQuant::PLUGIN_VERSION}"
        report << "=" * 80
        report << ""
        report << "Total de reglas: #{rules.size}"
        report << "Fecha: #{Time.now.strftime('%Y-%m-%d %H:%M:%S')}"
        report << "Moneda: #{display_currency}"
        report << ""
        
        # Agrupar por tipo
        by_type = rules.group_by { |_, r| r['type'] }
        
        by_type.each do |type, type_rules|
          type_name = case type
                      when 'vol' then 'Por Volumen'
                      when 'area' then 'Por Área'
                      when 'len' then 'Por Longitud'
                      when 'unit' then 'Por Unidad'
                      else 'Desconocido'
                      end
          
          report << "-" * 80
          report << "#{type_name} (#{type_rules.size} reglas)"
          report << "-" * 80
          
          type_rules.each do |target, rule|
            method = rule['calc_method'] || 'simple'
            value = rule['value'] || 0
            
            # Formatear valor con símbolo de moneda
            formatted_value = IQuant::Core::CurrencyConverter.format_currency(value, display_currency)
            
            report << "  • #{target}"
            report << "    Método: #{method}"
            report << "    Valor: #{formatted_value}"
            
            if method == 'masonry'
              report << "    Bloque: #{rule['brick_length']}×#{rule['brick_width']}×#{rule['brick_thickness']} cm"
            elsif method == 'solid'
              report << "    Dosificación: #{rule['dosage_type']}"
            end
            
            report << ""
          end
        end
        
        report << "=" * 80
        
        report.join("\n")
      end
      
    end
  end
end
