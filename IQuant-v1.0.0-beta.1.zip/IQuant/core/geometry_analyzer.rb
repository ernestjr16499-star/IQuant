# encoding: UTF-8
# core/geometry_analyzer.rb
# Analizador de geometría avanzado para iQuant v4.1

module IQuant
  module Core
    module GeometryAnalyzer
      extend self

      # Tolerancia para cálculos geométricos (en pulgadas)
      TOLERANCE = 0.001
      
      # ==========================================================================
      # MÉTODO PRINCIPAL: ANALIZAR ENTIDAD
      # ==========================================================================

      ##
      # Devuelve un hash con propiedades geométricas avanzadas
      # @param entity [Sketchup::Entity] Entidad a analizar
      # @return [Hash, nil] Datos de análisis o nil si no se puede analizar
      #
      def analyze_entity(entity)
        return nil unless entity && valid_geometry?(entity)

        # Dimensiones del Bounding Box (BB)
        bb = entity.bounds
        dims = [bb.width, bb.height, bb.depth].sort
        
        # Volumen real vs Volumen del BB
        real_volume = IQuant::Core::Calculator.calculate_volume(entity) rescue 0
        bb_volume = dims[0] * dims[1] * dims[2]
        
        # Factor de eficiencia
        efficiency = bb_volume > 0 ? (real_volume / bb_volume) : 0

        # Detección de espesor inteligente
        thickness = detect_smart_thickness(entity, dims[0], efficiency)

        # Clasificación de topología
        entity_type = classify_topology(entity, dims)

        {
          type: entity_type,
          thickness: thickness,
          is_manifold: is_manifold?(entity),
          orientation: determine_orientation(entity),
          efficiency: efficiency,
          dims: dims,
          bounding_box: {
            width: bb.width,
            height: bb.height,
            depth: bb.depth,
            volume: bb_volume
          }
        }
      rescue => e
        IQuant::Utils::ErrorHandler.safe_execute("Analyze Entity") do
          IQuant::Utils::Logger.warn("Error analyzing entity #{entity.entityID}: #{e.message}") if defined?(IQuant::Utils::Logger)
        end
        nil
      end

      # ==========================================================================
      # DETECCIÓN INTELIGENTE DE ESPESOR
      # ==========================================================================

      ##
      # Detecta el espesor real de una pared (no solo la dimensión mínima del BB)
      # @param entity [Sketchup::Entity] Entidad a analizar
      # @param min_bb_dim [Float] Dimensión mínima del bounding box
      # @param efficiency [Float] Factor de eficiencia volumétrica
      # @return [Float] Espesor detectado
      #
      def detect_smart_thickness(entity, min_bb_dim, efficiency)
        # 1. Si la geometría es una caja casi perfecta (eff > 0.9)
        return min_bb_dim if efficiency > 0.9

        # 2. Usar raytracing para geometrías irregulares
        raytrace_thickness = calculate_thickness_by_raytest(entity)
        
        # Si el raytracing falla, usar el BB como fallback
        raytrace_thickness > TOLERANCE ? raytrace_thickness : min_bb_dim
      end

      ##
      # Calcula espesor usando raytracing
      # @param entity [Sketchup::Entity] Entidad a analizar
      # @return [Float] Espesor calculado por raytracing (0.0 si falla)
      #
      def calculate_thickness_by_raytest(entity)
        return 0.0 unless entity.respond_to?(:definition)
        
        definition = entity.definition
        faces = definition.entities.grep(Sketchup::Face)
        return 0.0 if faces.empty?

        samples = []
        model = Sketchup.active_model
        
        # Transformación global de la entidad
        trans = entity.transformation

        # Muestrear hasta 10 caras aleatorias
        sample_faces = faces.size > 10 ? faces.sample(10) : faces
        
        sample_faces.each do |face|
          # Centro de la cara local
          local_center = face.bounds.center
          # Normal local invertida (hacia adentro del objeto)
          local_vector = face.normal.reverse

          # Convertir a coordenadas globales
          global_center = local_center.transform(trans)
          global_vector = local_vector.transform(trans)

          # Pequeño offset para no chocar con la propia cara de inicio
          start_point = global_center.offset(global_vector, 0.01)

          # Disparar rayo
          hit = model.raytest(start_point, global_vector)

          if hit
            hit_point = hit.first
            dist = start_point.distance(hit_point)
            
            # Filtros de distancia razonable
            if dist > 0.1 && dist < 118 # < 3 metros
              samples << dist
            end
          end
        end

        return 0.0 if samples.empty?

        # Retornar la mediana para evitar outliers
        sorted = samples.sort
        median = sorted[sorted.length / 2]
        
        # Ajustar offset inicial
        median + 0.01
      rescue => e
        IQuant::Utils::Logger.debug("Raytest failed: #{e.message}") if defined?(IQuant::Utils::Logger)
        0.0
      end

      # ==========================================================================
      # CLASIFICACIÓN DE TOPOLOGÍA
      # ==========================================================================

      ##
      # Clasifica la topología de la entidad
      # @param entity [Sketchup::Entity] Entidad a clasificar
      # @param dims [Array<Float>] Dimensiones ordenadas [min, mid, max]
      # @return [String] Tipo: 'wall', 'column', 'slab', 'beam', 'generic'
      #
      def classify_topology(entity, dims)
        min, mid, max = dims

        # Ratios de forma
        slenderness = max / (min + TOLERANCE)
        flatness = mid / (min + TOLERANCE)
        
        orientation = determine_orientation(entity)

        case orientation
        when :vertical
          if slenderness > 5 && flatness < 3
            'column'
          elsif slenderness > 3 && flatness > 5
            'wall'
          else
            'generic'
          end
        when :horizontal
          if slenderness > 5 && flatness < 3
            'beam'
          elsif slenderness > 3 && flatness > 5
            'slab'
          else
            'generic'
          end
        else
          'generic'
        end
      end

      # ==========================================================================
      # UTILIDADES GEOMÉTRICAS
      # ==========================================================================

      ##
      # Verifica si la entidad es una geometría válida para análisis
      # @param entity [Sketchup::Entity] Entidad a verificar
      # @return [Boolean] True si es válida
      #
      def valid_geometry?(entity)
        entity.is_a?(Sketchup::Group) || entity.is_a?(Sketchup::ComponentInstance)
      end

      ##
      # Verifica si la entidad es manifold (sólida cerrada)
      # @param entity [Sketchup::Entity] Entidad a verificar
      # @return [Boolean] True si es manifold
      #
      def is_manifold?(entity)
        return false unless entity.respond_to?(:definition)
        
        # Método nativo de SketchUp para grupos/componentes
        entity.manifold? rescue false
      end

      ##
      # Determina la orientación principal de la entidad
      # @param entity [Sketchup::Entity] Entidad a analizar
      # @return [Symbol] :vertical, :horizontal, :neutral
      #
      def determine_orientation(entity)
        bb = entity.bounds
        width = bb.width
        depth = bb.depth
        height = bb.height

        # Si la altura es la dimensión dominante
        if height > width * 1.5 && height > depth * 1.5
          return :vertical
        end

        # Si la altura es pequeña comparada con las otras
        if height < width * 0.5 && height < depth * 0.5
          return :horizontal
        end

        :neutral
      end

      ##
      # Calcula el área proyectada en el plano XY (para techos/losas)
      # @param entity [Sketchup::Entity] Entidad a analizar
      # @return [Float] Área proyectada
      #
      def projected_area_z(entity)
        return 0.0 unless valid_geometry?(entity)
        
        area = 0.0
        trans = entity.transformation
        
        entity.definition.entities.grep(Sketchup::Face).each do |face|
          # Normal global
          normal = face.normal.transform(trans)
          
          # Solo caras que miran hacia arriba o abajo
          dot = normal.z.abs
          
          # Área proyectada = Área Real * |cos(theta)|
          area += face.area * dot * 0.5 # x0.5 porque sumamos caras de arriba y abajo
        end
        
        area
      rescue => e
        IQuant::Utils::Logger.warn("Error calculating projected area: #{e.message}") if defined?(IQuant::Utils::Logger)
        0.0
      end

      ##
      # Calcula el área total de superficie
      # @param entity [Sketchup::Entity] Entidad a analizar
      # @return [Float] Área total
      #
      def total_surface_area(entity)
        return 0.0 unless valid_geometry?(entity)
        
        area = 0.0
        entity.definition.entities.grep(Sketchup::Face).each do |face|
          area += face.area
        end
        
        area
      rescue => e
        IQuant::Utils::Logger.warn("Error calculating total surface area: #{e.message}") if defined?(IQuant::Utils::Logger)
        0.0
      end

      ##
      # Detecta el material principal de la entidad
      # @param entity [Sketchup::Entity] Entidad a analizar
      # @return [String, nil] Nombre del material o nil
      #
      def detect_primary_material(entity)
        return nil unless valid_geometry?(entity)
        
        material_counts = Hash.new(0)
        
        entity.definition.entities.grep(Sketchup::Face).each do |face|
          if face.material
            material_counts[face.material.display_name] += face.area
          end
        end
        
        return nil if material_counts.empty?
        
        # Retornar el material con mayor área
        material_counts.max_by { |_, area| area }&.first
      end

    end
  end
end
