# encoding: UTF-8

module IQuant
  module Core
    module UnitConverter
      extend self
      
      # ==========================================================================
      # FACTORES DE CONVERSIÓN (basados en metros)
      # ==========================================================================
      
      LENGTH_FACTORS = {
        # Unidades métricas
        'm'   => 1.0,        # metro (base)
        'cm'  => 0.01,       # centímetro
        'mm'  => 0.001,      # milímetro
        'km'  => 1000.0,     # kilómetro
        
        # Unidades imperiales
        'in'  => 0.0254,     # pulgada
        'ft'  => 0.3048,     # pie
        'yd'  => 0.9144,     # yarda
        'mi'  => 1609.344    # milla
      }.freeze
      
      # ==========================================================================
      # MÉTODO PRINCIPAL DE CONVERSIÓN
      # ==========================================================================
      
      ##
      # Convierte un valor entre unidades
      #
      # @param value [Numeric] Valor a convertir
      # @param from_unit [String] Unidad de origen
      # @param to_unit [String] Unidad de destino
      # @param type [Symbol] Tipo de conversión (:longitud, :area, :volumen)
      # @return [Numeric] Valor convertido
      #
      def convert(value, from_unit, to_unit, type)
        safe_execute("Convertir unidad: #{value} #{from_unit} → #{to_unit} (#{type})") do
          # Validar parámetros
          validate_parameters(value, from_unit, to_unit, type)
          
          # Si las unidades son iguales, retornar el mismo valor
          return value.to_f if from_unit == to_unit
          
          # Obtener factores de conversión
          from_factor = get_conversion_factor(from_unit, type)
          to_factor = get_conversion_factor(to_unit, type)
          
          # Realizar conversión
          value_in_base = value.to_f * from_factor
          converted_value = value_in_base / to_factor
          
          # Redondear para evitar errores de punto flotante
          rounded_value = round_for_precision(converted_value)
          
          log_conversion(value, from_unit, to_unit, type, rounded_value)
          
          rounded_value
        end
      end
      
      # ==========================================================================
      # MÉTODOS DE CONVERSIÓN CONVENCIONALES
      # ==========================================================================
      
      ##
      # Convierte unidades de longitud
      #
      def convert_length(value, from_unit, to_unit)
        convert(value, from_unit, to_unit, :longitud)
      end
      
      ##
      # Convierte unidades de área
      #
      def convert_area(value, from_unit, to_unit)
        convert(value, from_unit, to_unit, :area)
      end
      
      ##
      # Convierte unidades de volumen
      #
      def convert_volume(value, from_unit, to_unit)
        convert(value, from_unit, to_unit, :volumen)
      end
      
      # ==========================================================================
      # MÉTODOS AUXILIARES
      # ==========================================================================
      
      ##
      # Obtiene el factor de conversión para una unidad y tipo
      #
      def get_conversion_factor(unit, type)
        case type
        when :longitud
          LENGTH_FACTORS[unit.downcase] || raise(ArgumentError, "Unidad de longitud desconocida: #{unit}")
        when :area
          factor = LENGTH_FACTORS[unit.gsub(/²|2/, '').downcase] || 
                   LENGTH_FACTORS[unit.gsub('sq_', '').downcase]
          factor ||= LENGTH_FACTORS[unit.downcase]  # Intentar sin modificar
          factor || raise(ArgumentError, "Unidad de área desconocida: #{unit}")
          factor ** 2  # Área es longitud^2
        when :volumen
          factor = LENGTH_FACTORS[unit.gsub(/³|3/, '').downcase] || 
                   LENGTH_FACTORS[unit.gsub('cu_', '').downcase]
          factor ||= LENGTH_FACTORS[unit.downcase]  # Intentar sin modificar
          factor || raise(ArgumentError, "Unidad de volumen desconocida: #{unit}")
          factor ** 3  # Volumen es longitud^3
        else
          raise ArgumentError, "Tipo de conversión desconocido: #{type}"
        end
      end
      
      ##
      # Valida los parámetros de entrada
      #
      def validate_parameters(value, from_unit, to_unit, type)
        raise ArgumentError, "El valor debe ser numérico" unless value.is_a?(Numeric)
        raise ArgumentError, "from_unit no puede estar vacío" if from_unit.nil? || from_unit.empty?
        raise ArgumentError, "to_unit no puede estar vacío" if to_unit.nil? || to_unit.empty?
        
        valid_types = [:longitud, :area, :volumen]
        unless valid_types.include?(type)
          raise ArgumentError, "Tipo debe ser uno de: #{valid_types.join(', ')}"
        end
        
        # Verificar que las unidades son conocidas (solo advertencia)
        begin
          get_conversion_factor(from_unit, type)
          get_conversion_factor(to_unit, type)
        rescue ArgumentError => e
          log_warning("Unidad no reconocida en validación: #{e.message}")
        end
      end
      
      ##
      # Redondea el valor para evitar errores de punto flotante
      #
      def round_for_precision(value, precision = 10)
        # Redondear a 10 decimales para la mayoría de los casos
        (value * 10**precision).round.to_f / 10**precision
      end
      
      ##
      # Registra la conversión en el log
      #
      def log_conversion(value, from_unit, to_unit, type, result)
        if defined?(IQuant::Utils::Logger)
          IQuant::Utils::Logger.log(
            "UnitConverter: #{value} #{from_unit} (#{type}) → #{result} #{to_unit}",
            :debug
          )
        end
      end
      
      ##
      # Registra una advertencia
      #
      def log_warning(message)
        if defined?(IQuant::Utils::Logger)
          IQuant::Utils::Logger.log("UnitConverter: #{message}", :warn)
        end
      end
      
      ##
      # Ejecución segura con manejo de errores
      #
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          begin
            yield
          rescue => e
            log_warning("Error en #{operation}: #{e.message}")
            raise e
          end
        end
      end
      
      # ==========================================================================
      # CONSTANTES PÚBLICAS PARA USO EXTERNO
      # ==========================================================================
      
      ##
      # Lista de unidades de longitud soportadas
      #
      SUPPORTED_LENGTH_UNITS = LENGTH_FACTORS.keys.sort.freeze
      
      ##
      # Lista de unidades de área soportadas (derivadas de longitud)
      #
      SUPPORTED_AREA_UNITS = LENGTH_FACTORS.keys.map { |u| "#{u}²" }.sort.freeze
      
      ##
      # Lista de unidades de volumen soportadas (derivadas de longitud)
      #
      SUPPORTED_VOLUME_UNITS = LENGTH_FACTORS.keys.map { |u| "#{u}³" }.sort.freeze
      
      ##
      # Todas las unidades soportadas
      #
      SUPPORTED_UNITS = {
        longitud: SUPPORTED_LENGTH_UNITS,
        area: SUPPORTED_AREA_UNITS,
        volumen: SUPPORTED_VOLUME_UNITS
      }.freeze
      
      ##
      # Verifica si una unidad es soportada para un tipo dado
      #
      def unit_supported?(unit, type)
        case type
        when :longitud
          LENGTH_FACTORS.key?(unit.downcase)
        when :area
          base_unit = unit.gsub(/²|2/, '').downcase
          LENGTH_FACTORS.key?(base_unit)
        when :volumen
          base_unit = unit.gsub(/³|3/, '').downcase
          LENGTH_FACTORS.key?(base_unit)
        else
          false
        end
      end
      
      ##
      # Obtiene todas las unidades soportadas para un tipo
      #
      def get_supported_units(type)
        SUPPORTED_UNITS[type] || []
      end
      
    end
  end
end
