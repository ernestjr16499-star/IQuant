# core/geometry_helper.rb
# Helper para cálculos geométricos - creado desde cero para iQuant v4.1

module IQuant
  module Core
    module GeometryHelper
      extend self
      
      # ==========================================================================
      # CÁLCULO DE VOLUMEN PARA CARAS EXTRUDIDAS
      # ==========================================================================
      
      ##
      # Calcula el volumen de una cara extrudida una profundidad dada
      #
      # @param face [Sketchup::Face] La cara de SketchUp
      # @param depth [Float] Profundidad de extrusión (en las unidades del modelo)
      # @return [Float] Volumen calculado (valor absoluto, siempre positivo)
      #
      def calculate_volume(face, depth)
        return 0.0 unless valid_face?(face)
        
        begin
          # Calcular el área de la cara
          area = calculate_area(face)
          
          # El volumen es área × profundidad (usar valor absoluto)
          volume = area * depth.abs
          
          # Log opcional
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.log("Calculated extruded volume: #{volume} for face #{face.entityID} (depth: #{depth})", :debug)
          end
          
          volume
        rescue => e
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.log("Error calculating extruded volume: #{e.message}", :error)
            IQuant::Utils::Logger.log("Backtrace: #{e.backtrace.first(5).join(', ')}", :debug) if defined?(IQuant::DEBUG_MODE) && IQuant::DEBUG_MODE
          end
          0.0
        end
      end
      
      ##
      # Calcula el volumen de un tetraedro formado por tres puntos y el origen
      # Método auxiliar para cálculos de volumen complejos
      #
      # @param p1 [Geom::Point3d] Primer punto
      # @param p2 [Geom::Point3d] Segundo punto
      # @param p3 [Geom::Point3d] Tercer punto
      # @return [Float] Volumen del tetraedro (con signo)
      #
      def calculate_tetrahedron_volume(p1, p2, p3)
        begin
          # V = |a·(b×c)| / 6, donde a, b, c son vectores desde el origen
          a = Geom::Vector3d.new(0, 0, 0, p1)
          b = Geom::Vector3d.new(0, 0, 0, p2)
          c = Geom::Vector3d.new(0, 0, 0, p3)
          
          cross_product = b.cross(c)
          scalar_triple = a.dot(cross_product)
          
          volume = scalar_triple / 6.0
          volume
        rescue => e
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.log("Error calculating tetrahedron volume: #{e.message}", :error)
          end
          0.0
        end
      end
      
      # ==========================================================================
      # CÁLCULO DE ÁREA
      # ==========================================================================
      
      ##
      # Calcula el área de una cara
      #
      # @param face [Sketchup::Face] La cara de SketchUp
      # @return [Float] Área calculada
      #
      def calculate_area(face)
        return 0.0 unless valid_face?(face)
        
        begin
          # Usar el método nativo de SketchUp si está disponible
          area = face.area
          
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.log("Calculated area: #{area} for face #{face.entityID}", :debug)
          end
          
          area
        rescue => e
          # Fallback: calcular área manualmente si face.area falla
          begin
            area = calculate_area_manual(face)
            if defined?(IQuant::Utils::Logger)
              IQuant::Utils::Logger.log("Used manual area calculation for face #{face.entityID}: #{area}", :debug)
            end
            area
          rescue => e2
            if defined?(IQuant::Utils::Logger)
              IQuant::Utils::Logger.log("Error calculating area (manual fallback failed): #{e2.message}", :error)
            end
            0.0
          end
        end
      end
      
      ##
      # Calcula el área de una cara manualmente (fallback)
      #
      # @param face [Sketchup::Face] La cara de SketchUp
      # @return [Float] Área calculada manualmente
      #
      def calculate_area_manual(face)
        return 0.0 unless valid_face?(face)
        
        # Obtener los vértices de la cara
        vertices = get_face_vertices(face)
        return 0.0 if vertices.size < 3
        
        # Calcular área usando el método del producto cruzado (para polígonos simples)
        # Asume que la cara es plana y los vértices están en orden
        area = 0.0
        n = vertices.size
        
        # Método del shoelace en 3D (proyectando al plano de la cara)
        # Primero, obtener la normal de la cara
        normal = get_face_normal(face)
        
        # Elegir el eje dominante para proyección
        if normal[0].abs >= normal[1].abs && normal[0].abs >= normal[2].abs
          # Proyectar en el plano YZ
          (0...n).each do |i|
            j = (i + 1) % n
            area += vertices[i][1] * vertices[j][2] - vertices[i][2] * vertices[j][1]
          end
          area = (area.abs * 0.5) / normal[0].abs
        elsif normal[1].abs >= normal[0].abs && normal[1].abs >= normal[2].abs
          # Proyectar en el plano XZ
          (0...n).each do |i|
            j = (i + 1) % n
            area += vertices[i][2] * vertices[j][0] - vertices[i][0] * vertices[j][2]
          end
          area = (area.abs * 0.5) / normal[1].abs
        else
          # Proyectar en el plano XY (caso más común)
          (0...n).each do |i|
            j = (i + 1) % n
            area += vertices[i][0] * vertices[j][1] - vertices[i][1] * vertices[j][0]
          end
          area = (area.abs * 0.5) / normal[2].abs
        end
        
        area.abs  # Área siempre positiva
      end
      
      # ==========================================================================
      # VECTORES NORMALES
      # ==========================================================================
      
      ##
      # Obtiene el vector normal de una cara
      #
      # @param face [Sketchup::Face] La cara de SketchUp
      # @return [Array<Float>] Vector normal [x, y, z] normalizado
      #
      def get_face_normal(face)
        return [0.0, 0.0, 1.0] unless valid_face?(face)
        
        begin
          # Usar el método nativo de SketchUp
          normal = face.normal
          normal_array = [normal.x, normal.y, normal.z]
          
          # Asegurar que esté normalizado
          length = Math.sqrt(normal_array[0]**2 + normal_array[1]**2 + normal_array[2]**2)
          if length > 0
            normal_array = normal_array.map { |v| v / length }
          end
          
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.log("Got face normal: #{normal_array} for face #{face.entityID}", :debug)
          end
          
          normal_array
        rescue => e
          # Fallback: calcular normal manualmente
          begin
            normal_array = calculate_face_normal_manual(face)
            if defined?(IQuant::Utils::Logger)
              IQuant::Utils::Logger.log("Used manual normal calculation for face #{face.entityID}: #{normal_array}", :debug)
            end
            normal_array
          rescue => e2
            if defined?(IQuant::Utils::Logger)
              IQuant::Utils::Logger.log("Error getting face normal (manual fallback failed): #{e2.message}", :error)
            end
            [0.0, 0.0, 1.0]  # Fallback a vector Z
          end
        end
      end
      
      ##
      # Calcula el vector normal de una cara manualmente (fallback)
      #
      # @param face [Sketchup::Face] La cara de SketchUp
      # @return [Array<Float>] Vector normal [x, y, z] normalizado
      #
      def calculate_face_normal_manual(face)
        return [0.0, 0.0, 1.0] unless valid_face?(face)
        
        vertices = get_face_vertices(face)
        return [0.0, 0.0, 1.0] if vertices.size < 3
        
        # Usar los primeros tres vértices para calcular la normal
        p1 = vertices[0]
        p2 = vertices[1]
        p3 = vertices[2]
        
        # Calcular vectores
        v1 = [p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]]
        v2 = [p3[0] - p1[0], p3[1] - p1[1], p3[2] - p1[2]]
        
        # Producto cruzado: v1 × v2
        normal = [
          v1[1] * v2[2] - v1[2] * v2[1],
          v1[2] * v2[0] - v1[0] * v2[2],
          v1[0] * v2[1] - v1[1] * v2[0]
        ]
        
        # Normalizar
        length = Math.sqrt(normal[0]**2 + normal[1]**2 + normal[2]**2)
        if length > 0
          normal = normal.map { |v| v / length }
        else
          normal = [0.0, 0.0, 1.0]
        end
        
        normal
      end
      
      # ==========================================================================
      # MÉTODOS AUXILIARES
      # ==========================================================================
      
      ##
      # Obtiene los vértices de una cara como array de puntos
      #
      # @param face [Sketchup::Face] La cara de SketchUp
      # @return [Array<Array<Float>>] Array de puntos [x, y, z]
      #
      def get_face_vertices(face)
        return [] unless valid_face?(face)
        
        begin
          vertices = []
          face.vertices.each do |vertex|
            position = vertex.position
            vertices << [position.x, position.y, position.z]
          end
          vertices
        rescue => e
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.log("Error getting face vertices: #{e.message}", :error)
          end
          []
        end
      end
      
      ##
      # Calcula el perímetro de una cara
      #
      # @param face [Sketchup::Face] La cara de SketchUp
      # @return [Float] Perímetro calculado
      #
      def calculate_perimeter(face)
        return 0.0 unless valid_face?(face)
        
        begin
          perimeter = 0.0
          face.edges.each do |edge|
            perimeter += edge.length
          end
          
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.log("Calculated perimeter: #{perimeter} for face #{face.entityID}", :debug)
          end
          
          perimeter
        rescue => e
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.log("Error calculating perimeter: #{e.message}", :error)
          end
          0.0
        end
      end
      
      ##
      # Obtiene el centroide de una cara
      #
      # @param face [Sketchup::Face] La cara de SketchUp
      # @return [Array<Float>] Punto centroide [x, y, z]
      #
      def get_face_centroid(face)
        return [0.0, 0.0, 0.0] unless valid_face?(face)
        
        begin
          # Usar el método nativo si está disponible
          if face.respond_to?(:centroid)
            centroid = face.centroid
            return [centroid.x, centroid.y, centroid.z]
          end
          
          # Fallback: calcular manualmente
          vertices = get_face_vertices(face)
          return [0.0, 0.0, 0.0] if vertices.empty?
          
          sum_x = 0.0
          sum_y = 0.0
          sum_z = 0.0
          
          vertices.each do |v|
            sum_x += v[0]
            sum_y += v[1]
            sum_z += v[2]
          end
          
          count = vertices.size.to_f
          [sum_x / count, sum_y / count, sum_z / count]
        rescue => e
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.log("Error calculating face centroid: #{e.message}", :error)
          end
          [0.0, 0.0, 0.0]
        end
      end
      
      ##
      # Verifica si una cara es válida para cálculos
      #
      # @param face [Sketchup::Face] La cara a verificar
      # @return [Boolean] True si la cara es válida
      #
      def valid_face?(face)
        face && face.is_a?(Sketchup::Face) && !face.deleted?
      end
      
      # ==========================================================================
      # MÉTODOS DE TRANSFORMACIÓN
      # ==========================================================================
      
      ##
      # Transforma una cara aplicando una transformación de SketchUp
      #
      # @param face [Sketchup::Face] La cara original
      # @param transformation [Geom::Transformation] Transformación a aplicar
      # @return [Array<Array<Float>>] Array de vértices transformados
      #
      def transform_face(face, transformation)
        return [] unless valid_face?(face) && transformation
        
        begin
          transformed_vertices = []
          face.vertices.each do |vertex|
            original_point = vertex.position
            transformed_point = original_point.transform(transformation)
            transformed_vertices << [transformed_point.x, transformed_point.y, transformed_point.z]
          end
          transformed_vertices
        rescue => e
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.log("Error transforming face: #{e.message}", :error)
          end
          []
        end
      end
      
      ##
      # Aplica ejecución segura a operaciones geométricas
      #
      # @param operation [String] Nombre de la operación para logging
      # @param block [Proc] Bloque de código a ejecutar
      # @return [Object] Resultado del bloque o nil si falla
      #
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          begin
            yield
          rescue => e
            if defined?(IQuant::Utils::Logger)
              IQuant::Utils::Logger.log("Error in #{operation}: #{e.message}", :error)
            end
            nil
          end
        end
      end
      
    end
  end
end
