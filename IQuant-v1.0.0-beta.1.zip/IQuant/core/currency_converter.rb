# encoding: UTF-8

module IQuant
  module Core
    module CurrencyConverter
      extend self
      
      # ==========================================================================
      # GESTIÓN DE TIPOS DE CAMBIO
      # ==========================================================================
      
      ##
      # Obtiene los tipos de cambio configurados (todos referenciados a USD y EUR)
      #
      # @return [Hash] Tipos de cambio con estructura { 'base' => currency_code, 'USD' => rate, 'EUR' => rate }
      #
      def get_exchange_rates
        IQuant::Utils::ErrorHandler.safe_execute('Get Exchange Rates') do
          model = Sketchup.active_model
          
          base_currency = model.get_attribute(IQuant::PREFS_KEY, "base_currency") || 'USD'
          rate_to_usd = model.get_attribute(IQuant::PREFS_KEY, "rate_to_usd") || 1.0
          rate_to_eur = model.get_attribute(IQuant::PREFS_KEY, "rate_to_eur") || 1.0
          
          {
            'base' => base_currency,
            'USD' => rate_to_usd.to_f,
            'EUR' => rate_to_eur.to_f
          }
        end || { 'base' => 'USD', 'USD' => 1.0, 'EUR' => 1.0 }
      end
      
      ##
      # Obtiene la moneda de visualización configurada
      #
      # @return [String] Código ISO de la moneda de visualización
      #
      def get_display_currency
        IQuant::Utils::ErrorHandler.safe_execute('Get Display Currency') do
          model = Sketchup.active_model
          model.get_attribute(IQuant::PREFS_KEY, "display_currency") || get_exchange_rates['base']
        end || get_exchange_rates['base']
      end
      
      ##
      # Obtiene la moneda base del proyecto
      #
      # @return [String] Código ISO de la moneda base
      #
      def get_base_currency
        get_exchange_rates['base']
      end
      
      ##
      # Establece la moneda base del proyecto y sus tipos de cambio
      #
      # @param currency_code [String] Código ISO de la moneda (ej: 'MXN', 'EUR')
      # @param rate_to_usd [Float] Cuántas unidades de esta moneda = 1 USD
      # @param rate_to_eur [Float] Cuántas unidades de esta moneda = 1 EUR
      # @return [Boolean] True si se guardó correctamente
      #
      def set_base_currency(currency_code, rate_to_usd, rate_to_eur)
        # Verificar que CURRENCIES esté disponible
        unless defined?(IQuant::Data::CURRENCIES)
          IQuant::Utils::Logger.log("CURRENCIES no cargado", :error) if defined?(IQuant::Utils::Logger)
          return false
        end
        
        return false unless IQuant::Data::CURRENCIES.key?(currency_code)
        return false if rate_to_usd.to_f <= 0 || rate_to_eur.to_f <= 0
        
        IQuant::Utils::ErrorHandler.safe_execute('Set Base Currency') do
          model = Sketchup.active_model
          model.set_attribute(IQuant::PREFS_KEY, "base_currency", currency_code)
          model.set_attribute(IQuant::PREFS_KEY, "rate_to_usd", rate_to_usd.to_f)
          model.set_attribute(IQuant::PREFS_KEY, "rate_to_eur", rate_to_eur.to_f)
          
          # Actualizar variable global
          IQuant.base_currency = currency_code
          
          # Log del cambio
          IQuant::Utils::Logger.log("Moneda base establecida: #{currency_code}", :info) if defined?(IQuant::Utils::Logger)
          IQuant::Utils::Logger.log("   1 USD = #{rate_to_usd} #{currency_code}", :info) if defined?(IQuant::Utils::Logger)
          IQuant::Utils::Logger.log("   1 EUR = #{rate_to_eur} #{currency_code}", :info) if defined?(IQuant::Utils::Logger)
          
          # Track analytics si está habilitado
          track_currency_change(currency_code)
          
          return true
        end
        
        false
      rescue => e
        IQuant::Utils::ErrorHandler.handle_error(e, 'Set Base Currency')
        false
      end
      
      ##
      # Establece la moneda de visualización
      #
      # @param currency_code [String] Código ISO de la moneda ('USD', 'EUR', o la base)
      # @return [Boolean] True si se guardó correctamente
      #
      def set_display_currency(currency_code)
        # Verificar que sea una moneda válida o USD/EUR
        valid_currencies = [get_base_currency, 'USD', 'EUR']
        return false unless valid_currencies.include?(currency_code)
        
        IQuant::Utils::ErrorHandler.safe_execute('Set Display Currency') do
          model = Sketchup.active_model
          model.set_attribute(IQuant::PREFS_KEY, "display_currency", currency_code)
          
          # Actualizar variable global
          IQuant.display_currency = currency_code
          
          IQuant::Utils::Logger.log("Moneda de visualización cambiada a: #{currency_code}", :info) if defined?(IQuant::Utils::Logger)
          
          # Track analytics si está habilitado
          if defined?(IQuant::Features::Analytics)
            IQuant::Features::Analytics.track_event('currency_changed', {
              to: currency_code,
              from: IQuant.display_currency
            })
          end
          
          return true
        end
        
        false
      rescue => e
        IQuant::Utils::ErrorHandler.handle_error(e, 'Set Display Currency')
        false
      end
      
      ##
      # Establece los tipos de cambio (para actualización manual)
      #
      # @param usd_rate [Float] Tipo de cambio a USD
      # @param eur_rate [Float] Tipo de cambio a EUR
      # @return [Boolean] True si se guardó correctamente
      #
      def set_exchange_rates(usd_rate, eur_rate)
        return false if usd_rate.to_f <= 0 || eur_rate.to_f <= 0
        
        IQuant::Utils::ErrorHandler.safe_execute('Set Exchange Rates') do
          model = Sketchup.active_model
          model.set_attribute(IQuant::PREFS_KEY, "rate_to_usd", usd_rate.to_f)
          model.set_attribute(IQuant::PREFS_KEY, "rate_to_eur", eur_rate.to_f)
          
          IQuant::Utils::Logger.log("Tipos de cambio actualizados: USD=#{usd_rate}, EUR=#{eur_rate}", :info) if defined?(IQuant::Utils::Logger)
          
          return true
        end
        
        false
      rescue => e
        IQuant::Utils::ErrorHandler.handle_error(e, 'Set Exchange Rates')
        false
      end
      
      # ==========================================================================
      # CONVERSIÓN DE MONEDAS
      # ==========================================================================
      
      ##
      # Convierte un monto de la moneda base a USD o EUR
      #
      # @param amount_base [Float] Monto en moneda base del proyecto
      # @param target_currency [String] 'USD' o 'EUR'
      # @return [Float] Monto convertido
      #
      def convert_to_reference(amount_base, target_currency)
        IQuant::Utils::ErrorHandler.safe_execute('Convert to Reference') do
          rates = get_exchange_rates
          base = rates['base']
          
          # Si la moneda objetivo es la base, no hay conversión
          return amount_base if base == target_currency
          
          # Validar que target_currency sea 'USD' o 'EUR'
          unless ['USD', 'EUR'].include?(target_currency)
            IQuant::Utils::Logger.log("Moneda objetivo no soportada para conversión directa: #{target_currency}", :warn) if defined?(IQuant::Utils::Logger)
            return amount_base
          end
          
          # Convertir usando el tipo de cambio
          case target_currency
          when 'USD'
            amount_base / rates['USD']
          when 'EUR'
            amount_base / rates['EUR']
          else
            amount_base
          end
        end || amount_base # Fallback: retornar monto original en caso de error
      end
      
      ##
      # Convierte un monto a cualquier moneda soportada
      #
      # @param amount_base [Float] Monto en moneda base del proyecto
      # @param target_currency [String] Código ISO de la moneda destino
      # @return [Float] Monto convertido
      #
      def convert_currency(amount_base, target_currency)
        IQuant::Utils::ErrorHandler.safe_execute('Convert Currency') do
          # Validar entrada
          return amount_base if amount_base.nil?
          return 0.0 if amount_base == 0.0
          
          # Validar moneda objetivo
          unless IQuant::Utils::Validator.validate_currency_code(target_currency)
            IQuant::Utils::Logger.log("Código de moneda inválido: #{target_currency}", :error) if defined?(IQuant::Utils::Logger)
            return amount_base
          end
          
          rates = get_exchange_rates
          base = rates['base']
          
          # Si la moneda objetivo es la base, no hay conversión
          return amount_base if target_currency == base
          
          # Si la moneda objetivo es USD o EUR, usar convert_to_reference
          if target_currency == 'USD' || target_currency == 'EUR'
            return convert_to_reference(amount_base, target_currency)
          end
          
          # Para conversiones entre otras monedas, necesitaríamos tasas cruzadas
          # Por ahora, mostrar advertencia y retornar monto base
          IQuant::Utils::Logger.log("Conversión no soportada: #{base} → #{target_currency}", :warn) if defined?(IQuant::Utils::Logger)
          amount_base
        end || amount_base
      end
      
      ##
      # Convierte entre cualquier par de monedas
      #
      # @param amount [Float] Monto a convertir
      # @param from_currency [String] Moneda origen
      # @param to_currency [String] Moneda destino
      # @return [Float] Monto convertido
      #
      def convert(amount, from_currency, to_currency)
        IQuant::Utils::ErrorHandler.safe_execute('Convert Between Currencies') do
          # Validar entradas
          return amount if amount.nil? || amount == 0.0
          
          unless IQuant::Utils::Validator.validate_currency_code(from_currency) &&
                 IQuant::Utils::Validator.validate_currency_code(to_currency)
            IQuant::Utils::Logger.log("Moneda inválida en conversión: #{from_currency} → #{to_currency}", :error) if defined?(IQuant::Utils::Logger)
            return amount
          end
          
          # Si son la misma moneda, retornar mismo monto
          return amount if from_currency == to_currency
          
          # Obtener moneda base del proyecto
          base_currency = get_base_currency
          
          # Convertir desde moneda origen a moneda base
          if from_currency == base_currency
            amount_in_base = amount
          elsif from_currency == 'USD' || from_currency == 'EUR'
            # Moneda origen es referencia, convertir a base
            rates = get_exchange_rates
            if from_currency == 'USD'
              amount_in_base = amount * rates['USD']
            else # EUR
              amount_in_base = amount * rates['EUR']
            end
          else
            # No se puede convertir directamente desde esta moneda
            IQuant::Utils::Logger.log("No se puede convertir desde moneda no base ni referencia: #{from_currency}", :warn) if defined?(IQuant::Utils::Logger)
            return amount
          end
          
          # Convertir desde moneda base a moneda destino
          if to_currency == base_currency
            return amount_in_base
          elsif to_currency == 'USD' || to_currency == 'EUR'
            return convert_to_reference(amount_in_base, to_currency)
          else
            IQuant::Utils::Logger.log("No se puede convertir a moneda no base ni referencia: #{to_currency}", :warn) if defined?(IQuant::Utils::Logger)
            return amount_in_base
          end
        end || amount
      end
      
      ##
      # Formatea un monto con su símbolo de moneda
      #
      # @param amount [Float] Monto a formatear
      # @param currency_code [String] Código ISO de la moneda
      # @param decimals [Integer] Cantidad de decimales (por defecto 2)
      # @return [String] Monto formateado con símbolo
      #
      def format_currency(amount, currency_code, decimals = 2)
        IQuant::Utils::ErrorHandler.safe_execute('Format Currency') do
          return "0.00" if amount.nil?
          
          # Verificar que CURRENCIES esté disponible
          unless defined?(IQuant::Data::CURRENCIES)
            IQuant::Utils::Logger.log("CURRENCIES no cargado", :error) if defined?(IQuant::Utils::Logger)
            return "#{amount.to_f.round(decimals)} #{currency_code}"
          end
          
          currency_data = IQuant::Data::CURRENCIES[currency_code]
          
          if currency_data
            symbol = currency_data[:symbol]
            "#{symbol}#{amount.round(decimals)}"
          else
            "#{amount.round(decimals)} #{currency_code}"
          end
        end || "#{amount.to_f.round(decimals)} #{currency_code}"
      end
      
      ##
      # Obtiene información completa de una moneda
      #
      # @param currency_code [String] Código ISO de la moneda
      # @return [Hash, nil] Datos de la moneda o nil si no existe
      #
      def get_currency_info(currency_code)
        if defined?(IQuant::Data::CURRENCIES)
          IQuant::Data::CURRENCIES[currency_code]
        else
          IQuant::Utils::Logger.log("CURRENCIES no cargado", :error) if defined?(IQuant::Utils::Logger)
          nil
        end
      end
      
      ##
      # Obtiene el símbolo de una moneda
      #
      # @param currency_code [String] Código ISO de la moneda
      # @return [String] Símbolo de la moneda o el código si no se encuentra
      #
      def get_currency_symbol(currency_code)
        if defined?(IQuant::Data::CURRENCIES)
          currency_data = IQuant::Data::CURRENCIES[currency_code]
          currency_data ? currency_data[:symbol] : currency_code
        else
          IQuant::Utils::Logger.log("CURRENCIES no cargado", :error) if defined?(IQuant::Utils::Logger)
          currency_code
        end
      end
      
      ##
      # Obtiene el nombre completo de una moneda
      #
      # @param currency_code [String] Código ISO de la moneda
      # @return [String] Nombre de la moneda
      #
      def get_currency_name(currency_code)
        if defined?(IQuant::Data::CURRENCIES)
          currency_data = IQuant::Data::CURRENCIES[currency_code]
          currency_data ? currency_data[:name] : currency_code
        else
          IQuant::Utils::Logger.log("CURRENCIES no cargado", :error) if defined?(IQuant::Utils::Logger)
          currency_code
        end
      end
      
      ##
      # Lista todas las monedas disponibles ordenadas por país
      #
      # @return [Hash] Hash con códigos de moneda como keys
      #
      def list_currencies
        if defined?(IQuant::Data::CURRENCIES)
          IQuant::Data::CURRENCIES
        else
          IQuant::Utils::Logger.log("CURRENCIES no cargado", :error) if defined?(IQuant::Utils::Logger)
          {}
        end
      end
      
      ##
      # Valida si un código de moneda es válido
      #
      # @param currency_code [String] Código ISO a validar
      # @return [Boolean] True si es válido
      #
      def valid_currency?(currency_code)
        if defined?(IQuant::Data::CURRENCIES)
          IQuant::Data::CURRENCIES.key?(currency_code)
        else
          IQuant::Utils::Logger.log("CURRENCIES no cargado", :error) if defined?(IQuant::Utils::Logger)
          false
        end
      end
      
      # ==========================================================================
      # UTILIDADES
      # ==========================================================================
      
      ##
      # Genera un reporte de conversión de monedas para debugging
      #
      # @param amount [Float] Monto a convertir
      # @return [String] Reporte formateado
      #
      def conversion_report(amount)
        IQuant::Utils::ErrorHandler.safe_execute('Generate Conversion Report') do
          rates = get_exchange_rates
          base = rates['base']
          
          report = []
          report << "=" * 60
          report << "REPORTE DE CONVERSIÓN DE MONEDAS"
          report << "=" * 60
          report << ""
          report << "Monto base: #{format_currency(amount, base)}"
          report << "Moneda base: #{get_currency_name(base)} (#{base})"
          report << ""
          report << "Tipos de cambio:"
          report << "  1 USD = #{rates['USD']} #{base}"
          report << "  1 EUR = #{rates['EUR']} #{base}"
          report << ""
          report << "Conversiones:"
          
          if base != 'USD'
            usd_amount = convert_to_reference(amount, 'USD')
            report << "  USD: #{format_currency(usd_amount, 'USD')}"
          end
          
          if base != 'EUR'
            eur_amount = convert_to_reference(amount, 'EUR')
            report << "  EUR: #{format_currency(eur_amount, 'EUR')}"
          end
          
          # Mostrar moneda de visualización actual si es diferente
          display = get_display_currency
          if display != base
            display_amount = convert_currency(amount, display)
            report << ""
            report << "Moneda de visualización (#{display}): #{format_currency(display_amount, display)}"
          end
          
          report << "=" * 60
          
          report.join("\n")
        end || "Error generando reporte de conversión"
      end
      
      ##
      # Detecta la moneda apropiada según la ubicación del sistema
      #
      # @return [String, nil] Código ISO sugerido o nil
      #
      def suggest_currency_by_locale
        IQuant::Utils::ErrorHandler.safe_execute('Suggest Currency by Locale') do
          locale = Sketchup.get_locale.to_s.downcase
          
          # Mapeo básico de locale a moneda
          case locale
          when /^en_us/ then 'USD'
          when /^en_gb/ then 'GBP'
          when /^en_ca/ then 'CAD'
          when /^en_au/ then 'AUD'
          when /^es_es/ then 'EUR'
          when /^es_mx/ then 'MXN'
          when /^es_ar/ then 'ARS'
          when /^es_cl/ then 'CLP'
          when /^es_co/ then 'COP'
          when /^pt_br/ then 'BRL'
          when /^pt_pt/ then 'EUR'
          when /^fr_fr/ then 'EUR'
          when /^de_de/ then 'EUR'
          when /^it_it/ then 'EUR'
          when /^ru_ru/ then 'RUB'
          when /^zh_cn/ then 'CNY'
          when /^ja_jp/ then 'JPY'
          when /^ko_kr/ then 'KRW'
          else
            'USD' # Por defecto
          end
        end || 'USD'
      end
      
      ##
      # Verifica si la configuración de monedas es válida
      #
      # @return [Hash] Estado de la configuración
      #
      def validate_configuration
        IQuant::Utils::ErrorHandler.safe_execute('Validate Currency Configuration') do
          rates = get_exchange_rates
          base = rates['base']
          
          errors = []
          warnings = []
          
          # Verificar moneda base usando el validador
          unless IQuant::Utils::Validator.validate_currency_code(base)
            errors << "Moneda base inválida: #{base}"
          end
          
          # Verificar tipos de cambio
          unless IQuant::Utils::Validator.validate_positive_float(rates['USD'])
            errors << "Tipo de cambio a USD debe ser positivo"
          end
          
          unless IQuant::Utils::Validator.validate_positive_float(rates['EUR'])
            errors << "Tipo de cambio a EUR debe ser positivo"
          end
          
          # Verificar moneda de visualización
          display = get_display_currency
          unless [base, 'USD', 'EUR'].include?(display)
            warnings << "Moneda de visualización no estándar: #{display}"
          end
          
          {
            valid: errors.empty?,
            errors: errors,
            warnings: warnings,
            base_currency: base,
            rates: rates,
            display_currency: display
          }
        end || {
          valid: false,
          errors: ["Error validando configuración de monedas"],
          warnings: [],
          base_currency: 'USD',
          rates: { 'base' => 'USD', 'USD' => 1.0, 'EUR' => 1.0 },
          display_currency: 'USD'
        }
      end
      
      # ==========================================================================
      # MÉTODOS PRIVADOS
      # ==========================================================================
      
      private
      
      ##
      # Track analytics para cambios de moneda
      #
      def track_currency_change(currency_code)
        return unless defined?(IQuant::Features::Analytics) && 
                      IQuant::Features::Analytics.enabled?
        
        IQuant::Features::Analytics.track_event('base_currency_changed', {
          currency: currency_code,
          usd_rate: IQuant.base_currency ? get_exchange_rates['USD'] : 1.0,
          eur_rate: IQuant.base_currency ? get_exchange_rates['EUR'] : 1.0
        })
      end
      
    end
  end
end
