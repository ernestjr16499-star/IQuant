# encoding: UTF-8

require 'json'

module IQuant
  module Core
    module Calculator
      extend self
      
      # Archivo para caché persistente
      CACHE_FILE ||= File.join(IQuant::PLUGIN_DIR, '.cache.json')
      
      # ==========================================================================
      # GESTIÓN DE CACHÉ PERSISTENTE
      # ==========================================================================

      def load_cache
        return unless File.exist?(CACHE_FILE)
        
        IQuant::Utils::ErrorHandler.safe_execute("Load Cache") do
          content = File.read(CACHE_FILE)
          data = JSON.parse(content)
          # Fusionar con el caché en memoria
          IQuant.volume_cache.merge!(data)
        end
      end

      def save_cache
        IQuant::Utils::ErrorHandler.safe_execute("Save Cache") do
          # Guardar solo si hay datos y no es excesivamente grande para evitar lags
          return if IQuant.volume_cache.empty?
          
          File.write(CACHE_FILE, JSON.generate(IQuant.volume_cache))
        end
      end

      # ==========================================================================
      # PURGA AUTOMÁTICA DE CACHÉ (NUEVO)
      # ==========================================================================

      ##
      # Purga automática del caché al cerrar el modelo o al salir
      #
      def purge_cache
        IQuant::Utils::ErrorHandler.safe_execute("Purge Cache") do
          # Limpiar caché en memoria
          IQuant.volume_cache.clear
          
          # Eliminar archivo de caché si existe
          if File.exist?(CACHE_FILE)
            File.delete(CACHE_FILE)
          end
        end
      end
      
      # Registrar purga al cerrar el modelo
      if defined?(Sketchup)
        # ✅ CORRECCIÓN: Evitar registrar múltiples observadores
        unless @cache_observer_registered
          Sketchup.add_observer(
            Sketchup::AppObserver.new.tap do |observer|
              def observer.onUnloadModel(model)
                IQuant::Core::Calculator.purge_cache
              end
              
              def observer.onQuit
                IQuant::Core::Calculator.purge_cache
              end
            end
          )
          # ✅ CORRECCIÓN: Marcar como registrado
          @cache_observer_registered = true
        end
      end

      # ==========================================================================
      # VALIDACIONES
      # ==========================================================================

      def valid_entity?(entity)
        return false unless entity
        return false if entity.deleted?
        return false unless entity.respond_to?(:bounds)
        
        entity.is_a?(Sketchup::ComponentInstance) ||
        entity.is_a?(Sketchup::Group) ||
        entity.is_a?(Sketchup::Face)
      end

      # ==========================================================================
      # ESTADÍSTICAS DE SELECCIÓN
      # ==========================================================================

      def get_selection_stats(selection)
        # Asegurar que el caché esté cargado
        load_cache if IQuant.volume_cache.empty?
        
        total_stats = {
          :count => 0,
          :length => 0.0,
          :area_surf => 0.0,
          :volume => 0.0,
          :cost => 0.0,
          :items => [],
          :materials_breakdown => {},
          :categories_breakdown => {},
          :material_details => {}
        }

        return total_stats if selection.empty?

        IQuant::Utils::ErrorHandler.safe_execute("Calculate Selection Stats") do
          selection.each do |entity|
            next unless valid_entity?(entity)
            
            data = process_entity(entity)
            next unless data

            total_stats[:count] += 1
            total_stats[:length] += data[:length]
            total_stats[:area_surf] += data[:area_surf]
            total_stats[:volume] += data[:volume]
            total_stats[:cost] += data[:cost]
            total_stats[:items] << data

            # Breakdown por material
            mat = data[:material] || 'Default'
            total_stats[:materials_breakdown][mat] ||= { cost: 0.0 }
            total_stats[:materials_breakdown][mat][:cost] += data[:cost]

            # Breakdown por categoría
            cat = data[:category] || 'General'
            total_stats[:categories_breakdown][cat] ||= { cost: 0.0 }
            total_stats[:categories_breakdown][cat][:cost] += data[:cost]

            # Detalles de materiales para desglose
            if data[:material_details] && !data[:material_details].empty?
              data[:material_details].each do |mat_name, mat_data|
                total_stats[:material_details][mat_name] ||= { quantity: 0.0, cost: 0.0, unit: mat_data[:unit] }
                total_stats[:material_details][mat_name][:quantity] += mat_data[:quantity]
                total_stats[:material_details][mat_name][:cost] += mat_data[:cost]
              end
            end
          end
          
          # Guardar caché actualizado al finalizar el proceso
          save_cache
        end

        total_stats
      end

      # ==========================================================================
      # PROCESAMIENTO DE ENTIDADES CON GEOMETRY ANALYZER INTEGRADO
      # ==========================================================================

      def process_entity(entity, parent_trans = Geom::Transformation.new)
        return nil unless valid_entity?(entity)

        IQuant::Utils::ErrorHandler.safe_execute("Process Entity #{entity.entityID}") do
          # ============================================================
          # ANÁLISIS GEOMÉTRICO AVANZADO (SI ESTÁ DISPONIBLE)
          # ============================================================
          geometry_data = nil
          if defined?(IQuant::Core::GeometryAnalyzer) && 
             IQuant::Core::GeometryAnalyzer.valid_geometry?(entity)
            
            geometry_data = IQuant::Core::GeometryAnalyzer.analyze_entity(entity)
          end

          # ============================================================
          # DIMENSIONES BÁSICAS
          # ============================================================
          bb = entity.bounds
          
          # Usar espesor inteligente del GeometryAnalyzer si está disponible
          if geometry_data && geometry_data[:thickness]
            # GeometryAnalyzer ya calculó el espesor correcto
            thickness = geometry_data[:thickness]
            # Para length y width, usar las otras dimensiones del bounding box
            dims = [bb.width, bb.height, bb.depth].sort
            # Filtrar el espesor y obtener las otras dos dimensiones
            other_dims = dims.reject { |d| (d - thickness).abs < 0.001 }
            length = other_dims.last || dims[2]
            width = other_dims.first || dims[1]
            height = thickness
          else
            # Método tradicional
            dims = [bb.width, bb.height, bb.depth].sort
            length = dims[2]
            width = dims[1]
            height = dims[0]  # Espesor tradicional (puede ser inexacto)
          end

          # ============================================================
          # INFORMACIÓN DE CAPAS Y MATERIALES
          # ============================================================
          layer_name = entity.layer ? entity.layer.name : "Layer0"
          mat_name = entity.material ? entity.material.display_name : "Default"
          
          # Buscar regla de costo (Helper interno)
          cost_rule = get_rule(layer_name, mat_name, IQuant::DICT_COST)
          
          # ============================================================
          # CÁLCULO DE ÁREA (MEJORADO CON GEOMETRY ANALYZER)
          # ============================================================
          area_mode = cost_rule && cost_rule[:area_calc_mode] ? cost_rule[:area_calc_mode] : 'total'
          
          # Para 'top_surface', usar projected_area_z del GeometryAnalyzer si está disponible
          area_surf = if area_mode == 'top_surface' && geometry_data
                        IQuant::Core::GeometryAnalyzer.projected_area_z(entity)
                      else
                        calculate_surface_area(entity, area_mode)
                      end
          
          # ============================================================
          # CÁLCULO DE VOLUMEN
          # ============================================================
          vol = calculate_volume(entity)
          
          # Aplicar transformación de escala si existe
          if entity.respond_to?(:transformation)
            scale = entity.transformation.to_a.values_at(0, 5, 10).map(&:abs)
            scale_factor = scale.reduce(:*)
            vol *= scale_factor if scale_factor != 1.0
          end

          # ============================================================
          # CATEGORÍA Y CLASIFICACIÓN
          # ============================================================
          # Usar clasificación del GeometryAnalyzer si está disponible
          category = if geometry_data && geometry_data[:type] != 'generic'
                      geometry_data[:type]  # 'wall', 'column', 'slab', 'beam'
                    else
                      get_category(entity)   # Método tradicional
                    end
          
          # Contar instancias
          instance_count = 1
          if entity.is_a?(Sketchup::ComponentInstance)
            instance_count = entity.definition.instances.size
          end

          # ============================================================
          # CÁLCULO DE COSTO
          # ============================================================
          cost, material_details = if defined?(IQuant::Core::CostCalculator)
            IQuant::Core::CostCalculator.calculate_cost_with_details(vol, area_surf, length, instance_count, cost_rule)
          else
            [0.0, {}] # Fallback si el módulo no está cargado
          end

          # ============================================================
          # CONVERSIÓN DE UNIDADES
          # ============================================================
          current_unit = IQuant.current_unit
          unit_factor = IQuant::UNIT_FACTORS[current_unit]
          
          length_converted = length * unit_factor
          width_converted = width * unit_factor
          height_converted = height * unit_factor
          area_converted = area_surf * (unit_factor ** 2)
          vol_converted = vol * (unit_factor ** 3)
          
          # ============================================================
          # CONSTRUIR RESULTADO
          # ============================================================
          result = {
            :id => entity.entityID,
            :name => get_entity_name(entity),
            :layer => layer_name,
            :material => mat_name,
            :category => category,
            :length => length_converted,
            :width => width_converted,
            :height => height_converted,
            :area_surf => area_converted,
            :volume => vol_converted,
            :instance_count => instance_count,
            :cost => cost,
            :material_details => material_details,
            :area_calc_mode => area_mode
          }

          # ============================================================
          # AGREGAR DATOS AVANZADOS DEL GEOMETRY ANALYZER
          # ============================================================
          if geometry_data
            result[:geometry_analysis] = {
              :type => geometry_data[:type],
              :orientation => geometry_data[:orientation],
              :is_manifold => geometry_data[:is_manifold],
              :efficiency => geometry_data[:efficiency],
              :smart_thickness_used => geometry_data[:thickness] != dims[0],
              :raw_dims => geometry_data[:dims].map { |d| d * unit_factor }
            }
            
            # Si es una losa/slab, agregar área proyectada exacta
            if geometry_data[:type] == 'slab' || geometry_data[:type] == 'floor'
              if defined?(IQuant::Core::GeometryAnalyzer)
                result[:projected_area] = IQuant::Core::GeometryAnalyzer.projected_area_z(entity) * (unit_factor ** 2)
              end
            end
          end

          result
        end
      end

      # ==========================================================================
      # CÁLCULO DE VOLUMEN (MEJORADO CON GEOMETRY ANALYZER HOOK)
      # ==========================================================================

      def calculate_volume(entity, parent_transform = Geom::Transformation.new)
        # 1. Intentar usar caché
        if entity.respond_to?(:definition) && entity.definition
          cache_key = entity.definition.guid
          if IQuant.volume_cache.key?(cache_key)
            cached_vol = IQuant.volume_cache[cache_key]
            
            # Aplicar escala si es instancia
            if entity.respond_to?(:transformation)
              combined_transform = parent_transform * entity.transformation
              scale = combined_transform.to_a.values_at(0, 5, 10).map(&:abs)
              scale_factor = scale.reduce(:*)
              return cached_vol * scale_factor if scale_factor != 1.0
            end
            
            return cached_vol
          end
        end
        
        # Limpieza de caché si es muy grande (> 2000 entradas)
        if IQuant.volume_cache.size > 2000
          IQuant.volume_cache.clear
        end
        
        vol = 0.0
        
        # 2. API Nativa (Sólidos Manifold) - PREFERIDA
        if entity.respond_to?(:volume)
          api_vol = entity.volume rescue -1
          if api_vol && api_vol > 0.0001
            vol = api_vol
            
            # Guardar en caché base (sin escala)
            if entity.respond_to?(:definition) && entity.definition
              IQuant.volume_cache[entity.definition.guid] = vol
            end
            
            # Aplicar escala
            if entity.respond_to?(:transformation)
              combined_transform = parent_transform * entity.transformation
              scale = combined_transform.to_a.values_at(0, 5, 10).map(&:abs)
              scale_factor = scale.reduce(:*)
              vol *= scale_factor if scale_factor != 1.0
            end
            
            return vol
          end
        end
        
        # 3. Cálculo Recursivo / Geometría Compleja
        if entity.respond_to?(:definition)
          IQuant::Utils::ErrorHandler.safe_execute("Calculate Volume Recursive") do
            current_transform = entity.respond_to?(:transformation) ?
                               parent_transform * entity.transformation : 
                               parent_transform
            
            entity.definition.entities.each do |e|
              if e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
                vol += calculate_volume(e, current_transform)
              elsif e.is_a?(Sketchup::Face)
                # Usar GeometryAnalyzer si está disponible para geometrías complejas
                if defined?(IQuant::Core::GeometryAnalyzer)
                  # Verificar si la geometría es irregular (baja eficiencia)
                  # Si es así, usar método más preciso
                  if IQuant::Core::GeometryAnalyzer.valid_geometry?(entity)
                    geometry_data = IQuant::Core::GeometryAnalyzer.analyze_entity(entity)
                    if geometry_data && geometry_data[:efficiency] < 0.5
                      # Geometría irregular, usar tetraedros para precisión
                      face_vol = calculate_face_volume(e, current_transform)
                      vol += face_vol if face_vol > 0
                      next
                    end
                  end
                end
                
                # Método normal para geometrías regulares
                face_vol = calculate_face_volume(e, current_transform)
                vol += face_vol if face_vol > 0
              end
            end
          end
        end
        
        # 4. Fallback: Bounding Box (solo si todo lo demás falla)
        if vol <= 0.0001
          bb = entity.bounds
          if entity.respond_to?(:transformation)
            # Escalar el BB
            combined_transform = parent_transform * entity.transformation
            scale = combined_transform.to_a.values_at(0, 5, 10).map(&:abs)
            scale_factor = scale.reduce(:*)
            vol = (bb.width * bb.height * bb.depth) * scale_factor
          else
            vol = bb.width * bb.height * bb.depth
          end
        end
        
        vol
      end

      # Método de tetraedros para volumen de caras (geometrías irregulares)
      def calculate_face_volume(face, transform = Geom::Transformation.new)
        return 0.0 unless face.is_a?(Sketchup::Face)
        
        IQuant::Utils::ErrorHandler.safe_execute("Calculate Face Volume") do
          origin = Geom::Point3d.new(0, 0, 0)
          mesh = face.mesh(7)
          volume = 0.0
          
          (1..mesh.count_polygons).each do |i|
            polygon = mesh.polygon_at(i)
            next unless polygon && polygon.size == 3
            
            pts = polygon.map { |idx| mesh.point_at(idx.abs).transform(transform) }
            
            # V = |a·(b×c)| / 6
            a = Geom::Vector3d.new(origin, pts[0])
            b = Geom::Vector3d.new(origin, pts[1])
            c = Geom::Vector3d.new(origin, pts[2])
            
            cross_product = b.cross(c)
            scalar_triple = a.dot(cross_product)
            
            volume += scalar_triple / 6.0 # Signado para cancelar caras internas
          end
          
          volume
        end
      end

      # ==========================================================================
      # CÁLCULO DE ÁREA DE SUPERFICIE
      # ==========================================================================

      def calculate_surface_area(entity, mode = 'total')
        area = 0.0
        return area unless entity.respond_to?(:definition)

        IQuant::Utils::ErrorHandler.safe_execute("Calculate Surface Area") do
          case mode
          when 'total'
            entity.definition.entities.grep(Sketchup::Face).each do |face|
              area += face.area
            end

          when 'material_only'
            entity.definition.entities.grep(Sketchup::Face).each do |face|
              area += face.area if face.material
            end

          when 'top_surface'
            # Si GeometryAnalyzer está disponible, usar projected_area_z
            if defined?(IQuant::Core::GeometryAnalyzer)
              return IQuant::Core::GeometryAnalyzer.projected_area_z(entity)
            else
              # Método tradicional
              entity.definition.entities.grep(Sketchup::Face).each do |face|
                # Normal apunta hacia arriba (tolerancia ~25 grados)
                if face.normal.z > 0.9
                  area += face.area
                end
              end
            end
          end

          # Recursión para grupos anidados (excepto para top_surface con GeometryAnalyzer)
          unless mode == 'top_surface' && defined?(IQuant::Core::GeometryAnalyzer)
            entity.definition.entities.each do |e|
              if e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
                area += calculate_surface_area(e, mode)
              end
            end
          end
        end

        area
      end

      # ==========================================================================
      # HELPERS PRIVADOS
      # ==========================================================================

      private

      def get_category(entity)
        cat = entity.get_attribute(IQuant::DICT_CATS, "category")
        return cat if cat && !cat.to_s.empty?
        
        # Intentar mapear desde Layer
        layer_name = entity.layer ? entity.layer.name : ""
        
        # Si GeometryAnalyzer está disponible, usar su clasificación
        if defined?(IQuant::Core::GeometryAnalyzer) && 
           IQuant::Core::GeometryAnalyzer.valid_geometry?(entity)
          
          geometry_data = IQuant::Core::GeometryAnalyzer.analyze_entity(entity)
          if geometry_data && geometry_data[:type] != 'generic'
            return geometry_data[:type]
          end
        end
        
        # Mapeo tradicional por nombre de capa
        case layer_name.downcase
        when /muro|wall|pared/
          'wall'
        when /columna|column|pillar/
          'column'
        when /losa|slab|plate|floor/
          'slab'
        when /viga|beam|girder/
          'beam'
        else
          'General'
        end
      end

      def get_rule(layer, mat, dict_name)
        model = Sketchup.active_model
        dict = model.attribute_dictionary(dict_name)
        return nil unless dict

        # Prioridad: Objeto > Capa > Material
        # (Aquí simplificado a capa/material como en el original)
        json = dict[layer] || dict[mat]
        return nil unless json

        IQuant::Utils::ErrorHandler.safe_execute("Parse Cost Rule") do
          JSON.parse(json, :symbolize_names => true)
        end
      end

      def get_entity_name(entity)
        return "Unknown" unless entity
        
        IQuant::Utils::ErrorHandler.safe_execute("Get Entity Name") do
          if entity.respond_to?(:definition) && entity.definition
            name = entity.definition.name.to_s
            return name unless name.empty?
          end
          
          if entity.respond_to?(:name)
            name = entity.name.to_s
            return name unless name.empty?
          end
          
          "Object_#{entity.entityID}"
        end
      rescue
        "Unknown"
      end

    end
  end
end
