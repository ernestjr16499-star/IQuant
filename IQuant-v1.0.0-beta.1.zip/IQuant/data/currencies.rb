﻿# encoding: UTF-8

module IQuant
  module Data

    # ==========================================================================
    # SISTEMA DE MONEDAS INTERNACIONALES (50 PAÍSES)
    # Referencia: ISO 4217
    # ==========================================================================
    
    CURRENCIES = {
      # América del Norte
      'CAD' => { country: 'Canadá', symbol: 'C$', name: 'Dólar Canadiense' },
      'MXN' => { country: 'México', symbol: '$', name: 'Peso Mexicano' },
      'USD' => { country: 'Estados Unidos', symbol: '$', name: 'Dólar Estadounidense' },

      # América Central y Caribe
      'CRC' => { country: 'Costa Rica', symbol: '₡', name: 'Colón Costarricense' },
      'CUP' => { country: 'Cuba', symbol: '$', name: 'Peso Cubano' },
      'DOP' => { country: 'República Dominicana', symbol: 'RD$', name: 'Peso Dominicano' },
      'GTQ' => { country: 'Guatemala', symbol: 'Q', name: 'Quetzal' },
      'HNL' => { country: 'Honduras', symbol: 'L', name: 'Lempira' },
      'NIO' => { country: 'Nicaragua', symbol: 'C$', name: 'Córdoba' },
      'PAB' => { country: 'Panamá', symbol: 'B/.', name: 'Balboa' },

      # América del Sur
      'ARS' => { country: 'Argentina', symbol: '$', name: 'Peso Argentino' },
      'BOB' => { country: 'Bolivia', symbol: 'Bs', name: 'Boliviano' },
      'BRL' => { country: 'Brasil', symbol: 'R$', name: 'Real Brasileño' },
      'CLP' => { country: 'Chile', symbol: '$', name: 'Peso Chileno' },
      'COP' => { country: 'Colombia', symbol: '$', name: 'Peso Colombiano' },
      'PEN' => { country: 'Perú', symbol: 'S/', name: 'Sol Peruano' },
      'PYG' => { country: 'Paraguay', symbol: '₲', name: 'Guaraní' },
      'UYU' => { country: 'Uruguay', symbol: '$U', name: 'Peso Uruguayo' },
      'VES' => { country: 'Venezuela', symbol: 'Bs.S', name: 'Bolívar Soberano' },

      # Europa
      'CHF' => { country: 'Suiza', symbol: 'CHF', name: 'Franco Suizo' },
      'CZK' => { country: 'República Checa', symbol: 'Kč', name: 'Corona Checa' },
      'DKK' => { country: 'Dinamarca', symbol: 'kr', name: 'Corona Danesa' },
      'EUR' => { country: 'Eurozona', symbol: '€', name: 'Euro' },
      'GBP' => { country: 'Reino Unido', symbol: '£', name: 'Libra Esterlina' },
      'HUF' => { country: 'Hungría', symbol: 'Ft', name: 'Florín Húngaro' },
      'NOK' => { country: 'Noruega', symbol: 'kr', name: 'Corona Noruega' },
      'PLN' => { country: 'Polonia', symbol: 'zł', name: 'Zloty Polaco' },
      'RON' => { country: 'Rumania', symbol: 'lei', name: 'Leu Rumano' },
      'RUB' => { country: 'Rusia', symbol: '₽', name: 'Rublo Ruso' },
      'SEK' => { country: 'Suecia', symbol: 'kr', name: 'Corona Sueca' },
      'TRY' => { country: 'Turquía', symbol: '₺', name: 'Lira Turca' },
      'UAH' => { country: 'Ucrania', symbol: '₴', name: 'Grivna' },

      # Asia
      'AED' => { country: 'Emiratos Árabes', symbol: 'د.إ', name: 'Dirham' },
      'CNY' => { country: 'China', symbol: '¥', name: 'Yuan Chino' },
      'HKD' => { country: 'Hong Kong', symbol: 'HK$', name: 'Dólar de Hong Kong' },
      'IDR' => { country: 'Indonesia', symbol: 'Rp', name: 'Rupia Indonesia' },
      'ILS' => { country: 'Israel', symbol: '₪', name: 'Nuevo Shéquel' },
      'INR' => { country: 'India', symbol: '₹', name: 'Rupia India' },
      'JPY' => { country: 'Japón', symbol: '¥', name: 'Yen Japonés' },
      'KRW' => { country: 'Corea del Sur', symbol: '₩', name: 'Won Surcoreano' },
      'MYR' => { country: 'Malasia', symbol: 'RM', name: 'Ringgit Malayo' },
      'PHP' => { country: 'Filipinas', symbol: '₱', name: 'Peso Filipino' },
      'SAR' => { country: 'Arabia Saudita', symbol: 'ر.س', name: 'Riyal Saudí' },
      'SGD' => { country: 'Singapur', symbol: 'S$', name: 'Dólar de Singapur' },
      'THB' => { country: 'Tailandia', symbol: '฿', name: 'Baht Tailandés' },
      'VND' => { country: 'Vietnam', symbol: '₫', name: 'Dong Vietnamita' },

      # África
      'EGP' => { country: 'Egipto', symbol: '£', name: 'Libra Egipcia' },
      'KES' => { country: 'Kenia', symbol: 'KSh', name: 'Chelín Keniano' },
      'MAD' => { country: 'Marruecos', symbol: 'د.م.', name: 'Dirham Marroquí' },
      'NGN' => { country: 'Nigeria', symbol: '₦', name: 'Naira' },
      'ZAR' => { country: 'Sudáfrica', symbol: 'R', name: 'Rand Sudafricano' },

      # Oceanía
      'AUD' => { country: 'Australia', symbol: 'A$', name: 'Dólar Australiano' },
      'NZD' => { country: 'Nueva Zelanda', symbol: 'NZ$', name: 'Dólar Neozelandés' }
    }.sort.to_h.freeze

  end
end
