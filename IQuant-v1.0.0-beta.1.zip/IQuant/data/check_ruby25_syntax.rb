#!/usr/bin/env ruby
# Simular verificación de Ruby 2.5

content = File.read('localization.rb')

# 1. Buscar sintaxis que podría fallar en Ruby 2.5
puts "=== POSIBLES PROBLEMAS PARA RUBY 2.5 ==="

# a) Hashes con símbolos como key: value
if content =~ /[a-z_][a-z0-9_]*:\s*[^,}]/
  puts "1. Hashes con sintaxis moderna (key: value) detectados"
  puts "   Ruby 2.5 puede tener problemas en ciertos contextos"
end

# b) &. operador (safe navigation) - Ruby 2.3+
if content =~ /&\./
  puts "2. Operador &. (safe navigation) detectado"
  puts "   Solo disponible en Ruby 2.3+"
end

# c) Constantes dinámicas
if content =~ /[A-Z_][A-Z0-9_]*\s*=\s*(?!nil|true|false)[a-zA-Z_]/ && content =~ /def.*=/
  puts "3. Posibles constantes dinámicas detectadas"
end

puts ""
puts "=== PRUEBA DE CARGA CON RUBY ACTUAL ==="
begin
  load 'localization.rb'
  puts "✓ Carga exitosa en Ruby #{RUBY_VERSION}"
  
  # Verificar si el módulo se carga correctamente
  if defined?(IQuant::Data::Localization)
    puts "✓ Módulo IQuant::Data::Localization cargado"
    if IQuant::Data::Localization.const_defined?(:LANGUAGES)
      puts "✓ Constante LANGUAGES definida"
    end
  end
rescue SyntaxError => e
  puts "❌ Error de sintaxis: #{e.message}"
rescue => e
  puts "❌ Error: #{e.class}: #{e.message}"
end
