﻿# encoding: UTF-8

module IQuant
  module Data
    
    # ==========================================================================
    # TÉRMINOS ESTANDARIZADOS INTERNACIONALES
    # Basado en ISO 6707-1 (Edificación e Ingeniería Civil - Vocabulario)
    # y OmniClass Table 21
    # ==========================================================================

    STANDARD_CATEGORIES = {
      # --- SUBESTRUCTURA (A) ---
      'foundations' => {
        'iso_code' => 'A10',
        'en' => 'Foundations',
        'es' => 'Cimentaciones',
        'pt' => 'Fundações',
        'fr' => 'Fondations',
        'de' => 'Gründungen',
        'zh' => '地基',
        'it' => 'Fondazioni',
        'ru' => 'Фундаменты'
      },
      'excavation' => {
        'iso_code' => 'A20',
        'en' => 'Excavation & Earthwork',
        'es' => 'Excavación y Mov. Tierras',
        'pt' => 'Escavação e Terraplenagem',
        'fr' => 'Excavation et Terrassement',
        'de' => 'Aushub und Erdarbeiten',
        'zh' => '土方工程',
        'it' => 'Scavi e Movimento Terra',
        'ru' => 'Земляные trabajos'
      },

      # --- ESTRUCTURA (B) ---
      'columns' => {
        'iso_code' => 'B1010',
        'en' => 'Columns',
        'es' => 'Columnas / Pilares',
        'pt' => 'Pilares',
        'fr' => 'Colonnes',
        'de' => 'Stützen',
        'zh' => '柱',
        'it' => 'Colonne',
        'ru' => 'Колонны'
      },
      'beams' => {
        'iso_code' => 'B1020',
        'en' => 'Beams',
        'es' => 'Vigas',
        'pt' => 'Vigas',
        'fr' => 'Poutres',
        'de' => 'Träger',
        'zh' => '梁',
        'it' => 'Travi',
        'ru' => 'Балки'
      },
      'walls_structural' => {
        'iso_code' => 'B2010',
        'en' => 'Structural Walls',
        'es' => 'Muros Estructurales',
        'pt' => 'Paredes Estruturais',
        'fr' => 'Murs Porteurs',
        'de' => 'Tragwände',
        'zh' => '承重墙',
        'it' => 'Muri Portanti',
        'ru' => 'Несущие стены'
      },
      'slabs' => {
        'iso_code' => 'B1080',
        'en' => 'Floor Slabs',
        'es' => 'Losas de Piso',
        'pt' => 'Lajes',
        'fr' => 'Dalles',
        'de' => 'Deckenplatten',
        'zh' => '楼板',
        'it' => 'Solai',
        'ru' => 'Перекрытия'
      },
      'stairs' => {
        'iso_code' => 'B1080',
        'en' => 'Stairs & Ramps',
        'es' => 'Escaleras y Rampas',
        'pt' => 'Escadas e Rampas',
        'fr' => 'Escaliers et Rampes',
        'de' => 'Treppen und Rampen',
        'zh' => '楼梯和坡道',
        'it' => 'Scale e Rampe',
        'ru' => 'Лестницы и пандусы'
      },
      'roofs' => {
        'iso_code' => 'B30',
        'en' => 'Roofing',
        'es' => 'Cubiertas / Techos',
        'pt' => 'Coberturas / Telhados',
        'fr' => 'Toiture',
        'de' => 'Dachkonstruktionen',
        'zh' => '屋顶',
        'it' => 'Coperture',
        'ru' => 'Кровля'
      },

      # --- CERRAMIENTOS Y DIVISIONES (C) ---
      'walls_partition' => {
        'iso_code' => 'C1010',
        'en' => 'Partitions',
        'es' => 'Tabiquería / Muros Divisorios',
        'pt' => 'Divisórias',
        'fr' => 'Cloisons',
        'de' => 'Trennwände',
        'zh' => '隔墙',
        'it' => 'Tramezzi',
        'ru' => 'Перегородки'
      },
      'windows' => {
        'iso_code' => 'B2020',
        'en' => 'Windows',
        'es' => 'Ventanas',
        'pt' => 'Janelas',
        'fr' => 'Fenêtres',
        'de' => 'Fenster',
        'zh' => '窗户',
        'it' => 'Finestre',
        'ru' => 'Окна'
      },
      'doors' => {
        'iso_code' => 'B2030',
        'en' => 'Doors',
        'es' => 'Puertas',
        'pt' => 'Portas',
        'fr' => 'Portes',
        'de' => 'Türen',
        'zh' => '门',
        'it' => 'Porte',
        'ru' => 'Двери'
      },

      # --- ACABADOS (C) ---
      'floor_finishes' => {
        'iso_code' => 'C3020',
        'en' => 'Floor Finishes',
        'es' => 'Pavimentos / Pisos',
        'pt' => 'Revestimento de Piso',
        'fr' => 'Revêtements de Sol',
        'de' => 'Bodenbeläge',
        'zh' => '地面装饰',
        'it' => 'Pavimentazioni',
        'ru' => 'Напольные покрытия'
      },
      'wall_finishes' => {
        'iso_code' => 'C3010',
        'en' => 'Wall Finishes',
        'es' => 'Revestimientos de Pared',
        'pt' => 'Revestimento de Parede',
        'fr' => 'Revêtements Muraux',
        'de' => 'Wandbekleidungen',
        'zh' => '墙面装饰',
        'it' => 'Rivestimenti Murali',
        'ru' => 'Отделка стен'
      },
      'ceilings' => {
        'iso_code' => 'C3030',
        'en' => 'Ceilings',
        'es' => 'Cielorrasos / Techos Falsos',
        'pt' => 'Forros',
        'fr' => 'Plafonds',
        'de' => 'Deckenbekleidungen',
        'zh' => '吊顶',
        'it' => 'Controsoffitti',
        'ru' => 'Потолки'
      },

      # --- INSTALACIONES (D) ---
      'plumbing' => {
        'iso_code' => 'D20',
        'en' => 'Plumbing',
        'es' => 'Fontanería / Plomería',
        'pt' => 'Hidráulica',
        'fr' => 'Plomberie',
        'de' => 'Sanitár',
        'zh' => '给排水',
        'it' => 'Idraulica',
        'ru' => 'Сантехника'
      },
      'hvac' => {
        'iso_code' => 'D30',
        'en' => 'HVAC',
        'es' => 'Climatización (HVAC)',
        'pt' => 'AVAC',
        'fr' => 'CVC',
        'de' => 'HLK',
        'zh' => '暖通空调',
        'it' => 'HVAC',
        'ru' => 'ОВК'
      },
      'electrical' => {
        'iso_code' => 'D50',
        'en' => 'Electrical',
        'es' => 'Electricidad',
        'pt' => 'Elétrica',
        'fr' => 'Électricité',
        'de' => 'Elektro',
        'zh' => '电气',
        'it' => 'Elettrico',
        'ru' => 'Электрика'
      },

      # --- SITIO Y EXTERIORES (G) ---
      'site_work' => {
        'iso_code' => 'G10',
        'en' => 'Site Work',
        'es' => 'Obras Exteriores',
        'pt' => 'Obras Externas',
        'fr' => 'Aménagement Extérieur',
        'de' => 'Außenanlagen',
        'zh' => '场地工程',
        'it' => 'Lavori Esterni',
        'ru' => 'Благоустройство'
      },
      
      # --- OTROS ---
      'furniture' => {
        'iso_code' => 'E10',
        'en' => 'Furniture',
        'es' => 'Mobiliario',
        'pt' => 'Mobiliário',
        'fr' => 'Mobilier',
        'de' => 'Möblierung',
        'zh' => '家具',
        'it' => 'Arredamento',
        'ru' => 'Мебель'
      },
      'general' => {
        'iso_code' => 'Z99',
        'en' => 'General / Uncategorized',
        'es' => 'General / Sin Categoría',
        'pt' => 'Geral / Sem Categoria',
        'fr' => 'Général / Non classé',
        'de' => 'Allgemein / Nicht kategorisiert',
        'zh' => '常规 / 未分类',
        'it' => 'Generale / Non categorizzato',
        'ru' => 'Общее / Без категории'
      }
    }.sort.to_h.freeze

    # ==========================================================================
    # UNIDADES ESTÁNDAR
    # Para dropdowns y conversiones
    # ==========================================================================
    
    STANDARD_UNITS = {
      'volume' => {
        'si' => ['m³', 'l'],
        'imperial' => ['ft³', 'yd³', 'gal']
      },
      'area' => {
        'si' => ['m²', 'cm²', 'ha'],
        'imperial' => ['ft²', 'in²', 'yd²', 'ac']
      },
      'length' => {
        'si' => ['m', 'cm', 'mm', 'km'],
        'imperial' => ['ft', 'in', 'yd', 'mi']
      },
      'mass' => {
        'si' => ['kg', 'ton', 'g'],
        'imperial' => ['lb', 'oz']
      },
      'count' => {
        'generic' => ['ea', 'pcs', 'units']
      }
    }.freeze
    
    # Método helper para obtener nombre de categoría traducido
    def self.get_category_name(key, lang = 'en')
      return key unless STANDARD_CATEGORIES[key]
      
      # Intentar obtener idioma, fallback a inglés, luego fallback al nombre clave
      STANDARD_CATEGORIES[key][lang] || STANDARD_CATEGORIES[key]['en'] || key
    end

  end
end
