﻿# encoding: UTF-8

module IQuant
  module Data

    # ==========================================================================
    # DOSIFICACIONES ESTÁNDAR INTERNACIONALES
    # Basado en: ACI 211, ASTM C94, Eurocódigo 2, BS 8500, ASTM C270
    # ==========================================================================

    DOSAGE_LIBRARY = {
      # ========== HORMIGONES ESTRUCTURALES (según ACI 318) ==========
      'c15' => {
        'name' => 'Concreto C15 (15 MPa) - Elementos no estructurales',
        'use' => 'Rellenos, contrapisos, banquetas',
        'standard' => 'ACI 211',
        'cement_kg_per_m3' => 280,
        'sand_m3_per_m3' => 0.55,
        'gravel_m3_per_m3' => 0.75,
        'water_l_per_m3' => 170
      },
      'c20' => {
        'name' => 'Concreto C20 (20 MPa) - Estructural liviano',
        'use' => 'Losas de piso, aceras, muros de contención bajos',
        'standard' => 'ACI 318 / BS 8500',
        'cement_kg_per_m3' => 320,
        'sand_m3_per_m3' => 0.52,
        'gravel_m3_per_m3' => 0.72,
        'water_l_per_m3' => 175
      },
      'c25' => {
        'name' => 'Concreto C25 (25 MPa) - Estructural estándar',
        'use' => 'Vigas, columnas, losas estructurales residenciales',
        'standard' => 'ACI 318 / Eurocódigo 2',
        'cement_kg_per_m3' => 350,
        'sand_m3_per_m3' => 0.50,
        'gravel_m3_per_m3' => 0.70,
        'water_l_per_m3' => 180
      },
      'c30' => {
        'name' => 'Concreto C30 (30 MPa) - Estructural alto',
        'use' => 'Edificios comerciales, puentes, elementos pretensados',
        'standard' => 'ACI 318 / BS 8500',
        'cement_kg_per_m3' => 385,
        'sand_m3_per_m3' => 0.48,
        'gravel_m3_per_m3' => 0.68,
        'water_l_per_m3' => 185
      },
      'c35' => {
        'name' => 'Concreto C35 (35 MPa) - Alta resistencia',
        'use' => 'Torres, pilares de puentes, losas de alta carga',
        'standard' => 'ACI 318',
        'cement_kg_per_m3' => 420,
        'sand_m3_per_m3' => 0.46,
        'gravel_m3_per_m3' => 0.66,
        'water_l_per_m3' => 190
      },
      'c40' => {
        'name' => 'Concreto C40 (40 MPa) - Muy alta resistencia',
        'use' => 'Rascacielos, infraestructura crítica',
        'standard' => 'ACI 318 / Eurocódigo 2',
        'cement_kg_per_m3' => 450,
        'sand_m3_per_m3' => 0.44,
        'gravel_m3_per_m3' => 0.64,
        'water_l_per_m3' => 195
      },
      
      # ========== CONCRETOS ESPECIALES ==========
      'c_high_strength' => {
        'name' => 'Concreto Alta Resistencia (50+ MPa)',
        'use' => 'Torres, pilares de gran altura, elementos esbeltos',
        'standard' => 'ACI 363',
        'cement_kg_per_m3' => 500,
        'sand_m3_per_m3' => 0.42,
        'gravel_m3_per_m3' => 0.62,
        'water_l_per_m3' => 165
      },
      'c_lightweight' => {
        'name' => 'Concreto Ligero (16 MPa)',
        'use' => 'Bloques prefabricados, losas aligeradas',
        'standard' => 'ACI 213',
        'cement_kg_per_m3' => 320,
        'sand_m3_per_m3' => 0.40,
        'gravel_m3_per_m3' => 0.50,  # Agregado ligero
        'water_l_per_m3' => 190
      },
      'c_pumpable' => {
        'name' => 'Concreto Bombeable (25 MPa)',
        'use' => 'Losas de gran área, elementos de difícil acceso',
        'standard' => 'ACI 304',
        'cement_kg_per_m3' => 360,
        'sand_m3_per_m3' => 0.55,  # Mayor contenido de finos
        'gravel_m3_per_m3' => 0.68,
        'water_l_per_m3' => 185
      },

      # ========== MORTEROS DE PEGA (Latinoamérica) ==========
      'm_1_3' => {
        'name' => 'Mortero 1:3 - Alta resistencia',
        'use' => 'Pega de bloques portantes, revestimientos',
        'standard' => 'Norma Técnica Local',
        'cement_kg_per_m3' => 500,
        'sand_m3_per_m3' => 1.0,
        'water_l_per_m3' => 250
      },
      'm_1_4' => {
        'name' => 'Mortero 1:4 - Resistencia media',
        'use' => 'Pega de bloques estándar, muros divisorios',
        'standard' => 'Norma Técnica Local',
        'cement_kg_per_m3' => 400,
        'sand_m3_per_m3' => 1.0,
        'water_l_per_m3' => 240
      },
      'm_1_5' => {
        'name' => 'Mortero 1:5 - Económico',
        'use' => 'Pega de bloques no portantes, rellenos',
        'standard' => 'Norma Técnica Local',
        'cement_kg_per_m3' => 300,
        'sand_m3_per_m3' => 1.0,
        'water_l_per_m3' => 220
      },
      'm_1_6' => {
        'name' => 'Mortero 1:6 - Muy económico',
        'use' => 'Mampostería liviana, reparaciones menores',
        'standard' => 'Norma Técnica Local',
        'cement_kg_per_m3' => 250,
        'sand_m3_per_m3' => 1.0,
        'water_l_per_m3' => 210
      },

      # ========== MORTEROS (según ASTM C270) ==========
      'm_type_m' => {
        'name' => 'Mortero Tipo M (17.5 MPa) - Muy alta resistencia',
        'use' => 'Muros de retención, cimientos, contacto con suelo',
        'standard' => 'ASTM C270',
        'cement_kg_per_m3' => 500,
        'sand_m3_per_m3' => 1.0,
        'water_l_per_m3' => 260
      },
      'm_type_n' => {
        'name' => 'Mortero Tipo N (5 MPa) - Propósito general',
        'use' => 'Muros exteriores sobre nivel, chimeneas',
        'standard' => 'ASTM C270',
        'cement_kg_per_m3' => 280,
        'sand_m3_per_m3' => 1.0,
        'water_l_per_m3' => 230
      },
      'm_type_o' => {
        'name' => 'Mortero Tipo O (2.5 MPa) - Baja resistencia',
        'use' => 'Muros interiores no portantes, reparaciones',
        'standard' => 'ASTM C270',
        'cement_kg_per_m3' => 180,
        'sand_m3_per_m3' => 1.0,
        'water_l_per_m3' => 210
      },
      'm_type_s' => {
        'name' => 'Mortero Tipo S (12.5 MPa) - Alta resistencia',
        'use' => 'Muros de carga, bajo nivel del suelo, alta compresión',
        'standard' => 'ASTM C270',
        'cement_kg_per_m3' => 420,
        'sand_m3_per_m3' => 1.0,
        'water_l_per_m3' => 250
      }
    }.sort.to_h.freeze

  end
end
