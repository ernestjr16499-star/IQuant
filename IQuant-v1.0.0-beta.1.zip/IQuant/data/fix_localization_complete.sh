#!/bin/bash
echo "=== CORRECCIÓN COMPLETA localization.rb ==="

# 1. Backup
backup="localization.rb.backup.$(date +%Y%m%d_%H%M%S)"
cp localization.rb "$backup"
echo "1. Backup creado: $backup"

# 2. Corregir hashes en LANGUAGES
echo "2. Corrigiendo sintaxis de LANGUAGES..."
sed -i "/LANGUAGES = {/,/}.freeze/ s/name: /:name => /g" localization.rb
sed -i "/LANGUAGES = {/,/}.freeze/ s/flag: /:flag => /g" localization.rb
echo "   ✓ LANGUAGES corregido"

# 3. Verificar ends
echo "3. Verificando estructura de módulos..."
modules=$(grep -c "^\s*module " localization.rb)
ends=$(grep -c "^\s*end\s*$" localization.rb)

echo "   Módulos encontrados: $modules"
echo "   Ends encontrados: $ends"

if [[ $ends -ge $modules ]]; then
    echo "   ✓ Ends suficientes"
else
    echo "   ⚠️  Faltan ends, agregando..."
    missing=$((modules - ends))
    for ((i=0; i<missing; i++)); do
        echo "end" >> localization.rb
    done
    echo "   ✓ Agregados $missing ends"
fi

# 4. Asegurar que termina con end
echo "4. Verificando final del archivo..."
last_line=$(tail -1 localization.rb)
if [[ "$last_line" =~ ^end ]]; then
    echo "   ✓ Termina con 'end'"
else
    echo "   ⚠️  No termina con 'end', agregando..."
    echo "" >> localization.rb
    echo "end" >> localization.rb
    echo "end" >> localization.rb
    echo "end" >> localization.rb
fi

# 5. Verificación final
echo "5. Verificación de sintaxis:"
result=$(ruby -wc localization.rb 2>&1)
if echo "$result" | grep -q "Syntax OK"; then
    echo "   ✅ Syntax OK"
else
    echo "   ❌ Error detectado:"
    echo "$result" | grep -E "Error|syntax"
fi

echo ""
echo "=== CORRECCIÓN COMPLETADA ==="
