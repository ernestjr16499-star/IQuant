# encoding: UTF-8

module IQuant
  module Utils
    module Validator
      extend self
      
      # ==========================================================================
      # CONSTANTES
      # ==========================================================================
      
      # Códigos de moneda válidos (ISO 4217, selección común)
      VALID_CURRENCY_CODES = %w[
        USD EUR GBP JPY CNY AUD CAD CHF HKD SGD NZD
        MXN BRL ARS CLP COP PEN UYU VEF
      ].freeze
      
      # Unidades de medida válidas
      VALID_UNITS = %w[m cm mm in ft].freeze
      
      # Idiomas soportados
      SUPPORTED_LANGUAGES = %w[en es pt fr de it].freeze
      
      # Tipos de reglas válidos
      VALID_RULE_TYPES = %w[vol area len unit].freeze
      
      # Métodos de cálculo válidos
      VALID_CALC_METHODS = %w[
        simple linear_stock tiles masonry solid fill_material
      ].freeze
      
      # ==========================================================================
      # VALIDACIONES BÁSICAS
      # ==========================================================================
      
      ##
      # Valida si un valor es un número positivo
      #
      # @param value [Numeric, String] Valor a validar
      # @param allow_zero [Boolean] Si permite cero
      # @return [Boolean] True si es válido
      #
      def validate_positive_float(value, allow_zero: false)
        return false if value.nil?
        
        # Convertir a número si es string
        num = value.is_a?(String) ? value.to_f : value.to_f
        
        # Validar rango
        if allow_zero
          num >= 0.0 && num.finite?
        else
          num > 0.0 && num.finite?
        end
      rescue
        false
      end
      
      ##
      # Valida si un valor es un entero positivo
      #
      # @param value [Integer, String] Valor a validar
      # @param allow_zero [Boolean] Si permite cero
      # @return [Boolean] True si es válido
      #
      def validate_positive_integer(value, allow_zero: false)
        return false if value.nil?
        
        # Convertir a entero si es string
        int = value.is_a?(String) ? value.to_i : value.to_i
        
        # Validar rango
        if allow_zero
          int >= 0
        else
          int > 0
        end
      rescue
        false
      end
      
      ##
      # Valida un código de moneda ISO 4217
      #
      # @param code [String] Código de moneda
      # @return [Boolean] True si es válido
      #
      def validate_currency_code(code)
        return false if code.nil? || !code.is_a?(String)
        
        VALID_CURRENCY_CODES.include?(code.upcase)
      end
      
      ##
      # Valida una unidad de medida
      #
      # @param unit [String] Unidad
      # @return [Boolean] True si es válido
      #
      def validate_unit(unit)
        return false if unit.nil? || !unit.is_a?(String)
        
        VALID_UNITS.include?(unit.downcase)
      end
      
      ##
      # Valida un código de idioma
      #
      # @param lang [String] Código de idioma
      # @return [Boolean] True si es válido
      #
      def validate_language(lang)
        return false if lang.nil? || !lang.is_a?(String)
        
        SUPPORTED_LANGUAGES.include?(lang.downcase)
      end
      
      ##
      # Valida un tipo de regla
      #
      # @param type [String] Tipo de regla
      # @return [Boolean] True si es válido
      #
      def validate_rule_type(type)
        return false if type.nil? || !type.is_a?(String)
        
        VALID_RULE_TYPES.include?(type.downcase)
      end
      
      ##
      # Valida un método de cálculo
      #
      # @param method [String] Método de cálculo
      # @return [Boolean] True si es válido
      #
      def validate_calc_method(method)
        return false if method.nil? || !method.is_a?(String)
        
        VALID_CALC_METHODS.include?(method.downcase)
      end
      
      # ==========================================================================
      # VALIDACIONES DE REGLAS
      # ==========================================================================
      
      ##
      # Valida una regla de costo completa
      #
      # @param rule [Hash] Regla a validar
      # @return [Hash] Resultado con :valid, :errors, :warnings
      #
      def validate_rule(rule)
        return {
          valid: false,
          errors: ["Rule cannot be nil"],
          warnings: []
        } if rule.nil? || !rule.is_a?(Hash)
        
        errors = []
        warnings = []
        
        # Validar tipo de regla
        type = rule[:type] || rule['type']
        unless validate_rule_type(type)
          errors << "Invalid rule type: #{type}"
        end
        
        # Validar valor base
        value = rule[:value] || rule['value']
        unless validate_positive_float(value, allow_zero: true)
          errors << "Invalid value: #{value}"
        end
        
        # Validar método de cálculo si existe
        calc_method = rule[:calc_method] || rule['calc_method']
        if calc_method && !validate_calc_method(calc_method)
          errors << "Invalid calculation method: #{calc_method}"
        end
        
        # Validaciones específicas por método
        if calc_method
          case calc_method.downcase
          when 'masonry'
            result = validate_masonry_rule(rule)
            errors.concat(result[:errors])
            warnings.concat(result[:warnings])
          when 'linear_stock'
            result = validate_linear_stock_rule(rule)
            errors.concat(result[:errors])
            warnings.concat(result[:warnings])
          when 'tiles'
            result = validate_tiles_rule(rule)
            errors.concat(result[:errors])
            warnings.concat(result[:warnings])
          when 'fill_material'
            result = validate_fill_material_rule(rule)
            errors.concat(result[:errors])
            warnings.concat(result[:warnings])
          when 'solid'
            result = validate_solid_rule(rule)
            errors.concat(result[:errors])
            warnings.concat(result[:warnings])
          end
        end
        
        # Validar nombre del ítem si existe
        item_name = rule[:item_name] || rule['item_name']
        if item_name && !item_name.is_a?(String)
          errors << "Item name must be a string"
        end
        
        {
          valid: errors.empty?,
          errors: errors,
          warnings: warnings
        }
      end
      
      ##
      # Valida una regla de mampostería
      #
      # @param rule [Hash] Regla de mampostería
      # @return [Hash] Resultado con :errors y :warnings
      #
      def validate_masonry_rule(rule)
        errors = []
        warnings = []
        
        # Dimensiones del bloque (en cm)
        brick_length = rule[:brick_length] || rule['brick_length']
        brick_width = rule[:brick_width] || rule['brick_width']
        brick_thickness = rule[:brick_thickness] || rule['brick_thickness']
        joint_thickness = rule[:joint_thickness] || rule['joint_thickness'] || 1.0
        
        # Validar dimensiones positivas
        unless validate_positive_float(brick_length)
          errors << "Brick length must be positive"
        end
        
        unless validate_positive_float(brick_width)
          errors << "Brick width must be positive"
        end
        
        unless validate_positive_float(brick_thickness)
          errors << "Brick thickness must be positive"
        end
        
        unless validate_positive_float(joint_thickness, allow_zero: true)
          errors << "Joint thickness must be non-negative"
        end
        
        # Validar rangos razonables (en centímetros)
        if brick_length && (brick_length < 10 || brick_length > 100)
          warnings << "Unusual brick length: #{brick_length} cm (typical: 10-100 cm)"
        end
        
        if brick_width && (brick_width < 5 || brick_width > 50)
          warnings << "Unusual brick width: #{brick_width} cm (typical: 5-50 cm)"
        end
        
        if brick_thickness && (brick_thickness < 5 || brick_thickness > 30)
          warnings << "Unusual brick thickness: #{brick_thickness} cm (typical: 5-30 cm)"
        end
        
        # Validar que la junta no sea mayor que el ancho del bloque
        if brick_width && joint_thickness && joint_thickness >= brick_width
          errors << "Joint thickness cannot be greater than or equal to brick width"
        end
        
        # Validar espesor de junta
        if joint_thickness && (joint_thickness < 0.5 || joint_thickness > 3)
          warnings << "Unusual joint thickness: #{joint_thickness} cm (typical: 1.0-2.0 cm)"
        end
        
        # Precio del bloque
        brick_price = rule[:brick_price] || rule['brick_price']
        unless validate_positive_float(brick_price)
          errors << "Brick price must be positive"
        end
        
        # Validar dosificación de mortero si existe
        mortar_dosage = rule[:mortar_dosage] || rule['mortar_dosage']
        if mortar_dosage && !mortar_dosage.is_a?(String)
          errors << "Mortar dosage must be a string"
        end
        
        # Validar precios de materiales del mortero
        mortar_prices = rule[:mortar_prices] || rule['mortar_prices']
        if mortar_prices && !mortar_prices.is_a?(Hash)
          errors << "Mortar prices must be a hash"
        end
        
        { errors: errors, warnings: warnings }
      end
      
      ##
      # Valida una regla de material lineal en stock
      #
      # @param rule [Hash] Regla de material lineal
      # @return [Hash] Resultado con :errors y :warnings
      #
      def validate_linear_stock_rule(rule)
        errors = []
        warnings = []
        
        stock_length = rule[:stock_length] || rule['stock_length']
        price_per_stock = rule[:price_per_stock] || rule['price_per_stock']
        
        unless validate_positive_float(stock_length)
          errors << "Stock length must be positive"
        end
        
        unless validate_positive_float(price_per_stock)
          errors << "Price per stock must be positive"
        end
        
        # Validar rangos razonables (en metros)
        if stock_length && (stock_length < 0.1 || stock_length > 12)
          warnings << "Unusual stock length: #{stock_length} m (typical: 0.1-12 m)"
        end
        
        { errors: errors, warnings: warnings }
      end
      
      ##
      # Valida una regla de tejas/losetas
      #
      # @param rule [Hash] Regla de tejas
      # @return [Hash] Resultado con :errors y :warnings
      #
      def validate_tiles_rule(rule)
        errors = []
        warnings = []
        
        tile_length = rule[:tile_length] || rule['tile_length']
        tile_width = rule[:tile_width] || rule['tile_width']
        price_per_tile = rule[:price_per_tile] || rule['price_per_tile']
        
        unless validate_positive_float(tile_length)
          errors << "Tile length must be positive"
        end
        
        unless validate_positive_float(tile_width)
          errors << "Tile width must be positive"
        end
        
        unless validate_positive_float(price_per_tile)
          errors << "Price per tile must be positive"
        end
        
        # Validar rangos razonables (en centímetros)
        if tile_length && (tile_length < 5 || tile_length > 120)
          warnings << "Unusual tile length: #{tile_length} cm (typical: 5-120 cm)"
        end
        
        if tile_width && (tile_width < 5 || tile_width > 120)
          warnings << "Unusual tile width: #{tile_width} cm (typical: 5-120 cm)"
        end
        
        # Validar relación aspecto
        if tile_length && tile_width
          aspect_ratio = tile_length.to_f / tile_width.to_f
          if aspect_ratio > 4 || aspect_ratio < 0.25
            warnings << "Extreme tile aspect ratio: #{aspect_ratio.round(2)}"
          end
        end
        
        { errors: errors, warnings: warnings }
      end
      
      ##
      # Valida una regla de material de relleno
      #
      # @param rule [Hash] Regla de relleno
      # @return [Hash] Resultado con :errors y :warnings
      #
      def validate_fill_material_rule(rule)
        errors = []
        warnings = []
        
        price_per_m3 = rule[:price_per_m3] || rule['price_per_m3']
        
        unless validate_positive_float(price_per_m3)
          errors << "Price per m³ must be positive"
        end
        
        # Validar rangos razonables de precio
        if price_per_m3 && (price_per_m3 < 5 || price_per_m3 > 500)
          warnings << "Unusual fill material price: #{price_per_m3} per m³"
        end
        
        { errors: errors, warnings: warnings }
      end
      
      ##
      # Valida una regla de masa sólida (hormigón/mortero)
      #
      # @param rule [Hash] Regla de masa sólida
      # @return [Hash] Resultado con :errors y :warnings
      #
      def validate_solid_rule(rule)
        errors = []
        warnings = []
        
        dosage_type = rule[:dosage_type] || rule['dosage_type']
        material_prices = rule[:material_prices] || rule['material_prices']
        
        if dosage_type == 'custom'
          # Solo necesita valor por m³
          value = rule[:value] || rule['value']
          unless validate_positive_float(value)
            errors << "Custom solid material price must be positive"
          end
        else
          # Dosificación predefinida
          unless dosage_type && dosage_type.is_a?(String)
            errors << "Dosage type must be a string"
          end
          
          if material_prices && !material_prices.is_a?(Hash)
            errors << "Material prices must be a hash"
          end
        end
        
        { errors: errors, warnings: warnings }
      end
      
      # ==========================================================================
      # VALIDACIONES DE CONFIGURACIÓN
      # ==========================================================================
      
      ##
      # Valida una configuración completa del plugin
      #
      # @param config [Hash] Configuración a validar
      # @return [Hash] Resultado con :valid, :errors, :warnings
      #
      def validate_configuration(config)
        return {
          valid: false,
          errors: ["Configuration cannot be nil"],
          warnings: []
        } if config.nil? || !config.is_a?(Hash)
        
        errors = []
        warnings = []
        
        # Validar unidad actual
        current_unit = config[:current_unit] || config['current_unit']
        unless validate_unit(current_unit)
          errors << "Invalid current unit: #{current_unit}"
        end
        
        # Validar moneda de visualización
        display_currency = config[:display_currency] || config['display_currency']
        if display_currency && !validate_currency_code(display_currency)
          errors << "Invalid display currency: #{display_currency}"
        end
        
        # Validar moneda base
        base_currency = config[:base_currency] || config['base_currency']
        if base_currency && !validate_currency_code(base_currency)
          errors << "Invalid base currency: #{base_currency}"
        end
        
        # Validar idioma actual
        current_lang = config[:current_lang] || config['current_lang']
        if current_lang && !validate_language(current_lang)
          errors << "Unsupported language: #{current_lang}"
        end
        
        # Validar configuración de analytics
        analytics_enabled = config[:analytics_enabled]
        if !analytics_enabled.nil? && ![true, false].include?(analytics_enabled)
          errors << "Analytics enabled must be boolean"
        end
        
        # Validar configuración de logging
        log_to_file = config[:log_to_file]
        if !log_to_file.nil? && ![true, false].include?(log_to_file)
          errors << "Log to file must be boolean"
        end
        
        {
          valid: errors.empty?,
          errors: errors,
          warnings: warnings
        }
      end
      
      # ==========================================================================
      # VALIDACIONES DE DATOS DE ENTRADA
      # ==========================================================================
      
      ##
      # Valida datos de entrada para cálculo
      #
      # @param data [Hash] Datos de entrada
      # @return [Hash] Resultado con :valid, :errors
      #
      def validate_calculation_input(data)
        errors = []
        
        # Validar volumen
        volume = data[:volume] || data['volume']
        unless validate_positive_float(volume, allow_zero: true)
          errors << "Volume must be a non-negative number"
        end
        
        # Validar área
        area = data[:area] || data['area']
        unless validate_positive_float(area, allow_zero: true)
          errors << "Area must be a non-negative number"
        end
        
        # Validar longitud
        length = data[:length] || data['length']
        unless validate_positive_float(length, allow_zero: true)
          errors << "Length must be a non-negative number"
        end
        
        # Validar cantidad de instancias
        instance_count = data[:instance_count] || data['instance_count'] || 1
        unless validate_positive_integer(instance_count, allow_zero: false)
          errors << "Instance count must be a positive integer"
        end
        
        {
          valid: errors.empty?,
          errors: errors
        }
      end
      
      ##
      # Valida datos de entrada para exportación
      #
      # @param data [Hash] Datos a exportar
      # @return [Hash] Resultado con :valid, :errors
      #
      def validate_export_data(data)
        errors = []
        
        return {
          valid: false,
          errors: ["Export data cannot be empty"]
        } if data.nil? || data.empty?
        
        # Validar estructura básica
        unless data.is_a?(Hash)
          errors << "Export data must be a hash"
        end
        
        # Validar estadísticas básicas
        stats_keys = [:count, :volume, :area_surf, :cost]
        stats_keys.each do |key|
          if data[key] && !data[key].is_a?(Numeric)
            errors << "#{key} must be a number"
          end
        end
        
        # Validar ítems si existen
        items = data[:items] || data['items']
        if items && !items.is_a?(Array)
          errors << "Items must be an array"
        end
        
        {
          valid: errors.empty?,
          errors: errors
        }
      end
      
      # ==========================================================================
      # MÉTODO FALTANTE CRÍTICO: validate_selection
      # ==========================================================================
      
      ##
      # Valida la selección actual de SketchUp
      # 
      # Este método es llamado desde calculator.rb
      #
      # @param selection [Array] Array de entidades de SketchUp
      # @return [Boolean] True si la selección es válida
      #
      def validate_selection(selection)
        return false if selection.nil? || selection.empty?
        
        selection.all? { |entity|
          entity.respond_to?(:faces) || 
          entity.is_a?(Sketchup::Face) ||
          entity.is_a?(Sketchup::Group) || 
          entity.is_a?(Sketchup::ComponentInstance)
        }
      end
      
      # ==========================================================================
      # UTILIDADES DE VALIDACIÓN
      # ==========================================================================
      
      ##
      # Formatea errores de validación para mostrar al usuario
      #
      # @param validation_result [Hash] Resultado de validación
      # @return [String] Mensaje formateado
      #
      def format_validation_errors(validation_result)
        return "" unless validation_result.is_a?(Hash)
        
        errors = validation_result[:errors] || []
        warnings = validation_result[:warnings] || []
        
        message = ""
        
        unless errors.empty?
          message << "Errors:\n"
          errors.each { |error| message << "  • #{error}\n" }
        end
        
        unless warnings.empty?
          message << "\nWarnings:\n" unless errors.empty?
          warnings.each { |warning| message << "  • #{warning}\n" }
        end
        
        message
      end
      
      ##
      # Lanza una excepción si la validación falla
      #
      # @param validation_result [Hash] Resultado de validación
      # @raise [RuntimeError] Si la validación no es válida
      #
      def raise_if_invalid!(validation_result, context = "Validation")
        return unless validation_result.is_a?(Hash)
        
        unless validation_result[:valid]
          error_message = format_validation_errors(validation_result)
          raise "#{context} failed:\n#{error_message}"
        end
      end
      
      ##
      # Valida y limpia un string para uso seguro
      #
      # @param str [String] String a limpiar
      # @param max_length [Integer] Longitud máxima
      # @return [String, nil] String limpio o nil si es inválido
      #
      def sanitize_string(str, max_length = 255)
        return nil unless str.is_a?(String)
        
        # Limpiar espacios
        cleaned = str.strip
        
        # Limitar longitud
        if cleaned.length > max_length
          cleaned = cleaned[0...max_length]
        end
        
        # Validar caracteres (UTF-8 válido)
        begin
          cleaned.encode('UTF-8', invalid: :replace, undef: :replace)
          cleaned
        rescue
          nil
        end
      end
      
    end
  end
end
