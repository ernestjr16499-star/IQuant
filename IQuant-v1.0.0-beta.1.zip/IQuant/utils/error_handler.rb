# encoding: UTF-8

module IQuant
  module Utils
    module ErrorHandler
      extend self
      
      # Manejo seguro de ejecución
      def safe_execute(operation, &block)
        return unless block_given?
        
        begin
          # Intentar usar logger si está disponible
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.info("▶️  Ejecutando: #{operation}")
          else
            puts "▶️  Ejecutando: #{operation}"
          end
          
          # Ejecutar el bloque
          result = yield
          
          # Log de éxito
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.success("✅ Completado: #{operation}")
          else
            puts "✅ Completado: #{operation}"
          end
          
          result
          
        rescue => e
          # Manejo de error robusto
          handle_error(e, operation)
          nil  # Retornar nil en caso de error
        end
      end
      
      # Manejo de errores
      def handle_error(error, context = "Operación")
        error_message = "#{context} falló: #{error.message}"
        
        # Intentar diferentes métodos de logging
        begin
          # 1. Intentar con nuestro logger
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.error(error_message)
            error.backtrace.first(3).each do |line|
              IQuant::Utils::Logger.error("  #{line}")
            end
          # 2. Usar puts directo
          else
            puts "❌ #{error_message}"
            puts "   Detalle: #{error.backtrace.first}"
          end
        rescue
          # 3. Fallback absoluto
          begin
            Sketchup.write_operation_status("IQuant Error: #{error.message}") rescue nil
          rescue
            # Silenciar si todo falla
          end
        end
      end
      
      # Validar y ejecutar con reintentos
      def execute_with_retry(operation, max_retries = 2, &block)
        retries = 0
        
        while retries <= max_retries
          begin
            return safe_execute(operation, &block)
          rescue => e
            retries += 1
            if retries <= max_retries
              puts "⚠️  Reintentando #{operation} (#{retries}/#{max_retries})..."
              sleep(0.1 * retries)  # Espera incremental
            else
              handle_error(e, "#{operation} después de #{max_retries} reintentos")
              return nil
            end
          end
        end
      end
      
      # Verificar condiciones antes de ejecutar
      def execute_if(condition, operation, &block)
        if condition
          safe_execute(operation, &block)
        else
          if defined?(IQuant::Utils::Logger)
            IQuant::Utils::Logger.warn("⏭️  Omitido: #{operation} (condición no cumplida)")
          else
            puts "⏭️  Omitido: #{operation} (condición no cumplida)"
          end
          nil
        end
      end
    end
  end
end

# Inicializar
begin
  IQuant::Utils::ErrorHandler.safe_execute("Cargar ErrorHandler") do
    puts "✅ ErrorHandler de IQuantum cargado"
  end
rescue => e
  puts "Error cargando ErrorHandler: #{e.message}"
end
