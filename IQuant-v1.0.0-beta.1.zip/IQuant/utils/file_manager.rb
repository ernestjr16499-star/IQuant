# utils/file_manager.rb
# Gestor de archivos para iQuant v4.1 - creado desde cero

module IQuant
  module Utils
    module FileManager
      extend self
      
      # ==========================================================================
      # CONFIGURACIÓN
      # ==========================================================================
      
      # Codificación por defecto para archivos de texto
      DEFAULT_ENCODING = 'UTF-8'
      
      # Permisos por defecto para directorios
      DEFAULT_DIR_PERMISSIONS = 0755
      
      # ==========================================================================
      # MÉTODOS PRINCIPALES
      # ==========================================================================
      
      ##
      # Guarda contenido en un archivo
      #
      # @param content [String, Array] Contenido a guardar (String o Array de líneas)
      # @param path [String] Ruta del archivo
      # @param options [Hash] Opciones adicionales
      #   - encoding: Codificación del archivo (default: DEFAULT_ENCODING)
      #   - mode: Modo de apertura del archivo (default: 'w')
      #   - create_dir: Crear directorio si no existe (default: true)
      # @return [Boolean] True si se guardó exitosamente, False si hubo error
      #
      def save_to_file(content, path, options = {})
        return false if content.nil? || path.to_s.empty?
        
        encoding = options[:encoding] || DEFAULT_ENCODING
        mode = options[:mode] || 'w'
        create_dir = options.fetch(:create_dir, true)
        
        safe_execute("Save to file: #{path}") do
          # Crear directorio si es necesario
          if create_dir
            dir_path = File.dirname(path)
            ensure_directory(dir_path)
          end
          
          # Convertir array a string si es necesario
          if content.is_a?(Array)
            content = content.join($/)  # Usar separador de línea del sistema
          end
          
          # Guardar contenido
          File.open(path, mode, encoding: encoding) do |file|
            file.write(content)
          end
          
          log_message("Archivo guardado exitosamente: #{path}", :info)
          true
        rescue Errno::EACCES => e
          log_message("Permiso denegado para escribir en: #{path}", :error)
          false
        rescue Errno::ENOENT => e
          log_message("Ruta no encontrada: #{path}", :error)
          false
        rescue Errno::EROFS => e
          log_message("Sistema de archivos de solo lectura: #{path}", :error)
          false
        rescue => e
          log_message("Error al guardar archivo #{path}: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Lee un archivo y retorna su contenido
      #
      # @param path [String] Ruta del archivo
      # @param options [Hash] Opciones adicionales
      #   - encoding: Codificación del archivo (default: DEFAULT_ENCODING)
      #   - mode: Modo de apertura del archivo (default: 'r')
      #   - as_lines: Retornar como array de líneas (default: false)
      # @return [String, Array, nil] Contenido del archivo o nil si hay error
      #
      def read_from_file(path, options = {})
        return nil unless file_exists?(path)
        
        encoding = options[:encoding] || DEFAULT_ENCODING
        mode = options[:mode] || 'r'
        as_lines = options.fetch(:as_lines, false)
        
        safe_execute("Read from file: #{path}") do
          content = File.read(path, encoding: encoding, mode: mode)
          
          if as_lines
            # Retornar como array de líneas (manteniendo saltos de línea)
            lines = content.lines.map(&:chomp)
            log_message("Archivo leído exitosamente: #{path} (#{lines.size} líneas)", :debug)
            lines
          else
            log_message("Archivo leído exitosamente: #{path} (#{content.size} bytes)", :debug)
            content
          end
        rescue Errno::EACCES => e
          log_message("Permiso denegado para leer: #{path}", :error)
          nil
        rescue Errno::ENOENT => e
          log_message("Archivo no encontrado: #{path}", :error)
          nil
        rescue => e
          log_message("Error al leer archivo #{path}: #{e.message}", :error)
          nil
        end
      end
      
      ##
      # Verifica si un archivo existe
      #
      # @param path [String] Ruta del archivo
      # @return [Boolean] True si el archivo existe y es legible
      #
      def file_exists?(path)
        return false if path.to_s.empty?
        
        begin
          exists = File.exist?(path) && File.file?(path) && File.readable?(path)
          log_message("Verificación de archivo #{path}: #{exists ? 'EXISTE' : 'NO EXISTE'}", :debug)
          exists
        rescue => e
          log_message("Error verificando existencia de archivo #{path}: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Verifica si un directorio existe
      #
      # @param path [String] Ruta del directorio
      # @return [Boolean] True si el directorio existe y es accesible
      #
      def directory_exists?(path)
        return false if path.to_s.empty?
        
        begin
          exists = File.exist?(path) && File.directory?(path) && File.readable?(path)
          log_message("Verificación de directorio #{path}: #{exists ? 'EXISTE' : 'NO EXISTE'}", :debug)
          exists
        rescue => e
          log_message("Error verificando existencia de directorio #{path}: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Crea el directorio si no existe
      #
      # @param path [String] Ruta del directorio
      # @param permissions [Integer] Permisos del directorio (octal, default: 0755)
      # @return [Boolean] True si el directorio existe o se creó exitosamente
      #
      def ensure_directory(path, permissions = DEFAULT_DIR_PERMISSIONS)
        return false if path.to_s.empty?
        
        safe_execute("Ensure directory: #{path}") do
          # Si ya existe, verificar que sea un directorio
          if directory_exists?(path)
            log_message("El directorio ya existe: #{path}", :debug)
            return true
          end
          
          # Crear directorio recursivamente
          begin
            require 'fileutils'
            FileUtils.mkdir_p(path, mode: permissions)
            
            if directory_exists?(path)
              log_message("Directorio creado exitosamente: #{path}", :info)
              true
            else
              log_message("No se pudo crear el directorio: #{path}", :error)
              false
            end
          rescue Errno::EACCES => e
            log_message("Permiso denegado para crear directorio: #{path}", :error)
            false
          rescue Errno::EROFS => e
            log_message("Sistema de archivos de solo lectura: #{path}", :error)
            false
          rescue => e
            log_message("Error al crear directorio #{path}: #{e.message}", :error)
            false
          end
        end
      end
      
      # ==========================================================================
      # MÉTODOS DE CONVENIENCIA
      # ==========================================================================
      
      ##
      # Copia un archivo de origen a destino
      #
      # @param source [String] Ruta del archivo origen
      # @param destination [String] Ruta del archivo destino
      # @param options [Hash] Opciones adicionales
      #   - overwrite: Sobrescribir si existe (default: false)
      #   - create_dir: Crear directorio destino si no existe (default: true)
      # @return [Boolean] True si se copió exitosamente
      #
      def copy_file(source, destination, options = {})
        return false unless file_exists?(source)
        
        overwrite = options.fetch(:overwrite, false)
        create_dir = options.fetch(:create_dir, true)
        
        # Verificar si el archivo destino ya existe
        if file_exists?(destination) && !overwrite
          log_message("El archivo destino ya existe y overwrite=false: #{destination}", :warn)
          return false
        end
        
        safe_execute("Copy file: #{source} -> #{destination}") do
          # Crear directorio destino si es necesario
          if create_dir
            dest_dir = File.dirname(destination)
            ensure_directory(dest_dir)
          end
          
          require 'fileutils'
          FileUtils.cp(source, destination)
          
          if file_exists?(destination)
            log_message("Archivo copiado exitosamente: #{source} -> #{destination}", :info)
            true
          else
            log_message("Error: El archivo no se copió correctamente", :error)
            false
          end
        rescue Errno::EACCES => e
          log_message("Permiso denegado para copiar archivo: #{e.message}", :error)
          false
        rescue => e
          log_message("Error al copiar archivo: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Mueve un archivo de origen a destino
      #
      # @param source [String] Ruta del archivo origen
      # @param destination [String] Ruta del archivo destino
      # @param options [Hash] Opciones adicionales
      #   - overwrite: Sobrescribir si existe (default: false)
      #   - create_dir: Crear directorio destino si no existe (default: true)
      # @return [Boolean] True si se movió exitosamente
      #
      def move_file(source, destination, options = {})
        return false unless file_exists?(source)
        
        overwrite = options.fetch(:overwrite, false)
        create_dir = options.fetch(:create_dir, true)
        
        # Verificar si el archivo destino ya existe
        if file_exists?(destination) && !overwrite
          log_message("El archivo destino ya existe y overwrite=false: #{destination}", :warn)
          return false
        end
        
        safe_execute("Move file: #{source} -> #{destination}") do
          # Crear directorio destino si es necesario
          if create_dir
            dest_dir = File.dirname(destination)
            ensure_directory(dest_dir)
          end
          
          require 'fileutils'
          FileUtils.mv(source, destination)
          
          if file_exists?(destination)
            log_message("Archivo movido exitosamente: #{source} -> #{destination}", :info)
            true
          else
            log_message("Error: El archivo no se movió correctamente", :error)
            false
          end
        rescue Errno::EACCES => e
          log_message("Permiso denegado para mover archivo: #{e.message}", :error)
          false
        rescue => e
          log_message("Error al mover archivo: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Elimina un archivo
      #
      # @param path [String] Ruta del archivo
      # @return [Boolean] True si se eliminó exitosamente o no existía
      #
      def delete_file(path)
        return true unless file_exists?(path)
        
        safe_execute("Delete file: #{path}") do
          require 'fileutils'
          FileUtils.rm(path)
          
          if file_exists?(path)
            log_message("Error: El archivo no se eliminó: #{path}", :error)
            false
          else
            log_message("Archivo eliminado exitosamente: #{path}", :info)
            true
          end
        rescue Errno::EACCES => e
          log_message("Permiso denegado para eliminar archivo: #{path}", :error)
          false
        rescue => e
          log_message("Error al eliminar archivo #{path}: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Elimina un directorio y todo su contenido
      #
      # @param path [String] Ruta del directorio
      # @param force [Boolean] Forzar eliminación incluso si no está vacío (default: true)
      # @return [Boolean] True si se eliminó exitosamente o no existía
      #
      def delete_directory(path, force = true)
        return true unless directory_exists?(path)
        
        safe_execute("Delete directory: #{path}") do
          require 'fileutils'
          
          if force
            FileUtils.rm_rf(path)
          else
            FileUtils.rmdir(path)
          end
          
          if directory_exists?(path)
            log_message("Error: El directorio no se eliminó: #{path}", :error)
            false
          else
            log_message("Directorio eliminado exitosamente: #{path}", :info)
            true
          end
        rescue Errno::EACCES => e
          log_message("Permiso denegado para eliminar directorio: #{path}", :error)
          false
        rescue Errno::ENOTEMPTY => e
          log_message("Directorio no vacío (use force=true): #{path}", :error)
          false
        rescue => e
          log_message("Error al eliminar directorio #{path}: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Obtiene el tamaño de un archivo en bytes
      #
      # @param path [String] Ruta del archivo
      # @return [Integer, nil] Tamaño en bytes o nil si hay error
      #
      def file_size(path)
        return nil unless file_exists?(path)
        
        begin
          size = File.size(path)
          log_message("Tamaño del archivo #{path}: #{size} bytes", :debug)
          size
        rescue => e
          log_message("Error obteniendo tamaño del archivo #{path}: #{e.message}", :error)
          nil
        end
      end
      
      ##
      # Obtiene la fecha de modificación de un archivo
      #
      # @param path [String] Ruta del archivo
      # @return [Time, nil] Fecha de modificación o nil si hay error
      #
      def file_modified_time(path)
        return nil unless file_exists?(path)
        
        begin
          mtime = File.mtime(path)
          log_message("Fecha modificación de #{path}: #{mtime}", :debug)
          mtime
        rescue => e
          log_message("Error obteniendo fecha de modificación de #{path}: #{e.message}", :error)
          nil
        end
      end
      
      ##
      # Lista archivos en un directorio
      #
      # @param path [String] Ruta del directorio
      # @param pattern [String] Patrón para filtrar archivos (ej: "*.txt")
      # @param recursive [Boolean] Buscar recursivamente en subdirectorios (default: false)
      # @return [Array<String>] Lista de rutas de archivos
      #
      def list_files(path, pattern = "*", recursive = false)
        return [] unless directory_exists?(path)
        
        safe_execute("List files in: #{path}") do
          if recursive
            require 'find'
            files = []
            Find.find(path) do |file_path|
              next unless File.file?(file_path)
              next unless File.fnmatch(pattern, File.basename(file_path))
              files << file_path
            end
            files
          else
            Dir[File.join(path, pattern)].select { |f| File.file?(f) }
          end
        rescue => e
          log_message("Error listando archivos en #{path}: #{e.message}", :error)
          []
        end
      end
      
      ##
      # Lista directorios en un directorio
      #
      # @param path [String] Ruta del directorio
      # @param pattern [String] Patrón para filtrar directorios (ej: "*")
      # @return [Array<String>] Lista de rutas de directorios
      #
      def list_directories(path, pattern = "*")
        return [] unless directory_exists?(path)
        
        safe_execute("List directories in: #{path}") do
          Dir[File.join(path, pattern)].select { |f| File.directory?(f) }
        rescue => e
          log_message("Error listando directorios en #{path}: #{e.message}", :error)
          []
        end
      end
      
      # ==========================================================================
      # MÉTODOS DE LOGGING Y SEGURIDAD
      # ==========================================================================
      
      private
      
      ##
      # Registra un mensaje en el log si Logger está disponible
      #
      # @param message [String] Mensaje a loguear
      # @param level [Symbol] Nivel de log (:debug, :info, :warn, :error, :success)
      #
      def log_message(message, level = :info)
        if defined?(IQuant::Utils::Logger)
          IQuant::Utils::Logger.log(message, level)
        elsif defined?(IQuant::DEBUG_MODE) && IQuant::DEBUG_MODE
          puts "[FileManager #{level.to_s.upcase}] #{message}"
        end
      end
      
      ##
      # Ejecuta un bloque de código de forma segura
      #
      # @param operation [String] Nombre de la operación
      # @param block [Proc] Bloque de código a ejecutar
      # @return [Object] Resultado del bloque o nil si falla
      #
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          begin
            yield
          rescue => e
            log_message("Error en #{operation}: #{e.message}", :error)
            nil
          end
        end
      end
      
    end
  end
end
