# utils/config_manager.rb
# Gestor de configuración para iQuant v4.1 - creado desde cero

module IQuant
  module Utils
    module ConfigManager
      extend self
      
      # ==========================================================================
      # CONSTANTES DE CONFIGURACIÓN
      # ==========================================================================
      
      # Claves de configuración por defecto
      DEFAULT_CONFIG = {
        # Configuraciones de usuario
        language: 'en',
        unit: 'm',
        display_currency: 'USD',
        base_currency: 'USD',
        analytics_enabled: true,
        
        # Configuraciones del proyecto
        project: '',
        client: '',
        company: '',
        
        # Configuraciones de tasas de cambio
        usd_exchange_rate: 1.0,
        eur_exchange_rate: 1.0,
        
        # Configuraciones de visualización
        theme: 'light',
        show_tutorial: true,
        auto_refresh: true,
        
        # Configuraciones de exportación
        export_path: nil,
        last_export_format: 'csv',
        export_include_materials: true,
        export_include_categories: true,
        
        # Configuraciones de licencia (se llenan desde licensing.rb)
        license_key: nil,
        trial_start_date: nil,
        export_count: 0,
        license_status: :trial  # :trial, :licensed, :expired
      }.freeze
      
      # ==========================================================================
      # MÉTODOS PRINCIPALES
      # ==========================================================================
      
      ##
      # Carga la configuración del plugin desde las preferencias de SketchUp
      #
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @return [Hash] Configuración cargada (valores por defecto si no hay configuración guardada)
      #
      def load_config(model = nil)
        config = DEFAULT_CONFIG.dup
        
        safe_execute('Cargar configuración') do
          # Obtener modelo activo si no se proporciona
          model ||= Sketchup.active_model
          return config unless model && model.valid?
          
          # Verificar que la clave de preferencias esté definida
          unless defined?(IQuant::PREFS_KEY)
            log_message("IQuant::PREFS_KEY no está definida", :error)
            return config
          end
          
          # Cargar cada valor desde las preferencias del modelo
          config.each_key do |key|
            value = model.get_attribute(IQuant::PREFS_KEY, key.to_s)
            
            # Solo asignar si el valor no es nil (SketchUp retorna nil si no existe)
            unless value.nil?
              # Convertir strings a símbolos si corresponde
              if value.is_a?(String) && [:license_status].include?(key)
                begin
                  value = value.to_sym
                rescue
                  value = DEFAULT_CONFIG[key]
                end
              # Convertir strings a booleanos si corresponde
              elsif value.is_a?(String) && [:analytics_enabled, :show_tutorial, :auto_refresh, 
                                             :export_include_materials, :export_include_categories].include?(key)
                value = value.downcase == 'true'
              # Convertir strings a números si corresponde
              elsif value.is_a?(String) && [:usd_exchange_rate, :eur_exchange_rate, :export_count].include?(key)
                begin
                  value = Float(value)
                rescue
                  value = DEFAULT_CONFIG[key]
                end
              end
              
              config[key] = value
            end
          end
          
          log_message("Configuración cargada exitosamente (#{config.size} valores)", :info)
        rescue => e
          log_message("Error cargando configuración: #{e.message}", :error)
          log_message("Backtrace: #{e.backtrace.first(5).join(', ')}", :debug) if defined?(IQuant::DEBUG_MODE) && IQuant::DEBUG_MODE
        end
        
        config
      end
      
      ##
      # Guarda una configuración en las preferencias de SketchUp
      #
      # @param key [String, Symbol] Clave de la configuración
      # @param value [Object] Valor a guardar
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @return [Boolean] True si se guardó exitosamente
      #
      def save_config(key, value, model = nil)
        return false if key.to_s.empty?
        
        safe_execute("Guardar configuración: #{key}") do
          # Obtener modelo activo si no se proporciona
          model ||= Sketchup.active_model
          return false unless model && model.valid?
          
          # Verificar que la clave de preferencias esté definida
          unless defined?(IQuant::PREFS_KEY)
            log_message("IQuant::PREFS_KEY no está definida", :error)
            return false
          end
          
          # Convertir valor a formato almacenable
          stored_value = case value
          when Symbol
            value.to_s
          when TrueClass, FalseClass
            value.to_s
          when Numeric
            value.to_f.to_s  # Guardar como string para consistencia
          when NilClass
            ''  # Guardar string vacío para nil
          else
            value.to_s
          end
          
          # Guardar en las preferencias del modelo
          model.set_attribute(IQuant::PREFS_KEY, key.to_s, stored_value)
          
          log_message("Configuración guardada: #{key} = #{value.inspect}", :debug)
          true
        rescue => e
          log_message("Error guardando configuración #{key}: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Guarda múltiples configuraciones a la vez
      #
      # @param config_hash [Hash] Hash de configuraciones {clave: valor}
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @return [Boolean] True si todas se guardaron exitosamente
      #
      def save_config_batch(config_hash, model = nil)
        return false unless config_hash.is_a?(Hash) && !config_hash.empty?
        
        safe_execute("Guardar configuración en lote") do
          success = true
          config_hash.each do |key, value|
            unless save_config(key, value, model)
              log_message("Fallo al guardar configuración: #{key}", :warn)
              success = false
            end
          end
          
          if success
            log_message("Configuración en lote guardada exitosamente (#{config_hash.size} valores)", :info)
          else
            log_message("Algunas configuraciones no se guardaron correctamente", :warn)
          end
          
          success
        end
      end
      
      ##
      # Elimina una configuración de las preferencias
      #
      # @param key [String, Symbol] Clave de la configuración a eliminar
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @return [Boolean] True si se eliminó exitosamente
      #
      def delete_config(key, model = nil)
        return false if key.to_s.empty?
        
        safe_execute("Eliminar configuración: #{key}") do
          # Obtener modelo activo si no se proporciona
          model ||= Sketchup.active_model
          return false unless model && model.valid?
          
          # Verificar que la clave de preferencias esté definida
          unless defined?(IQuant::PREFS_KEY)
            log_message("IQuant::PREFS_KEY no está definida", :error)
            return false
          end
          
          # Eliminar atributo
          model.delete_attribute(IQuant::PREFS_KEY, key.to_s)
          
          log_message("Configuración eliminada: #{key}", :info)
          true
        rescue => e
          log_message("Error eliminando configuración #{key}: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Resetea la configuración a los valores por defecto
      #
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @return [Hash] Configuración reseteada (valores por defecto)
      #
      def reset_config(model = nil)
        safe_execute("Resetear configuración") do
          # Obtener modelo activo si no se proporciona
          model ||= Sketchup.active_model
          return DEFAULT_CONFIG.dup unless model && model.valid?
          
          # Verificar que la clave de preferencias esté definida
          unless defined?(IQuant::PREFS_KEY)
            log_message("IQuant::PREFS_KEY no está definida", :error)
            return DEFAULT_CONFIG.dup
          end
          
          # Eliminar todo el diccionario de atributos
          model.delete_attribute(IQuant::PREFS_KEY)
          
          log_message("Configuración reseteada a valores por defecto", :info)
          DEFAULT_CONFIG.dup
        rescue => e
          log_message("Error reseteando configuración: #{e.message}", :error)
          DEFAULT_CONFIG.dup
        end
      end
      
      ##
      # Exporta la configuración a un archivo JSON
      #
      # @param file_path [String] Ruta del archivo de exportación
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @return [Boolean] True si se exportó exitosamente
      #
      def export_config(file_path, model = nil)
        safe_execute("Exportar configuración a #{file_path}") do
          # Cargar configuración actual
          config = load_config(model)
          
          # Convertir símbolos a strings para JSON
          json_config = config.transform_values do |value|
            if value.is_a?(Symbol)
              value.to_s
            else
              value
            end
          end
          
          # Asegurar que el directorio existe
          if defined?(IQuant::Utils::FileManager)
            IQuant::Utils::FileManager.ensure_directory(File.dirname(file_path))
          else
            require 'fileutils'
            FileUtils.mkdir_p(File.dirname(file_path)) rescue nil
          end
          
          # Guardar como JSON
          require 'json'
          File.write(file_path, JSON.pretty_generate(json_config))
          
          log_message("Configuración exportada a: #{file_path}", :info)
          true
        rescue => e
          log_message("Error exportando configuración: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Importa configuración desde un archivo JSON
      #
      # @param file_path [String] Ruta del archivo de importación
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @param merge [Boolean] Fusionar con configuración existente (true) o reemplazar (false)
      # @return [Boolean] True si se importó exitosamente
      #
      def import_config(file_path, model = nil, merge = true)
        safe_execute("Importar configuración desde #{file_path}") do
          # Verificar que el archivo exista
          unless File.exist?(file_path)
            log_message("Archivo de configuración no encontrado: #{file_path}", :error)
            return false
          end
          
          # Leer y parsear JSON
          require 'json'
          json_content = File.read(file_path)
          imported_config = JSON.parse(json_content, symbolize_names: true)
          
          # Cargar configuración actual si estamos fusionando
          current_config = merge ? load_config(model) : {}
          
          # Fusionar configuraciones
          final_config = current_config.merge(imported_config)
          
          # Guardar configuración fusionada
          save_config_batch(final_config, model)
          
          log_message("Configuración importada desde: #{file_path}", :info)
          true
        rescue JSON::ParserError => e
          log_message("Error parseando archivo JSON: #{e.message}", :error)
          false
        rescue => e
          log_message("Error importando configuración: #{e.message}", :error)
          false
        end
      end
      
      ##
      # Lista todas las configuraciones guardadas
      #
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @return [Array<String>] Lista de claves de configuración
      #
      def list_config_keys(model = nil)
        safe_execute("Listar claves de configuración") do
          # Obtener modelo activo si no se proporciona
          model ||= Sketchup.active_model
          return [] unless model && model.valid?
          
          # Verificar que la clave de preferencias esté definida
          unless defined?(IQuant::PREFS_KEY)
            log_message("IQuant::PREFS_KEY no está definida", :error)
            return []
          end
          
          # Obtener diccionario de atributos
          dict = model.attribute_dictionary(IQuant::PREFS_KEY)
          return [] unless dict
          
          keys = dict.keys || []
          log_message("Claves de configuración encontradas: #{keys.size}", :debug)
          keys
        rescue => e
          log_message("Error listando claves de configuración: #{e.message}", :error)
          []
        end
      end
      
      # ==========================================================================
      # MÉTODOS DE CONVENIENCIA
      # ==========================================================================
      
      ##
      # Obtiene un valor de configuración específico
      #
      # @param key [String, Symbol] Clave de la configuración
      # @param default [Object] Valor por defecto si no existe
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @return [Object] Valor de la configuración o valor por defecto
      #
      def get_config(key, default = nil, model = nil)
        config = load_config(model)
        config[key.to_sym] || default
      end
      
      ##
      # Verifica si una configuración existe
      #
      # @param key [String, Symbol] Clave de la configuración
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @return [Boolean] True si la configuración existe
      #
      def has_config?(key, model = nil)
        list_config_keys(model).include?(key.to_s)
      end
      
      ##
      # Obtiene la ruta de exportación por defecto basada en el modelo actual
      #
      # @param model [Sketchup::Model, nil] Modelo de SketchUp (nil = active_model)
      # @return [String] Ruta de exportación sugerida
      #
      def default_export_path(model = nil)
        model ||= Sketchup.active_model
        return '' unless model
        
        model_path = model.path
        model_name = File.basename(model_path, '.*')
        
        if model_path && !model_path.empty?
          # Si el modelo está guardado, usar su directorio
          export_dir = File.join(File.dirname(model_path), 'iQuant_Exports')
          File.join(export_dir, "#{model_name}_#{Time.now.strftime('%Y%m%d_%H%M%S')}")
        else
          # Si el modelo no está guardado, usar documentos del usuario
          documents_dir = File.expand_path('~/Documents')
          export_dir = File.join(documents_dir, 'iQuant_Exports')
          File.join(export_dir, "Unsaved_#{Time.now.strftime('%Y%m%d_%H%M%S')}")
        end
      end
      
      # ==========================================================================
      # MÉTODOS DE LOGGING Y SEGURIDAD
      # ==========================================================================
      
      private
      
      ##
      # Registra un mensaje en el log si Logger está disponible
      #
      # @param message [String] Mensaje a loguear
      # @param level [Symbol] Nivel de log (:debug, :info, :warn, :error, :success)
      #
      def log_message(message, level = :info)
        if defined?(IQuant::Utils::Logger)
          IQuant::Utils::Logger.log(message, level)
        elsif defined?(IQuant::DEBUG_MODE) && IQuant::DEBUG_MODE
          puts "[ConfigManager #{level.to_s.upcase}] #{message}"
        end
      end
      
      ##
      # Ejecuta un bloque de código de forma segura
      #
      # @param operation [String] Nombre de la operación
      # @param block [Proc] Bloque de código a ejecutar
      # @return [Object] Resultado del bloque o nil si falla
      #
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          begin
            yield
          rescue => e
            log_message("Error en #{operation}: #{e.message}", :error)
            nil
          end
        end
      end
      
    end
  end
end
