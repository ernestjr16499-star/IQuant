# encoding: UTF-8

module IQuant
  module Utils
    module Logger
      extend self
      
      # Niveles de log
      LEVELS = {
        debug: 0,
        info: 1,
        warn: 2,
        error: 3,
        success: 4
      }.freeze
      
      # Configuración
      LOG_LEVEL = :info
      LOG_TO_FILE = false
      LOG_FILE = File.join(IQuant::PLUGIN_DIR, 'logs', 'iquant.log')
      
      # Colores para terminal (solo si está disponible)
      COLORS = {
        debug:   "\e[36m",  # cyan
        info:    "\e[34m",  # blue
        warn:    "\e[33m",  # yellow
        error:   "\e[31m",  # red
        success: "\e[32m",  # green
        reset:   "\e[0m"    # reset
      }
      
      # Formato de tiempo
      def time_format
        Time.now.strftime("%Y-%m-%d %H:%M:%S")
      end
      
      # Verificar si podemos usar colores (método seguro para SketchUp)
      def use_colors?
        # En SketchUp, NO usar tty? porque no está disponible
        # En su lugar, verificar si estamos en la consola de SketchUp
        defined?(Sketchup) && Sketchup.platform == :platform_win
      rescue
        false
      end
      
      # Método principal de logging
      def log(message, level = :info)
        return unless should_log?(level)
        
        timestamp = time_format
        level_str = level.to_s.upcase
        
        # Mensaje formateado para consola
        console_message = format_console_message(timestamp, level_str, message, level)
        
        # Mensaje formateado para archivo (sin colores)
        file_message = format_file_message(timestamp, level_str, message)
        
        # Imprimir a consola
        output_to_console(console_message)
        
        # Escribir a archivo si está habilitado
        output_to_file(file_message) if LOG_TO_FILE
      end
      
      # Métodos de conveniencia
      def debug(message)   log(message, :debug)   end
      def info(message)    log(message, :info)    end
      def warn(message)    log(message, :warn)    end
      def error(message)   log(message, :error)   end
      def success(message) log(message, :success) end
      
      private
      
      def should_log?(level)
        LEVELS[level] >= LEVELS[LOG_LEVEL]
      end
      
      def format_console_message(timestamp, level_str, message, level)
        if use_colors?
          "#{COLORS[level]}[#{timestamp}] #{level_str.rjust(8)}: #{message}#{COLORS[:reset]}"
        else
          "[#{timestamp}] #{level_str.rjust(8)}: #{message}"
        end
      end
      
      def format_file_message(timestamp, level_str, message)
        "[#{timestamp}] #{level_str.rjust(8)}: #{message}"
      end
      
      def output_to_console(message)
        # Usar puts seguro para SketchUp
        begin
          puts message
        rescue
          # Fallback si puts falla
          Sketchup.write_operation_status(message) rescue nil
        end
      end
      
      def output_to_file(message)
        # Crear directorio de logs si no existe
        log_dir = File.dirname(LOG_FILE)
        Dir.mkdir(log_dir) unless Dir.exist?(log_dir)
        
        # Escribir al archivo
        File.open(LOG_FILE, 'a') do |f|
          f.puts(message)
        end
      rescue => e
        # Silenciar error de archivo para no romper el plugin
        puts "[LOGGER ERROR] No se pudo escribir en archivo: #{e.message}"
      end
      
      # Helper para loggear excepciones
      def log_exception(e, context = "Error")
        error("#{context}: #{e.message}")
        e.backtrace.first(5).each do |line|
          error("  #{line}")
        end
      end
    end
  end
end

# Inicializar logger
begin
  IQuant::Utils::Logger.info("Logger de IQuantum inicializado")
rescue => e
  puts "Error inicializando logger: #{e.message}"
end
