# encoding: UTF-8

module IQuant
  module Main
    extend self

    # Método de inicialización principal
    def init_plugin
      puts "🔧 Inicializando IQuantum v#{IQuant::PLUGIN_VERSION}..."
      register_plugin
      true
    rescue => e
      puts "❌ Error al inicializar: #{e.message}"
      puts e.backtrace.first(5).join("\n")
      false
    end

    # Registrar el plugin (sin doble registro)
    def register_plugin
      create_menu
      puts "✅ Plugin registrado exitosamente"
      true
    rescue => e
      puts "❌ Error al registrar plugin: #{e.message}"
      false
    end


    # Crear el menú de Extensions
    def create_menu
      # Usar ::UI para acceder al UI global de SketchUp (no IQuant::UI)
      return unless defined?(::UI)
      
      # Crear menú principal
      menu = ::UI.menu('Extensions')
      submenu = menu.add_submenu(IQuant::PLUGIN_NAME)
      
      # Agregar items del menú
      submenu.add_item("Abrir IQuant") {
        show_main_dialog
      }
      
      submenu.add_separator
      
      submenu.add_item("Acerca de...") {
        show_about_dialog
      }
      
      puts "✅ Menú creado en Extensions"
    rescue => e
      puts "❌ Error al crear menú: #{e.message}"
      puts e.backtrace.first(3).join("\n")
    end

    # Mostrar diálogo principal
    def show_main_dialog
      if defined?(IQuant::UI::DialogManager)
        IQuant::UI::DialogManager.show_dialog
      else
        ::UI.messagebox("IQuant UI en desarrollo...\n\nVersión: #{IQuant::PLUGIN_VERSION}")
      end
    rescue => e
      ::UI.messagebox("Error al abrir IQuant:\n#{e.message}")
    end

    # Mostrar diálogo "Acerca de"
    def show_about_dialog
      message = "#{IQuant::PLUGIN_NAME}\n"
      message += "Versión: #{IQuant::PLUGIN_VERSION}\n"
      message += "Autor: #{IQuant::PLUGIN_AUTHOR}\n\n"
      message += IQuant::PLUGIN_DESC
      
      ::UI.messagebox(message, MB_OK, IQuant::PLUGIN_NAME)
    end

    # Método auxiliar para cargar archivos
    def load_file_safely(file_path)
      require file_path
      true
    rescue LoadError => e
      puts "⚠️ No se pudo cargar: #{file_path}"
      puts "   Error: #{e.message}"
      false
    rescue => e
      puts "❌ Error al cargar #{file_path}:"
      puts "   #{e.message}"
      false
    end

  end
end
