﻿# features/material_viewer_2d.rb
# encoding: UTF-8

module IQuant
  module Features
    module MaterialViewer2D
      extend self
      
      ##
      # Verifica si el visualizador 2D está habilitado
      #
      # @return [Boolean]
      #
      def enabled?
        # Siempre habilitado para esta versión
        true
      end
      
      ##
      # Inicializa el visualizador 2D en el diálogo HTML
      #
      # @param dialog [UI::HtmlDialog] Diálogo activo
      #
      def init_viewer(dialog)
        return unless enabled?
        
        safe_execute('Inicializar visualizador 2D') do
          # Inicializar el panel flotante de visualización 2D
          # Esta función será llamada desde JavaScript cuando el DOM esté listo
          IQuant::Utils::Logger.log("Visualizador 2D inicializado", :info) if defined?(IQuant::Utils::Logger)
        end
      end
      
      ##
      # Actualiza el visualizador 2D con la selección actual
      #
      # @param dialog [UI::HtmlDialog] Diálogo activo
      # @param selection_data [Hash] Datos de la selección
      #
      def update_viewer(dialog, selection_data)
        return unless enabled? && dialog && dialog.visible?
        
        safe_execute('Actualizar visualizador 2D') do
          # Preparar datos para el visualizador
          viewer_data = prepare_viewer_data(selection_data)
          
          # Actualizar el visualizador via JavaScript
          json_data = JSON.generate(viewer_data).gsub("'", "\\\\'")
          
          # Verificación adicional antes de ejecutar script
          if dialog && dialog.visible?
            dialog.execute_script("
              if (typeof window.updateMaterialViewer2D === 'function') {
                window.updateMaterialViewer2D(#{json_data});
              }
            ")
          end
          
          IQuant::Utils::Logger.log("Visualizador 2D actualizado", :debug) if defined?(IQuant::Utils::Logger)
        end
      end
      
      ##
      # Prepara datos para el visualizador 2D
      #
      # @param selection_data [Hash] Datos de la selección
      # @return [Hash] Datos formateados para el visualizador
      #
      def prepare_viewer_data(selection_data)
        lang = IQuant.current_lang || 'en'
        
        # Extraer información de materiales
        materials = []
        
        if selection_data[:entities] && !selection_data[:entities].empty?
          # Agrupar por material
          material_map = {}
          
          selection_data[:entities].each do |entity|
            next unless entity[:material]
            
            material_name = entity[:material][:name]
            material_color = entity[:material][:color] || '#CCCCCC'
            
            if material_map[material_name]
              material_map[material_name][:volume] += entity[:volume] || 0
              material_map[material_name][:area] += entity[:area] || 0
              material_map[material_name][:count] += 1
            else
              material_map[material_name] = {
                name: material_name,
                color: material_color,
                volume: entity[:volume] || 0,
                area: entity[:area] || 0,
                count: 1
              }
            end
          end
          
          materials = material_map.values.sort_by { |m| -m[:volume] }
        end
        
        {
          materials: materials,
          selection_count: selection_data[:entities] ? selection_data[:entities].length : 0,
          total_volume: selection_data[:total_volume] || 0,
          total_area: selection_data[:total_area] || 0,
          timestamp: Time.now.to_i,
          lang: lang
        }
      end
      
      ##
      # Ejecución segura con manejo de errores
      #
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          begin
            yield
          rescue => e
            puts "Error en #{operation}: #{e.message}" if defined?(IQuant::DEBUG_MODE) && IQuant::DEBUG_MODE
          end
        end
      end
        end
      
      end
    end
