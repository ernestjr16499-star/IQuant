﻿# encoding: UTF-8
# features/analytics.rb
# Sistema de analytics opt-in para iQuant v4.1

module IQuant
  module Features
    module Analytics
      extend self
      
      # Constantes del sistema
      ANALYTICS_SERVER_URL = "https://api.iquant.app/analytics"
      ANALYTICS_VERSION = "1.0"
      ANALYTICS_SESSION_KEY = "iQuant_Analytics_Session"
      
      # Inicializar el sistema de analytics
      def init
        safe_execute('Inicializar analytics') do
          @session_id = generate_session_id
          @enabled = IQuant.analytics_enabled
          @queue = []
          @last_send = Time.now
          
          IQuant::Utils::Logger.log("Sistema de analytics inicializado (enabled: #{@enabled})", :debug)
          
          # Cargar eventos pendientes del disco
          load_pending_events
          
          # Iniciar hilo de procesamiento en background (si está habilitado)
          start_background_thread if @enabled
        end
      end
      
      # Activar analytics (opt-in)
      def opt_in
        safe_execute('Opt-in analytics') do
          @enabled = true
          IQuant.analytics_enabled = true
          
          # Guardar preferencia
          model = Sketchup.active_model
          model.set_attribute(IQuant::PREFS_KEY, "analytics_enabled", true)
          
          # Iniciar procesamiento en background
          start_background_thread
          
          # Registrar evento de activación
          track_event('analytics_opted_in')
          
          IQuant::Utils::Logger.log("Usuario opt-in para analytics", :info)
        end
      end
      
      # Desactivar analytics (opt-out)
      def opt_out
        safe_execute('Opt-out analytics') do
          @enabled = false
          IQuant.analytics_enabled = false
          
          # Guardar preferencia
          model = Sketchup.active_model
          model.set_attribute(IQuant::PREFS_KEY, "analytics_enabled", false)
          
          # Detener hilo de background
          stop_background_thread
          
          # Limpiar eventos pendientes
          clear_pending_events
          
          IQuant::Utils::Logger.log("Usuario opt-out para analytics", :info)
        end
      end
      
      # Registrar evento de analytics
      # @param event_name [String] Nombre del evento
      # @param properties [Hash] Propiedades adicionales del evento
      def track_event(event_name, properties = {})
        return unless @enabled
        
        safe_execute("Track event: #{event_name}") do
          event_data = build_event_data(event_name, properties)
          
          # Agregar a la cola
          @queue ||= []
          @queue << event_data
          
          # Guardar en disco para persistencia
          save_event_to_disk(event_data)
          
          IQuant::Utils::Logger.log("Evento registrado: #{event_name}", :debug)
          
          # Intentar enviar si la cola es grande o ha pasado mucho tiempo
          send_events_if_needed
        end
      end
      
      # Obtener estado actual de analytics
      # @return [Hash] Estado del sistema
      def get_analytics_status
        {
          enabled: @enabled || false,
          pending_events: @queue&.size || 0,
          session_id: @session_id,
          version: ANALYTICS_VERSION
        }
      end
      
      # Enviar eventos pendientes inmediatamente
      def flush_events
        return unless @enabled && @queue && !@queue.empty?
        
        safe_execute('Flush analytics events') do
          events_to_send = @queue.dup
          @queue.clear
          
          # Enviar en un hilo separado para no bloquear la UI
          Thread.new do
            send_events_to_server(events_to_send)
          end
        end
      end
      
      private
      
      # Generar ID de sesión único
      def generate_session_id
        model = Sketchup.active_model
        existing_id = model.get_attribute(IQuant::PREFS_KEY, "analytics_session_id")
        
        if existing_id && !existing_id.empty?
          existing_id
        else
          new_id = "iq-#{Time.now.to_i}-#{rand(36**8).to_s(36)}"
          model.set_attribute(IQuant::PREFS_KEY, "analytics_session_id", new_id)
          new_id
        end
      end
      
      # Construir datos del evento
      def build_event_data(event_name, properties)
        model = Sketchup.active_model
        plugin_info = {
          plugin_version: IQuant::PLUGIN_VERSION,
          sketchup_version: Sketchup.version,
          operating_system: RUBY_PLATFORM,
          locale: Sketchup.get_locale,
          language: IQuant.current_lang || 'en'
        }
        
        {
          event_name: event_name,
          properties: properties,
          timestamp: Time.now.utc.iso8601,
          session_id: @session_id,
          plugin_info: plugin_info,
          user_id: get_anonymous_user_id(model),
          # Información anónima del proyecto
          project_stats: {
            entity_count: model.entities.count,
            layer_count: model.layers.count,
            material_count: model.materials.count
          }
        }
      end
      
      # Obtener ID de usuario anónimo
      def get_anonymous_user_id(model)
        user_id = model.get_attribute(IQuant::PREFS_KEY, "anonymous_user_id")
        
        unless user_id
          # Generar ID anónimo (no contiene información personal)
          user_id = "anon-#{Digest::MD5.hexdigest("#{model.guid}-#{Sketchup.version}")[0..16]}"
          model.set_attribute(IQuant::PREFS_KEY, "anonymous_user_id", user_id)
        end
        
        user_id
      end
      
      # Guardar evento en disco para persistencia
      def save_event_to_disk(event_data)
        return unless IQuant::LOG_TO_FILE
        
        events_file = get_events_file_path
        
        begin
          # Leer eventos existentes
          existing_events = []
          if File.exist?(events_file)
            file_content = File.read(events_file)
            existing_events = JSON.parse(file_content) rescue []
          end
          
          # Agregar nuevo evento
          existing_events << event_data
          
          # Mantener solo los últimos 100 eventos
          existing_events = existing_events.last(100)
          
          # Guardar
          File.open(events_file, 'w') do |f|
            f.write(JSON.generate(existing_events))
          end
        rescue => e
          IQuant::Utils::Logger.log("Error guardando evento en disco: #{e.message}", :warn)
        end
      end
      
      # Cargar eventos pendientes del disco
      def load_pending_events
        return unless IQuant::LOG_TO_FILE
        
        events_file = get_events_file_path
        
        begin
          if File.exist?(events_file)
            file_content = File.read(events_file)
            @queue = JSON.parse(file_content, symbolize_names: true) rescue []
            IQuant::Utils::Logger.log("Eventos pendientes cargados: #{@queue.size}", :debug)
          end
        rescue => e
          IQuant::Utils::Logger.log("Error cargando eventos del disco: #{e.message}", :warn)
          @queue = []
        end
      end
      
      # Limpiar eventos pendientes
      def clear_pending_events
        events_file = get_events_file_path
        
        begin
          File.delete(events_file) if File.exist?(events_file)
          @queue = []
        rescue => e
          IQuant::Utils::Logger.log("Error limpiando eventos: #{e.message}", :warn)
        end
      end
      
      # Obtener ruta del archivo de eventos
      def get_events_file_path
        plugin_dir = IQuant::PLUGIN_DIR || File.expand_path('..', __dir__)
        File.join(plugin_dir, 'analytics_events.json')
      end
      
      # Determinar si es necesario enviar eventos
      def send_events_if_needed
        return unless @queue && !@queue.empty?
        
        # Enviar si hay más de 10 eventos o han pasado más de 5 minutos
        if @queue.size >= 10 || (Time.now - @last_send) > 300
          flush_events
          @last_send = Time.now
        end
      end
      
      # Enviar eventos al servidor
      def send_events_to_server(events)
        return if events.empty?
        
        begin
          # Construir payload
          payload = {
            events: events,
            batch_id: "batch-#{Time.now.to_i}-#{rand(1000)}"
          }
          
          # Enviar HTTP POST con manejo de errores de red
          uri = URI.parse(ANALYTICS_SERVER_URL)
          http = Net::HTTP.new(uri.host, uri.port)
          http.use_ssl = (uri.scheme == 'https')
          http.read_timeout = 3  # Timeout más corto para evitar bloqueos
          http.open_timeout = 3
          
          request = Net::HTTP::Post.new(uri.path)
          request['Content-Type'] = 'application/json'
          request['User-Agent'] = "iQuant/#{IQuant::PLUGIN_VERSION}"
          request.body = JSON.generate(payload)
          
          response = http.request(request)
          
          if response.is_a?(Net::HTTPSuccess)
            IQuant::Utils::Logger.log("Eventos enviados exitosamente: #{events.size} eventos", :debug)
          else
            IQuant::Utils::Logger.log("Error enviando eventos: #{response.code} #{response.message}", :warn)
            # Re-agregar eventos a la cola para reintentar más tarde
            @queue = events + (@queue || [])
          end
        rescue Errno::ETIMEDOUT, Errno::ECONNREFUSED, SocketError, Timeout::Error => e
          # Error de red: no mostrar error al usuario, solo log
          IQuant::Utils::Logger.log("Analytics: no se pudo enviar (#{e.class})", :debug)
          # Re-agregar eventos a la cola para reintentar más tarde
          @queue = events + (@queue || [])
        rescue => e
          IQuant::Utils::Logger.log("Excepción enviando eventos: #{e.message}", :warn)
          # Re-agregar eventos a la cola
          @queue = events + (@queue || [])
        end
      end
      
      # Iniciar hilo de background para procesamiento
      def start_background_thread
        return if @background_thread && @background_thread.alive?
        
        @background_thread = Thread.new do
          loop do
            sleep 60 # Revisar cada minuto
            
            # Enviar eventos si es necesario
            send_events_if_needed
            
            # Limpiar eventos muy antiguos (más de 7 días)
            cleanup_old_events
            
            break unless @enabled
          end
        end
        
        @background_thread.abort_on_exception = false
      end
      
      # Detener hilo de background
      def stop_background_thread
        if @background_thread && @background_thread.alive?
          @background_thread.kill
          @background_thread = nil
        end
      end
      
      # Limpiar eventos antiguos
      def cleanup_old_events
        return unless @queue
        
        one_week_ago = Time.now - (7 * 24 * 60 * 60)
        
        @queue.reject! do |event|
          event_time = Time.parse(event[:timestamp]) rescue nil
          event_time && event_time < one_week_ago
        end
      end
      
      # Ejecución segura con manejo de errores
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          begin
            yield
          rescue => e
            IQuant::Utils::Logger.log("Error en #{operation}: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
          end
        end
      end
      
    end
  end
end
