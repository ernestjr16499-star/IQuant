﻿# encoding: UTF-8

module IQuant
  module Features
    module Licensing
      extend self
      
      # ==========================================================================
      # CONSTANTES
      # ==========================================================================
      
      # Keys para almacenar en atributos del modelo
      LICENSE_KEY_ATTR = 'iQuant_license_key'
      LICENSE_STATUS_ATTR = 'iQuant_license_status'
      TRIAL_START_ATTR = 'iQuant_trial_start_date'
      EXPORT_COUNT_ATTR = 'iQuant_export_count'
      LAST_EXPORT_DATE_ATTR = 'iQuant_last_export_date'
      
      # Estados de licencia
      STATUS_TRIAL = :trial
      STATUS_LICENSED = :licensed
      STATUS_EXPIRED = :expired
      
      # ==========================================================================
      # MÉTODOS PÚBLICOS
      # ==========================================================================
      
      ##
      # Inicializa el sistema de licencias
      #
      def init
        safe_execute('Inicializar sistema de licencias') do
          model = Sketchup.active_model
          
          # Inicializar atributos si no existen
          unless model.get_attribute(LICENSE_STATUS_ATTR, 'status')
            model.set_attribute(LICENSE_STATUS_ATTR, 'status', STATUS_TRIAL.to_s)
            model.set_attribute(TRIAL_START_ATTR, 'date', Time.now.to_i)
            model.set_attribute(EXPORT_COUNT_ATTR, 'count', 0)
            IQuant::Utils::Logger.log("Sistema de licencias inicializado en modo trial", :info)
          end
          
          # Verificar si la licencia ha expirado
          check_and_update_status
        end
      end
      
      ##
      # Verifica el estado actual de la licencia
      #
      # @return [Hash] Información del estado de la licencia
      #
      def check_license_status
        model = Sketchup.active_model
        
        # Obtener estado actual
        status = model.get_attribute(LICENSE_STATUS_ATTR, 'status')&.to_sym || STATUS_TRIAL
        trial_start = model.get_attribute(TRIAL_START_ATTR, 'date') || Time.now.to_i
        export_count = model.get_attribute(EXPORT_COUNT_ATTR, 'count') || 0
        license_key = model.get_attribute(LICENSE_KEY_ATTR, 'key')
        
        case status
        when STATUS_LICENSED
          {
            status: STATUS_LICENSED,
            key: license_key ? mask_license_key(license_key) : nil,
            message: 'Licencia activa',
            days_left: nil,
            exports_left: nil
          }
        when STATUS_TRIAL
          days_left = calculate_trial_days_left(trial_start)
          exports_left = [IQuant::TRIAL_EXPORTS - export_count, 0].max
          
          {
            status: STATUS_TRIAL,
            key: nil,
            message: "Versión de prueba",
            days_left: days_left,
            exports_left: exports_left,
            trial_start: Time.at(trial_start).strftime('%Y-%m-%d')
          }
        when STATUS_EXPIRED
          {
            status: STATUS_EXPIRED,
            key: nil,
            message: "Licencia expirada",
            days_left: 0,
            exports_left: 0
          }
        else
          {
            status: STATUS_TRIAL,
            key: nil,
            message: "Modo de prueba",
            days_left: IQuant::TRIAL_DAYS,
            exports_left: IQuant::TRIAL_EXPORTS
          }
        end
      end
      
      ##
      # Activa una licencia con la clave proporcionada
      #
      # @param key [String] Clave de licencia
      # @return [Boolean] true si la activación fue exitosa
      #
      def activate_key(key)
        safe_execute('Activar licencia') do
          # Validar formato básico de la clave
          unless valid_license_key_format?(key)
            IQuant::Utils::Logger.log("Formato de clave inválido: #{key[0..8]}...", :warn)
            return false
          end
          
          # Aquí iría la validación real con servidor de licencias
          # Por ahora, simulamos una clave válida
          is_valid = validate_license_key(key)
          
          if is_valid
            model = Sketchup.active_model
            model.set_attribute(LICENSE_KEY_ATTR, 'key', key)
            model.set_attribute(LICENSE_STATUS_ATTR, 'status', STATUS_LICENSED.to_s)
            model.set_attribute(EXPORT_COUNT_ATTR, 'count', 0) # Resetear contador de exportaciones
            
            IQuant::Utils::Logger.log("Licencia activada exitosamente: #{mask_license_key(key)}", :success)
            
            # Track analytics
            if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
              IQuant::Features::Analytics.track_event('license_activated', { 
                key_length: key.length,
                masked_key: mask_license_key(key)
              })
            end
            
            true
          else
            IQuant::Utils::Logger.log("Clave de licencia inválida: #{mask_license_key(key)}", :warn)
            false
          end
        end
      end
      
      ##
      # Registra una exportación
      #
      # @return [Boolean] true si se pudo registrar (licencia válida o trial con exportaciones restantes)
      #
      def record_export
        safe_execute('Registrar exportación') do
          status = check_license_status
          
          case status[:status]
          when STATUS_LICENSED
            # Licencia activa, no hay límite
            return true
            
          when STATUS_TRIAL
            model = Sketchup.active_model
            export_count = model.get_attribute(EXPORT_COUNT_ATTR, 'count') || 0
            
            # Verificar límite de exportaciones
            if export_count >= IQuant::TRIAL_EXPORTS
              IQuant::Utils::Logger.log("Límite de exportaciones de prueba alcanzado", :warn)
              return false
            end
            
            # Incrementar contador
            model.set_attribute(EXPORT_COUNT_ATTR, 'count', export_count + 1)
            model.set_attribute(LAST_EXPORT_DATE_ATTR, 'date', Time.now.to_i)
            
            IQuant::Utils::Logger.log("Exportación registrada (#{export_count + 1}/#{IQuant::TRIAL_EXPORTS})", :info)
            return true
            
          when STATUS_EXPIRED
            IQuant::Utils::Logger.log("No se puede exportar: licencia expirada", :warn)
            return false
          end
          
          false
        end
      end
      
      ##
      # Verifica si se puede exportar
      #
      # @return [Boolean] true si se puede exportar
      #
      def can_export?
        status = check_license_status
        
        case status[:status]
        when STATUS_LICENSED
          true
        when STATUS_TRIAL
          (status[:exports_left] || IQuant::TRIAL_EXPORTS) > 0
        else
          false
        end
      end
      
      ##
      # Determina si se debe agregar watermark
      #
      # @return [Boolean] true si se debe agregar watermark
      #
      def should_add_watermark?
        status = check_license_status
        status[:status] != STATUS_LICENSED
      end
      
      ##
      # Obtiene información completa de la licencia
      #
      # @return [Hash] Información detallada de la licencia
      #
      def get_license_info
        status = check_license_status
        model = Sketchup.active_model
        
        info = {
          status: status[:status],
          message: status[:message],
          can_export: can_export?,
          should_watermark: should_add_watermark?,
          trial_days: IQuant::TRIAL_DAYS,
          trial_exports: IQuant::TRIAL_EXPORTS
        }
        
        # Agregar información específica según el estado
        case status[:status]
        when STATUS_TRIAL
          info.merge!(
            days_left: status[:days_left],
            exports_left: status[:exports_left],
            trial_start: status[:trial_start],
            export_count: model.get_attribute(EXPORT_COUNT_ATTR, 'count') || 0
          )
        when STATUS_LICENSED
          license_key = model.get_attribute(LICENSE_KEY_ATTR, 'key')
          info.merge!(
            key: mask_license_key(license_key),
            export_count: model.get_attribute(EXPORT_COUNT_ATTR, 'count') || 0
          )
        end
        
        info
      end
      
      # ==========================================================================
      # MÉTODOS PRIVADOS
      # ==========================================================================
      
      private
      
      ##
      # Verifica y actualiza el estado de la licencia (ej. trial expirado)
      #
      def check_and_update_status
        model = Sketchup.active_model
        current_status = model.get_attribute(LICENSE_STATUS_ATTR, 'status')&.to_sym
        
        return unless current_status == STATUS_TRIAL
        
        trial_start = model.get_attribute(TRIAL_START_ATTR, 'date') || Time.now.to_i
        days_left = calculate_trial_days_left(trial_start)
        
        if days_left <= 0
          model.set_attribute(LICENSE_STATUS_ATTR, 'status', STATUS_EXPIRED.to_s)
          IQuant::Utils::Logger.log("Período de prueba ha expirado", :warn)
        end
      end
      
      ##
      # Calcula los días restantes de prueba
      #
      # @param trial_start [Integer] Timestamp de inicio del trial
      # @return [Integer] Días restantes
      #
      def calculate_trial_days_left(trial_start)
        days_passed = (Time.now.to_i - trial_start) / (60 * 60 * 24)
        [IQuant::TRIAL_DAYS - days_passed, 0].max
      end
      
      ##
      # Valida el formato de la clave de licencia
      #
      # @param key [String] Clave a validar
      # @return [Boolean] true si el formato es válido
      #
      def valid_license_key_format?(key)
        return false unless key.is_a?(String)
        
        # Formato: XXXX-XXXX-XXXX-XXXX (16 caracteres alfanuméricos separados por guiones)
        key.match?(/^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/)
      end
      
      ##
      # Valida la clave de licencia (simulación - en producción se conectaría a un servidor)
      #
      # @param key [String] Clave a validar
      # @return [Boolean] true si la clave es válida
      #
      def validate_license_key(key)
        # En un sistema real, esto haría una petición a un servidor de licencias
        # o validaría localmente con un algoritmo criptográfico
        
        # Por ahora, simulamos algunas claves de prueba
        test_keys = [
          'TEST-1234-ABCD-5678',  # Clave de prueba 1
          'DEMO-9876-EFGH-4321',  # Clave de prueba 2
          'PROD-2468-WXYZ-1357'   # Clave de prueba 3
        ]
        
        # También aceptamos cualquier clave que empiece con "VALID-" para desarrollo
        test_keys.include?(key) || key.start_with?('VALID-')
      end
      
      ##
      # Enmascara una clave de licencia para mostrar solo los últimos caracteres
      #
      # @param key [String] Clave completa
      # @return [String] Clave enmascarada
      #
      def mask_license_key(key)
        return nil unless key && key.is_a?(String)
        "****-****-****-#{key[-4..-1]}" if key.length >= 4
      end
      
      ##
      # Ejecución segura con manejo de errores
      #
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          begin
            yield
          rescue => e
            IQuant::Utils::Logger.log("Error en #{operation}: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
          end
        end
      end
      
    end
  end
end
