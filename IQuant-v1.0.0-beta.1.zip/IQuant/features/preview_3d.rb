﻿# features/preview_3d.rb
# Sistema de vista previa 3D para iQuant v4.1 (CORREGIDO)

# encoding: UTF-8

module IQuant
  module Features
    module Preview3D
      extend self
      
      # ==========================================================================
      # CONFIGURACIÓN DEL VIEWER 3D
      # ==========================================================================
      
      # Versión de Three.js (ya incluida en html_generator.rb)
      THREE_JS_VERSION = '0.150.0'
      
      # ID del contenedor en HTML (asumir que html_generator.rb lo incluye)
      VIEWER_CONTAINER_ID = 'preview-3d-container'
      
      # Colores predeterminados (inspirado en tema de Grok/X)
      COLORS = {
        background: 0x1e1e1e,  # Fondo oscuro
        grid: 0x444444,        # Rejilla
        axis_x: 0xff0000,      # Eje X rojo
        axis_y: 0x00ff00,      # Eje Y verde
        axis_z: 0x0000ff,      # Eje Z azul
        mesh: 0xffffff,        # Malla blanca
        wireframe: 0x888888    # Wireframe gris
      }
      
      # Opciones de renderizado
      OPTIONS = {
        antialias: true,
        alpha: true,
        auto_rotate: false,
        zoom_speed: 1.0,
        pan_speed: 0.5,
        rotate_speed: 1.0,
        show_grid: true,
        show_axes: true,
        show_wireframe: true
      }
      
      # ==========================================================================
      # INICIALIZACIÓN DEL VIEWER
      # ==========================================================================
      
      ##
      # Inicializa el viewer 3D en el diálogo
      #
      # @param dialog [UI::HtmlDialog] El diálogo principal
      #
      def init_viewer(dialog)
        safe_execute('Inicializar Preview 3D') do
          return unless enabled?
          
          IQuant::Utils::Logger.log("Inicializando Preview 3D con Three.js v#{THREE_JS_VERSION}", :info) if defined?(IQuant::Utils::Logger)
          
          # Inyectar contenedor si no existe
          if dialog && dialog.visible?
            dialog.execute_script("if (!document.getElementById('#{VIEWER_CONTAINER_ID}')) { 
              const container = document.createElement('div');
              container.id = '#{VIEWER_CONTAINER_ID}';
              container.style.width = '100%';
              container.style.height = '400px';
              container.style.border = '1px solid #ddd';
              container.style.borderRadius = '4px';
              container.style.overflow = 'hidden';
              // Buscar sección de preview o crear una
              const previewSection = document.getElementById('preview-section') || document.getElementById('preview-3d-section');
              if (previewSection) {
                previewSection.appendChild(container);
              } else {
                // Crear sección si no existe
                const section = document.createElement('div');
                section.id = 'preview-3d-section';
                section.style.marginTop = '20px';
                section.innerHTML = '<h3>3D Preview</h3>';
                section.appendChild(container);
                document.querySelector('.main-content').appendChild(section);
              }
            }")
            
            # Inyectar scripts de Three.js si no están ya cargados
            dialog.execute_script("if (typeof THREE === 'undefined') {
              console.log('Cargando Three.js...');
              const script = document.createElement('script');
              script.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/#{THREE_JS_VERSION}/three.min.js';
              script.onload = function() {
                console.log('Three.js cargado');
                // Cargar OrbitControls
                const controlsScript = document.createElement('script');
                controlsScript.src = 'https://cdn.jsdelivr.net/npm/three@#{THREE_JS_VERSION}/examples/js/controls/OrbitControls.js';
                controlsScript.onload = init3DViewer;
                document.head.appendChild(controlsScript);
              };
              document.head.appendChild(script);
            } else {
              init3DViewer();
            }")
            
            # Configurar eventos (resize, etc.)
            dialog.execute_script(get_event_listeners_script)
            
            # Inyectar funciones helper
            dialog.execute_script(get_clear_scene_script)
            dialog.execute_script(get_load_geometry_script)
            dialog.execute_script(get_fit_camera_script)
          end
          
          # Track inicialización
          if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
            IQuant::Features::Analytics.track_event('preview_3d_initialized')
          end
          
          IQuant::Utils::Logger.log("Preview 3D inicializado", :success) if defined?(IQuant::Utils::Logger)
        end
      end
      
      # ==========================================================================
      # ACTUALIZACIÓN DEL VIEWER
      # ==========================================================================
      
      ##
      # Actualiza el viewer con la entidad seleccionada
      #
      # @param dialog [UI::HtmlDialog] El diálogo
      # @param entity [Sketchup::Entity] La entidad a renderizar
      #
      def update_viewer(dialog, entity)
        safe_execute('Actualizar Preview 3D') do
          return unless enabled? && entity && valid_entity?(entity)
          
          IQuant::Utils::Logger.log("Actualizando Preview 3D para entidad #{entity.entityID}", :info) if defined?(IQuant::Utils::Logger)
          
          # Exportar geometría a formato JSON compatible con Three.js
          geometry_data = export_geometry(entity)
          
          if geometry_data.nil? || geometry_data.empty?
            show_error_message(dialog, "Geometría inválida o vacía")
            return
          end
          
          # Convertir a JSON seguro para JavaScript
          json_data = geometry_data.to_json.gsub("'", "\\\\'").gsub("\n", "\\n")
          
          # Limpiar escena anterior y cargar nueva
          if dialog && dialog.visible?
            dialog.execute_script("if (typeof clear3DScene === 'function') clear3DScene();")
            dialog.execute_script("if (typeof load3DGeometry === 'function') load3DGeometry(#{json_data});")
            
            # Ajustar cámara automáticamente
            dialog.execute_script("if (typeof fitCameraToObject === 'function') setTimeout(fitCameraToObject, 100);")
          end
          
          # Track actualización
          if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
            IQuant::Features::Analytics.track_event('preview_3d_updated', { 
              entity_type: entity.class.name,
              vertex_count: geometry_data[:vertices] ? geometry_data[:vertices].size : 0
            })
          end
          
          IQuant::Utils::Logger.log("Preview 3D actualizado exitosamente", :success) if defined?(IQuant::Utils::Logger)
        end
      end
      
      ##
      # Limpia el viewer 3D
      #
      def clear_viewer(dialog)
        if dialog && dialog.visible?
          dialog.execute_script("if (typeof clear3DScene === 'function') clear3DScene();")
        end
      end
      
      # ==========================================================================
      # EXPORTACIÓN DE GEOMETRÍA
      # ==========================================================================
      
      ##
      # Exporta la geometría de la entidad a formato JSON para Three.js
      # Formato: { vertices: [[x,y,z], ...], faces: [[i1,i2,i3], ...], normals: [[nx,ny,nz], ...] }
      #
      # @param entity [Sketchup::Entity] Entidad a exportar
      # @return [Hash, nil] Datos de geometría o nil si error
      #
      def export_geometry(entity)
        return nil unless entity.respond_to?(:definition)
        
        begin
          definition = entity.definition
          trans = entity.transformation
          
          vertices = []
          faces = []
          normals = []
          
          # Recorrer caras recursivamente
          process_entities(definition.entities, trans, vertices, faces, normals)
          
          if vertices.empty?
            IQuant::Utils::Logger.log("No se encontraron vértices en la entidad", :warn) if defined?(IQuant::Utils::Logger)
            return nil
          end
          
          # Normalizar unidades (convertir de pulgadas internas a metros para Three.js)
          unit_factor = IQuant::UNIT_FACTORS['m'] if defined?(IQuant::UNIT_FACTORS) && IQuant::UNIT_FACTORS['m']  # Asumir metros para 3D
          unit_factor ||= 0.0254  # Fallback: pulgadas a metros
          vertices.map! { |v| v.map! { |coord| coord * unit_factor } }
          
          {
            vertices: vertices,
            faces: faces,
            normals: normals,
            bounds: calculate_bounds(vertices),
            center: calculate_center(vertices),
            entity_id: entity.entityID,
            entity_type: entity.class.name
          }
        rescue => e
          IQuant::Utils::Logger.log("Error exportando geometría: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
          IQuant::Utils::Logger.log("Backtrace: #{e.backtrace.first(5).join(', ')}", :debug) if defined?(IQuant::DEBUG_MODE) && IQuant::DEBUG_MODE && defined?(IQuant::Utils::Logger)
          nil
        end
      end
      
      private
      
      ##
      # Procesa entidades recursivamente (para grupos anidados)
      #
      def process_entities(entities, trans, vertices, faces, normals)
        entities.each do |e|
          if e.is_a?(Sketchup::Face)
            process_face(e, trans, vertices, faces, normals)
          elsif e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
            # Transformación compuesta
            sub_trans = trans * e.transformation
            process_entities(e.definition.entities, sub_trans, vertices, faces, normals)
          end
        end
      end
      
      ##
      # Procesa una cara individual
      #
      def process_face(face, trans, vertices, faces, normals)
        begin
          # Obtener malla triangulada (nivel 7 = triangulada con UVs y normales)
          mesh = face.mesh(7)
          
          # Vértices globales
          vertex_offset = vertices.size
          mesh.points.each do |pt|
            global_pt = pt.transform(trans)
            vertices << [global_pt.x, global_pt.y, global_pt.z]
          end
          
          # Índices de caras (ajustados por offset actual de vértices)
          mesh.polygons.each do |poly|
            # Asumir triángulos (debido a mesh(7))
            # Los índices en mesh son 1-based, convertimos a 0-based
            faces << [
              poly[0].abs - 1 + vertex_offset,
              poly[1].abs - 1 + vertex_offset, 
              poly[2].abs - 1 + vertex_offset
            ]
          end
          
          # Normales (por vértice)
          mesh.normals.each do |n|
            global_n = n.transform(trans)
            normals << [global_n.x, global_n.y, global_n.z]
          end
        rescue => e
          IQuant::Utils::Logger.log("Error procesando cara: #{e.message}", :warn) if defined?(IQuant::Utils::Logger)
        end
      end
      
      ##
      # Calcula bounds para fitCamera
      #
      def calculate_bounds(vertices)
        return { min: [0,0,0], max: [0,0,0] } if vertices.empty?
        
        min_x = max_x = vertices[0][0]
        min_y = max_y = vertices[0][1]
        min_z = max_z = vertices[0][2]
        
        vertices.each do |v|
          min_x = [min_x, v[0]].min
          max_x = [max_x, v[0]].max
          min_y = [min_y, v[1]].min
          max_y = [max_y, v[1]].max
          min_z = [min_z, v[2]].min
          max_z = [max_z, v[2]].max
        end
        
        {
          min: [min_x, min_y, min_z],
          max: [max_x, max_y, max_z]
        }
      end
      
      ##
      # Calcula centro del modelo
      #
      def calculate_center(vertices)
        return [0,0,0] if vertices.empty?
        
        sum_x = sum_y = sum_z = 0.0
        vertices.each do |v|
          sum_x += v[0]
          sum_y += v[1]
          sum_z += v[2]
        end
        
        count = vertices.size.to_f
        [sum_x/count, sum_y/count, sum_z/count]
      end
      
      # ==========================================================================
      # SCRIPTS JAVASCRIPT PARA INYECCIÓN
      # ==========================================================================
      
      ##
      # Script de inicialización de Three.js (ahora en HTML)
      #
      def get_three_js_init_script
        <<-JS
        function init3DViewer() {
          const container = document.getElementById('#{VIEWER_CONTAINER_ID}');
          if (!container) {
            console.error('Contenedor 3D no encontrado');
            return;
          }
          
          console.log('Inicializando viewer 3D...');
          
          // Escena
          window.scene3D = new THREE.Scene();
          window.scene3D.background = new THREE.Color(#{COLORS[:background]});
          
          // Cámara
          window.camera3D = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 10000);
          window.camera3D.position.set(0, 0, 100);
          
          // Renderer
          window.renderer3D = new THREE.WebGLRenderer({ 
            antialias: #{OPTIONS[:antialias]}, 
            alpha: #{OPTIONS[:alpha]},
            preserveDrawingBuffer: true // Para posibles screenshots
          });
          window.renderer3D.setSize(container.clientWidth, container.clientHeight);
          window.renderer3D.setPixelRatio(window.devicePixelRatio);
          container.innerHTML = ''; // Limpiar
          container.appendChild(window.renderer3D.domElement);
          
          // Controles Orbit
          window.controls3D = new THREE.OrbitControls(window.camera3D, window.renderer3D.domElement);
          window.controls3D.enableZoom = true;
          window.controls3D.zoomSpeed = #{OPTIONS[:zoom_speed]};
          window.controls3D.enablePan = true;
          window.controls3D.panSpeed = #{OPTIONS[:pan_speed]};
          window.controls3D.enableRotate = true;
          window.controls3D.rotateSpeed = #{OPTIONS[:rotate_speed]};
          window.controls3D.autoRotate = #{OPTIONS[:auto_rotate]};
          
          // Rejilla
          if (#{OPTIONS[:show_grid]}) {
            const gridHelper = new THREE.GridHelper(100, 10, #{COLORS[:grid]}, #{COLORS[:grid]});
            window.scene3D.add(gridHelper);
          }
          
          // Ejes
          if (#{OPTIONS[:show_axes]}) {
            const axesHelper = new THREE.AxesHelper(50);
            // Configurar colores individuales
            axesHelper.setColors(
              new THREE.Color(#{COLORS[:axis_x]}),
              new THREE.Color(#{COLORS[:axis_y]}), 
              new THREE.Color(#{COLORS[:axis_z]})
            );
            window.scene3D.add(axesHelper);
          }
          
          // Luces
          const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
          window.scene3D.add(ambientLight);
          
          const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
          directionalLight.position.set(1, 1, 1);
          window.scene3D.add(directionalLight);
          
          // Animación
          function animate3D() {
            requestAnimationFrame(animate3D);
            if (window.controls3D) window.controls3D.update();
            if (window.renderer3D && window.scene3D && window.camera3D) {
              window.renderer3D.render(window.scene3D, window.camera3D);
            }
          }
          animate3D();
          
          console.log('Viewer 3D inicializado');
        }
        JS
      end
      
      ##
      # Script para listeners (resize, etc.)
      #
      def get_event_listeners_script
        <<-JS
        // Listener para resize
        const resizeObserver = new ResizeObserver(() => {
          const container = document.getElementById('#{VIEWER_CONTAINER_ID}');
          if (container && window.camera3D && window.renderer3D) {
            window.camera3D.aspect = container.clientWidth / container.clientHeight;
            window.camera3D.updateProjectionMatrix();
            window.renderer3D.setSize(container.clientWidth, container.clientHeight);
          }
        });
        
        const container = document.getElementById('#{VIEWER_CONTAINER_ID}');
        if (container) {
          resizeObserver.observe(container);
        }
        
        // Limpiar observer cuando se cierre
        window.addEventListener('unload', () => {
          resizeObserver.disconnect();
        });
        JS
      end
      
      ##
      # Script para limpiar escena
      #
      def get_clear_scene_script
        <<-JS
        function clear3DScene() {
          if (!window.scene3D) return;
          
          // Remover objetos de malla (mantener helpers y luces)
          const objectsToRemove = [];
          window.scene3D.children.forEach(child => {
            if (child.type === 'Mesh' || child.type === 'LineSegments') {
              objectsToRemove.push(child);
            }
          });
          
          objectsToRemove.forEach(obj => {
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) {
              if (Array.isArray(obj.material)) {
                obj.material.forEach(m => m.dispose());
              } else {
                obj.material.dispose();
              }
            }
            window.scene3D.remove(obj);
          });
          
          console.log('Escena 3D limpiada');
        }
        JS
      end
      
      ##
      # Script para cargar geometría
      #
      def get_load_geometry_script
        <<-JS
        function load3DGeometry(data) {
          if (!window.scene3D) {
            console.error('Scene 3D no inicializada');
            return;
          }
          
          try {
            // Validar datos
            if (!data.vertices || !Array.isArray(data.vertices) || data.vertices.length === 0) {
              console.error('Datos de geometría inválidos: sin vértices');
              return;
            }
            
            console.log(`Cargando geometría: \${data.vertices.length} vértices, \${data.faces ? data.faces.length : 0} caras`);
            
            // Crear geometría
            const geometry = new THREE.BufferGeometry();
            
            // Vértices
            const verticesFlat = [];
            data.vertices.forEach(v => {
              verticesFlat.push(v[0] || 0, v[1] || 0, v[2] || 0);
            });
            geometry.setAttribute('position', new THREE.Float32BufferAttribute(verticesFlat, 3));
            
            // Normales
            if (data.normals && Array.isArray(data.normals) && data.normals.length === data.vertices.length) {
              const normalsFlat = [];
              data.normals.forEach(n => {
                normalsFlat.push(n[0] || 0, n[1] || 0, n[2] || 0);
              });
              geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normalsFlat, 3));
            } else {
              geometry.computeVertexNormals();
            }
            
            // Índices (caras)
            if (data.faces && Array.isArray(data.faces) && data.faces.length > 0) {
              const indices = [];
              data.faces.forEach(f => {
                if (Array.isArray(f) && f.length >= 3) {
                  indices.push(f[0] || 0, f[1] || 0, f[2] || 0);
                }
              });
              geometry.setIndex(indices);
            }
            
            // Material
            const material = new THREE.MeshPhongMaterial({
              color: #{COLORS[:mesh]},
              side: THREE.DoubleSide,
              flatShading: false,
              shininess: 30,
              specular: 0x222222
            });
            
            // Malla
            window.currentMesh3D = new THREE.Mesh(geometry, material);
            window.scene3D.add(window.currentMesh3D);
            
            // Wireframe
            if (#{OPTIONS[:show_wireframe]}) {
              const wireframeMaterial = new THREE.LineBasicMaterial({ 
                color: #{COLORS[:wireframe]},
                linewidth: 1
              });
              const wireframeGeo = new THREE.WireframeGeometry(geometry);
              window.currentWireframe3D = new THREE.LineSegments(wireframeGeo, wireframeMaterial);
              window.scene3D.add(window.currentWireframe3D);
            }
            
            console.log('Geometría 3D cargada exitosamente');
            
          } catch (error) {
            console.error('Error cargando geometría 3D:', error);
          }
        }
        JS
      end
      
      ##
      # Script para fit camera
      #
      def get_fit_camera_script
        <<-JS
        function fitCameraToObject() {
          if (!window.currentMesh3D || !window.camera3D || !window.controls3D) {
            return;
          }
          
          try {
            const boundingBox = new THREE.Box3().setFromObject(window.currentMesh3D);
            const center = boundingBox.getCenter(new THREE.Vector3());
            const size = boundingBox.getSize(new THREE.Vector3());
            
            const maxDim = Math.max(size.x, size.y, size.z);
            const fov = window.camera3D.fov * (Math.PI / 180);
            let cameraZ = Math.abs(maxDim / 2 / Math.tan(fov / 2));
            
            // Margen adicional
            cameraZ *= 1.5;
            
            window.camera3D.position.z = center.z + cameraZ;
            window.camera3D.position.x = center.x;
            window.camera3D.position.y = center.y;
            
            window.camera3D.lookAt(center);
            window.controls3D.target = center;
            window.controls3D.update();
            
            console.log('Cámara ajustada al objeto');
          } catch (error) {
            console.error('Error ajustando cámara:', error);
          }
        }
        JS
      end
      
      # ==========================================================================
      # UTILIDADES
      # ==========================================================================
      
      ##
      # Verifica si el viewer está habilitado
      #
      def enabled?
        # Verificar licencia
        if defined?(IQuant::Features::Licensing)
          license_status = IQuant::Features::Licensing.check_license_status
          return license_status[:status] == :licensed || license_status[:status] == :trial
        end
        true # Por defecto habilitado si no hay sistema de licencias
      end
      
      ##
      # Valida entidad para preview
      #
      def valid_entity?(entity)
        return false unless entity
        entity.is_a?(Sketchup::Group) || 
        entity.is_a?(Sketchup::ComponentInstance) ||
        entity.is_a?(Sketchup::Face) ||
        entity.is_a?(Sketchup::Edge)
      end
      
      ##
      # Muestra mensaje de error en el viewer
      #
      def show_error_message(dialog, message)
        if dialog && dialog.visible?
          dialog.execute_script("
            const container = document.getElementById('#{VIEWER_CONTAINER_ID}');
            if (container) {
              container.innerHTML = '<div style=\"padding: 20px; text-align: center; color: #f00;\">' +
                                   '<strong>Error:</strong> ' + #{message.inspect} + '</div>';
            }
          ")
        end
      end
      
      ##
      # Captura screenshot del viewer 3D
      #
      def capture_screenshot(dialog, width = 800, height = 600)
        safe_execute('Capturar screenshot 3D') do
          if dialog && dialog.visible?
            dialog.execute_script("
              if (window.renderer3D && window.scene3D && window.camera3D) {
                // Renderizar en tamaño específico
                const originalSize = {
                  width: window.renderer3D.domElement.width,
                  height: window.renderer3D.domElement.height
                };
                
                window.renderer3D.setSize(#{width}, #{height});
                window.renderer3D.render(window.scene3D, window.camera3D);
                
                // Obtener data URL
                const dataURL = window.renderer3D.domElement.toDataURL('image/png');
                
                // Restaurar tamaño original
                window.renderer3D.setSize(originalSize.width, originalSize.height);
                
                // Retornar data URL
                dataURL;
              } else {
                null;
              }
            ")
          end
        end
      end
      
      # Ejecución segura
      def safe_execute(operation, &block)
        IQuant::Utils::ErrorHandler.safe_execute(operation, &block) if defined?(IQuant::Utils::ErrorHandler)
      end
      
    end
  end
end

# Inicialización automática cuando se carga el diálogo
if defined?(IQuant::UI::DialogManager)
  IQuant::UI::DialogManager.class_eval do
    # Sobrescribir o extender el método show_dialog para inicializar 3D
    alias_method :original_show_dialog, :show_dialog unless method_defined?(:original_show_dialog)
    
    def show_dialog
      result = original_show_dialog
      
      # Inicializar preview 3D después de mostrar el diálogo
      if @dialog && defined?(IQuant::Features::Preview3D)
        IQuant::Features::Preview3D.init_viewer(@dialog)
      end
      
      result
    end
  end
end
