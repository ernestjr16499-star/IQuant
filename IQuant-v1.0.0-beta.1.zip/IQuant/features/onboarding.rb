﻿# features/onboarding.rb
# Sistema de onboarding/tutorial interactivo para iQuant v4.1 (CORREGIDO)

# encoding: UTF-8

module IQuant
  module Features
    module Onboarding
      extend self
      
      # ==========================================================================
      # CONFIGURACIÓN DEL ONBOARDING
      # ==========================================================================
      
      STEPS = 5  # Número total de pasos
      
      ##
      # Inicia el tutorial interactivo
      #
      # @param dialog [UI::HtmlDialog] El diálogo principal
      #
      def start_tutorial(dialog)
        safe_execute('Iniciar onboarding') do
          IQuant::Utils::Logger.log("Iniciando tutorial interactivo", :info)
          
          # Inyectar HTML modal para onboarding
          dialog.execute_script(get_onboarding_html)
          
          # Mostrar primer paso
          next_step(dialog, 1)
          
          # Track inicio
          if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
            IQuant::Features::Analytics.track_event('onboarding_started')
          end
        end
      end
      
      ##
      # Avanza al siguiente paso del tutorial
      #
      # @param dialog [UI::HtmlDialog] El diálogo principal
      # @param step [Integer] Número del paso actual (1-5)
      #
      def next_step(dialog, step)
        safe_execute("Onboarding paso #{step}") do
          # AGREGAR ESTA LÍNEA AL INICIO DEL MÉTODO:
          IQuant.instance_variable_set(:@onboarding_current_step, step)
          
          lang = IQuant.current_lang || 'en'
          
          if step > STEPS
            complete_tutorial(dialog)
            return
          end
          
          # Obtener contenido del paso
          title = IQuant::Data::Localization.t("onboarding_step#{step}_title", lang)
          desc = IQuant::Data::Localization.t("onboarding_step#{step}_desc", lang)
          action = get_step_action(step)
          
          # Actualizar modal via JS
          dialog.execute_script("updateOnboardingStep(#{step}, '#{escape_js(title)}', '#{escape_js(desc)}', '#{escape_js(action)}')")
          
          # Ejecutar highlight o guía específica
          execute_step_guide(dialog, step)
          
          IQuant::Utils::Logger.log("Onboarding: Paso #{step} mostrado", :debug)
          
          # Track progreso
          if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
            IQuant::Features::Analytics.track_event('onboarding_step', { step: step })
          end
        end
      end
      
      ##
      # Retrocede al paso anterior
      #
      def previous_step(dialog, current_step)
        return if current_step <= 1
        # MODIFICAR PARA PASAR EL STEP CORRECTO:
        IQuant.instance_variable_set(:@onboarding_current_step, current_step - 1)
        next_step(dialog, current_step - 1)
      end
      
      ##
      # Salta el tutorial
      #
      def skip_tutorial(dialog)
        safe_execute('Saltar onboarding') do
          complete_tutorial(dialog)
          IQuant::Utils::Logger.log("Tutorial saltado por usuario", :info)
        end
      end
      
      ##
      # Completa el tutorial y marca como realizado
      #
      # @param dialog [UI::HtmlDialog] El diálogo principal
      #
      def complete_tutorial(dialog)
        safe_execute('Completar onboarding') do
          model = Sketchup.active_model
          model.set_attribute(IQuant::PREFS_KEY, "has_run_onboarding", true)
          
          # Cerrar modal
          dialog.execute_script("closeOnboardingModal()")
          
          IQuant::Utils::Logger.log("Tutorial completado", :info)
          
          # Track completado
          if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
            IQuant::Features::Analytics.track_event('onboarding_completed')
          end
        end
      end
      
      ##
      # Verifica si el usuario ya completó el onboarding
      #
      # @return [Boolean] true si ya completó el onboarding
      #
      def has_completed_onboarding?
        model = Sketchup.active_model
        model.get_attribute(IQuant::PREFS_KEY, "has_run_onboarding", false)
      end
      
      private
      
      ##
      # Obtiene el HTML para el modal de onboarding
      #
      # @return [String] HTML del modal
      #
      def get_onboarding_html
        lang = IQuant.current_lang || 'en'
        
        <<-HTML
        <div id="onboarding-modal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000;">
          <div class="modal-content" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 20px; border-radius: 8px; max-width: 500px; width: 90%;">
            <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
              <h2 style="margin: 0;">#{escape_html(IQuant::Data::Localization.t('onboarding_title', lang))}</h2>
              <button onclick="sketchupAction('onboarding_skip')" style="background: none; border: none; font-size: 18px; cursor: pointer;">✕</button>
            </div>
            
            <div class="modal-body">
              <div class="step-indicator" style="margin-bottom: 15px; color: #666;">
                Paso <span id="current-step">1</span> de #{STEPS}
              </div>
              
              <h3 id="step-title" style="margin-top: 0;"></h3>
              <p id="step-desc" style="line-height: 1.5;"></p>
              
              <div id="step-action" style="margin-top: 20px;"></div>
            </div>
            
            <div class="modal-footer" style="display: flex; justify-content: space-between; margin-top: 25px;">
              <button onclick="sketchupAction('onboarding_previous')" id="prev-btn" disabled style="padding: 8px 16px; background: #f0f0f0; border: 1px solid #ccc; border-radius: 4px; cursor: pointer;">← #{escape_html(IQuant::Data::Localization.t('previous', lang))}</button>
              <button onclick="sketchupAction('onboarding_next')" id="next-btn" style="padding: 8px 16px; background: #0078d4; color: white; border: none; border-radius: 4px; cursor: pointer;">#{escape_html(IQuant::Data::Localization.t('next', lang))} →</button>
            </div>
          </div>
        </div>
        
        <script>
          function updateOnboardingStep(step, title, desc, actionHtml) {
            document.getElementById('current-step').textContent = step;
            document.getElementById('step-title').textContent = title;
            document.getElementById('step-desc').textContent = desc;
            document.getElementById('step-action').innerHTML = actionHtml;
            
            document.getElementById('prev-btn').disabled = (step === 1);
            document.getElementById('next-btn').textContent = (step === #{STEPS}) ? '#{escape_html(IQuant::Data::Localization.t('finish', lang))}' : '#{escape_html(IQuant::Data::Localization.t('next', lang))} →';
            
            document.getElementById('onboarding-modal').style.display = 'block';
          }
          
          function closeOnboardingModal() {
            document.getElementById('onboarding-modal').style.display = 'none';
          }
        </script>
        HTML
      end
      
      ##
      # Obtiene la acción interactiva para cada paso (HTML)
      #
      # @param step [Integer] Número del paso
      # @return [String] HTML para la acción
      #
      def get_step_action(step)
        lang = IQuant.current_lang || 'en'
        
        case step
        when 1
          # Paso 1: Configuración inicial
          <<-HTML
          <div class="info-message" style="background: #e3f2fd; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
            #{escape_html(IQuant::Data::Localization.t('onboarding_step1_action', lang))}
          </div>
          <button onclick="sketchupAction('focus_currency_selector')" style="padding: 8px 16px; background: #0078d4; color: white; border: none; border-radius: 4px; cursor: pointer;">
            #{escape_html(IQuant::Data::Localization.t('configure_currency', lang))}
          </button>
          HTML
          
        when 2
          # Paso 2: Seleccionar objetos
          <<-HTML
          <div class="warning-message" style="background: #fff3cd; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
            #{escape_html(IQuant::Data::Localization.t('onboarding_step2_action', lang))}
          </div>
          <button onclick="sketchupAction('select_example_object')" style="padding: 8px 16px; background: #0078d4; color: white; border: none; border-radius: 4px; cursor: pointer;">
            #{escape_html(IQuant::Data::Localization.t('select_example', lang))}
          </button>
          HTML
          
        when 3
          # Paso 3: Configurar reglas
          <<-HTML
          <div class="success-message" style="background: #d4edda; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
            #{escape_html(IQuant::Data::Localization.t('onboarding_step3_action', lang))}
          </div>
          <button onclick="sketchupAction('switch_to_rules_tab')" style="padding: 8px 16px; background: #0078d4; color: white; border: none; border-radius: 4px; cursor: pointer;">
            #{escape_html(IQuant::Data::Localization.t('go_to_rules', lang))}
          </button>
          HTML
          
        when 4
          # Paso 4: Exportar reportes
          # Verificar si PDF está disponible
          pdf_disabled = begin
            require 'prawn'
            false
          rescue LoadError
            true
          end
          
          <<-HTML
          <div class="info-message" style="background: #e3f2fd; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
            #{escape_html(IQuant::Data::Localization.t('onboarding_step4_action', lang))}
          </div>
          <button onclick="sketchupAction('export_test_csv')" style="padding: 8px 16px; background: #0078d4; color: white; border: none; border-radius: 4px; cursor: pointer; margin-right: 10px;">
            #{escape_html(IQuant::Data::Localization.t('try_export_csv', lang))}
          </button>
          <button onclick="sketchupAction('export_test_pdf')" #{pdf_disabled ? 'disabled style="padding: 8px 16px; background: #ccc; color: #666; border: none; border-radius: 4px;"' : 'style="padding: 8px 16px; background: #0078d4; color: white; border: none; border-radius: 4px; cursor: pointer;"'}>
            #{escape_html(IQuant::Data::Localization.t('try_export_pdf', lang))}
          </button>
          HTML
          
        when 5
          # Paso 5: Features avanzadas
          <<-HTML
          <div class="success-message" style="background: #d4edda; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
            #{escape_html(IQuant::Data::Localization.t('onboarding_step5_action', lang))}
          </div>
          <button onclick="sketchupAction('switch_to_charts_tab')" style="padding: 8px 16px; background: #0078d4; color: white; border: none; border-radius: 4px; cursor: pointer; margin-right: 10px;">
            #{escape_html(IQuant::Data::Localization.t('view_charts', lang))}
          </button>
          <button onclick="sketchupAction('show_3d_preview')" style="padding: 8px 16px; background: #0078d4; color: white; border: none; border-radius: 4px; cursor: pointer;">
            #{escape_html(IQuant::Data::Localization.t('view_3d_preview', lang))}
          </button>
          HTML
          
        else
          ''
        end
      end
      
      ##
      # Ejecuta guías específicas por paso (highlights, acciones en SketchUp)
      #
      # @param dialog [UI::HtmlDialog] El diálogo
      # @param step [Integer] Número del paso
      #
      def execute_step_guide(dialog, step)
        case step
        when 1
          # Highlight selectores de config via callback
          # Esto se manejará en callbacks.rb
          nil
          
        when 2
          # Seleccionar objetos de ejemplo en SketchUp
          model = Sketchup.active_model
          model.selection.clear
          
          # Buscar algún grupo o componente
          entity = model.entities.grep(Sketchup::Group).first || 
                   model.entities.grep(Sketchup::ComponentInstance).first
          
          if entity
            model.selection.add(entity)
            IQuant::Utils::Logger.log("Objeto de ejemplo seleccionado: #{entity.entityID}", :info)
          else
            IQuant::Utils::Logger.log("No se encontraron objetos para el ejemplo", :warn)
          end
          
          # Notificar al dialog para refresh
          if defined?(IQuant::UI::DialogManager) && IQuant::UI::DialogManager.respond_to?(:refresh_dialog)
            IQuant::UI::DialogManager.refresh_dialog
          end
          
        when 3
          # Switch a tab rules - se maneja en callback
          nil
          
        when 4
          # Switch a tab report - se maneja en callback
          nil
          
        when 5
          # Switch a charts - se maneja en callback
          nil
        end
      end
      
      ##
      # Escapa texto para JavaScript
      #
      def escape_js(text)
        return '' unless text
        text.gsub("'", "\\\\'").gsub("\n", "\\n").gsub("\r", "\\r")
      end
      
      ##
      # Escapa texto para HTML
      #
      def escape_html(text)
        return '' unless text
        text.gsub('&', '&amp;').gsub('<', '&lt;').gsub('>', '&gt;').gsub('"', '&quot;').gsub("'", '&#39;')
      end
      
      ##
      # Obtiene los textos de localización para onboarding
      # (Backup en caso de que Localization no tenga las keys)
      #
      def get_localized_texts(lang)
        defaults = {
          'en' => {
            'onboarding_title' => 'Welcome to iQuant!',
            'onboarding_step1_title' => 'Step 1: Basic Configuration',
            'onboarding_step1_desc' => 'Configure your language, units and currency',
            'onboarding_step1_action' => 'Click the button below to focus the currency selector',
            'onboarding_step2_title' => 'Step 2: Select Objects',
            'onboarding_step2_desc' => 'Select objects in SketchUp to quantify them',
            'onboarding_step2_action' => 'We\'ve selected an example object for you',
            'onboarding_step3_title' => 'Step 3: Configure Cost Rules',
            'onboarding_step3_desc' => 'Set up cost rules for different materials',
            'onboarding_step3_action' => 'Go to the Rules tab to configure your first rule',
            'onboarding_step4_title' => 'Step 4: Export Reports',
            'onboarding_step4_desc' => 'Export your quantification reports to CSV, PDF or Excel',
            'onboarding_step4_action' => 'Try exporting a CSV report now',
            'onboarding_step5_title' => 'Step 5: Advanced Features',
            'onboarding_step5_desc' => 'Explore charts, 3D preview and other advanced features',
            'onboarding_step5_action' => 'Check out the charts and 3D preview features',
            'configure_currency' => 'Configure Currency',
            'select_example' => 'Select Example',
            'go_to_rules' => 'Go to Rules',
            'try_export_csv' => 'Try CSV Export',
            'try_export_pdf' => 'Try PDF Export',
            'view_charts' => 'View Charts',
            'view_3d_preview' => 'View 3D Preview',
            'previous' => 'Previous',
            'next' => 'Next',
            'finish' => 'Finish'
          },
          'es' => {
            'onboarding_title' => '¡Bienvenido a iQuant!',
            'onboarding_step1_title' => 'Paso 1: Configuración Básica',
            'onboarding_step1_desc' => 'Configura tu idioma, unidades y moneda',
            'onboarding_step1_action' => 'Haz clic en el botón para enfocar el selector de moneda',
            'onboarding_step2_title' => 'Paso 2: Seleccionar Objetos',
            'onboarding_step2_desc' => 'Selecciona objetos en SketchUp para cuantificarlos',
            'onboarding_step2_action' => 'Hemos seleccionado un objeto de ejemplo para ti',
            'onboarding_step3_title' => 'Paso 3: Configurar Reglas de Costo',
            'onboarding_step3_desc' => 'Configura reglas de costo para diferentes materiales',
            'onboarding_step3_action' => 'Ve a la pestaña Reglas para configurar tu primera regla',
            'onboarding_step4_title' => 'Paso 4: Exportar Reportes',
            'onboarding_step4_desc' => 'Exporta tus reportes de cuantificación a CSV, PDF o Excel',
            'onboarding_step4_action' => 'Prueba exportar un reporte CSV ahora',
            'onboarding_step5_title' => 'Paso 5: Funciones Avanzadas',
            'onboarding_step5_desc' => 'Explora gráficos, vista 3D y otras funciones avanzadas',
            'onboarding_step5_action' => 'Revisa las funciones de gráficos y vista 3D',
            'configure_currency' => 'Configurar Moneda',
            'select_example' => 'Seleccionar Ejemplo',
            'go_to_rules' => 'Ir a Reglas',
            'try_export_csv' => 'Probar Exportación CSV',
            'try_export_pdf' => 'Probar Exportación PDF',
            'view_charts' => 'Ver Gráficos',
            'view_3d_preview' => 'Ver Vista 3D',
            'previous' => 'Anterior',
            'next' => 'Siguiente',
            'finish' => 'Finalizar'
          }
        }
        
        defaults[lang] || defaults['en']
      end
      
      # Ejecución segura
      def safe_execute(operation, &block)
        if defined?(IQuant::Utils::ErrorHandler)
          IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
        else
          begin
            yield
          rescue => e
            IQuant::Utils::Logger.log("Error en #{operation}: #{e.message}", :error) if defined?(IQuant::Utils::Logger)
          end
        end
      end
      
    end
  end
end

# Si Localization no tiene las keys, agregarlas
if defined?(IQuant::Data::Localization) && defined?(IQuant::Data::Localization::STRINGS)
  # Agregar textos de onboarding en inglés
  IQuant::Data::Localization::STRINGS['en']['onboarding_title'] = 'Welcome to iQuant!'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step1_title'] = 'Step 1: Basic Configuration'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step1_desc'] = 'Configure your language, units and currency'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step1_action'] = 'Click the button below to focus the currency selector'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step2_title'] = 'Step 2: Select Objects'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step2_desc'] = 'Select objects in SketchUp to quantify them'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step2_action'] = 'We\'ve selected an example object for you'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step3_title'] = 'Step 3: Configure Cost Rules'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step3_desc'] = 'Set up cost rules for different materials'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step3_action'] = 'Go to the Rules tab to configure your first rule'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step4_title'] = 'Step 4: Export Reports'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step4_desc'] = 'Export your quantification reports to CSV, PDF or Excel'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step4_action'] = 'Try exporting a CSV report now'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step5_title'] = 'Step 5: Advanced Features'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step5_desc'] = 'Explore charts, 3D preview and other advanced features'
  IQuant::Data::Localization::STRINGS['en']['onboarding_step5_action'] = 'Check out the charts and 3D preview features'
  
  # Agregar textos en español
  IQuant::Data::Localization::STRINGS['es']['onboarding_title'] = '¡Bienvenido a iQuant!'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step1_title'] = 'Paso 1: Configuración Básica'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step1_desc'] = 'Configura tu idioma, unidades y moneda'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step1_action'] = 'Haz clic en el botón para enfocar el selector de moneda'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step2_title'] = 'Paso 2: Seleccionar Objetos'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step2_desc'] = 'Selecciona objetos en SketchUp para cuantificarlos'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step2_action'] = 'Hemos seleccionado un objeto de ejemplo para ti'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step3_title'] = 'Paso 3: Configurar Reglas de Costo'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step3_desc'] = 'Configura reglas de costo para diferentes materiales'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step3_action'] = 'Ve a la pestaña Reglas para configurar tu primera regla'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step4_title'] = 'Paso 4: Exportar Reportes'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step4_desc'] = 'Exporta tus reportes de cuantificación a CSV, PDF o Excel'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step4_action'] = 'Prueba exportar un reporte CSV ahora'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step5_title'] = 'Paso 5: Funciones Avanzadas'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step5_desc'] = 'Explora gráficos, vista 3D y otras funciones avanzadas'
  IQuant::Data::Localization::STRINGS['es']['onboarding_step5_action'] = 'Revisa las funciones de gráficos y vista 3D'
end
