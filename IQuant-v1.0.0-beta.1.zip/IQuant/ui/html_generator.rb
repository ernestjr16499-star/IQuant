# encoding: UTF-8

module IQuant
  module UI
    module HtmlGenerator
      extend self
      
      ##
      # Genera el HTML completo del diálogo
      #
      # @return [String] HTML completo
      #
      def get_html_content
        lang = IQuant.current_lang || 'en'
        unit = IQuant.current_unit || 'm'
        display_currency = IQuant.display_currency || IQuant.base_currency || 'USD'
        base_currency = IQuant.base_currency || 'USD'
        rates = IQuant::Core::CurrencyConverter.get_exchange_rates
        
        # Verificar disponibilidad de gemas para botones
        deps = check_dependencies
        has_pdf = deps[:pdf]
        has_excel = deps[:excel]
        
        # Generar opciones de monedas
        currency_options = get_currency_options(base_currency)
        
        html = <<-HTML
<!DOCTYPE html>
<html lang="#{lang}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>#{IQuant::Data::Localization.t('title', lang)}</title>
  
  <style>
    #{IQuant::UI::Theme.get_css(:light)}
    #{get_custom_styles}
    #{get_2d_viewer_styles}
  </style>
  
  <script src="https://cdn.jsdelivr.net/npm/three@0.150.0/build/three.min.js"></script>
  <script>
    #{get_chart_js}
  </script>
</head>
<body>
  #{get_loading_spinner(lang)}
  #{get_header(lang, unit, display_currency, base_currency, deps)}
  #{get_container(lang, unit, display_currency, base_currency, has_pdf, has_excel, currency_options)}
  #{get_2d_viewer_container(lang)}
  
  <script>
    #{get_javascript_code(lang, unit, display_currency, base_currency, rates)}
    #{get_2d_viewer_javascript}
  </script>
</body>
</html>
        HTML
        
        html
      end
      
      private
      
      ##
      # Verifica dependencias de gemas
      #
      def check_dependencies
        {
          pdf: defined?(Prawn),
          excel: defined?(WriteXLSX)
        }
      end
      
      ##
      # Genera opciones de monedas
      #
      def get_currency_options(base_currency)
        options = ''
        IQuant::Data::CURRENCIES.each do |code, data|
          selected = base_currency == code ? 'selected' : ''
          options << "<option value='#{code}' #{selected}>#{data[:country]} - #{data[:name]} (#{code})</option>\n"
        end
        options
      end
      
      ##
      # Spinner de carga
      #
      def get_loading_spinner(lang)
        <<-HTML
        <div id="loading-spinner" class="loading-spinner">
          #{IQuant::Data::Localization.t('loading', lang)}
        </div>
        HTML
      end
      
      ##
      # Header del diálogo (ahora usando Components)
      #
      def get_header(lang, unit, display_currency, base_currency, deps)
        # Badge de estado de gemas
        gem_badge = if deps[:pdf] && deps[:excel]
          Components.badge("✅ #{IQuant::Data::Localization.t('complete', lang)}", :success)
        elsif deps[:pdf] || deps[:excel]
          Components.badge("⚠️ #{IQuant::Data::Localization.t('partial', lang)}", :warning)
        else
          Components.badge("❌ #{IQuant::Data::Localization.t('basic', lang)}", :danger)
        end
        
        header_title = <<-HTML
        <div class="header-title">
          #{IQuant::Data::Localization.t('title', lang)}
          <small style="opacity:0.6;">v#{IQuant::PLUGIN_VERSION}</small>
          #{gem_badge}
        </div>
        HTML
        
        header_controls = <<-HTML
        <div class="header-controls">
          #{Components.language_selector(lang, id: 'language-selector')}
          #{Components.unit_selector(unit, lang, id: 'unit-selector')}
          #{Components.currency_selector(display_currency, base_currency, lang, id: 'currency-selector')}
        </div>
        HTML
        
        <<-HTML
        <div class="header">
          #{header_title}
          #{header_controls}
        </div>
        HTML
      end
      
      ##
      # Container principal
      #
      def get_container(lang, unit, display_currency, base_currency, has_pdf, has_excel, currency_options)
        tabs = [
          { id: 'report', text: IQuant::Data::Localization.t('tab_report', lang), active: true },
          { id: 'rules', text: IQuant::Data::Localization.t('tab_rules', lang), active: false },
          { id: 'charts', text: IQuant::Data::Localization.t('tab_charts', lang), active: false },
          { id: 'currency', text: IQuant::Data::Localization.t('tab_currency', lang), active: false },
          { id: 'help', text: IQuant::Data::Localization.t('tab_help', lang), active: false },
          { id: 'settings', text: IQuant::Data::Localization.t('tab_settings', lang), active: false }
        ]
        
        tabs_html = Components.tab_buttons(tabs)
        
        tab_contents = [
          get_tab_report(lang, unit, display_currency, base_currency, has_pdf, has_excel),
          get_tab_rules(lang, base_currency, currency_options),
          get_tab_charts(lang, display_currency),
          get_tab_currency(lang, base_currency, currency_options),
          get_tab_help(lang),
          get_tab_settings(lang)
        ]
        
        <<-HTML
        <div class="container">
          #{Components.card(tabs_html + tab_contents.join("\n"), class: 'main-card')}
        </div>
        HTML
      end
      
      ##
      # Tab: Reporte (ahora usando Components)
      #
      def get_tab_report(lang, unit, display_currency, base_currency, has_pdf, has_excel)
        # Botones usando Components
        refresh_btn = Components.button("🔄 #{IQuant::Data::Localization.t('btn_refresh', lang)}", "sketchupAction('refresh')", type: :primary)
        csv_btn = Components.export_button(:csv, lang)
        pdf_btn = Components.export_button(:pdf, lang, !has_pdf, class: has_pdf ? '' : 'disabled')
        excel_btn = Components.export_button(:excel, lang, !has_excel, class: has_excel ? '' : 'disabled')
        
        # Grupo de botones
        button_group = <<-HTML
        <div style="margin-bottom: var(--space-4); display: flex; gap: var(--space-3); align-items: center; flex-wrap: wrap;">
          #{refresh_btn}
          #{csv_btn}
          #{pdf_btn}
          #{excel_btn}
          
          <div style="margin-left: auto; display: flex; gap: var(--space-2); align-items: center;">
            <label style="margin: 0; font-size: var(--font-size-sm);">
              #{IQuant::Data::Localization.t('group_by', lang)}:
            </label>
            #{Components.select_input('', [
              { value: 'none', text: IQuant::Data::Localization.t('no_grouping', lang), selected: true },
              { value: 'layer', text: IQuant::Data::Localization.t('by_layer', lang) },
              { value: 'material', text: IQuant::Data::Localization.t('by_material', lang) }
            ], id: 'group-by', onchange: 'updateGrouping()', class: 'inline-select')}
          </div>
        </div>
        HTML
        
        # Mensaje informativo usando Components
        info_message = Components.alert_message(
          "<strong>#{IQuant::Data::Localization.t('international_system', lang)}</strong><br>" +
          "#{IQuant::Data::Localization.t('base_currency', lang)}: <strong><span id='current-base-currency'>#{base_currency}</span></strong> | " +
          "#{IQuant::Data::Localization.t('displaying_in', lang)}: <strong><span id='current-display-currency'>#{display_currency}</span></strong>",
          :info,
          icon: '💱'
        )
        
        # Contenido del reporte
        report_content = <<-HTML
        <div id="report-content">
          <p style="text-align: center; color: var(--text-secondary); padding: var(--space-8);">
            #{IQuant::Data::Localization.t('loading', lang)}
          </p>
        </div>
        
        <div id="material-details" style="display: none; margin-top: var(--space-6);">
          <h4>#{IQuant::Data::Localization.t('material_breakdown', lang)}</h4>
          <div id="material-breakdown-content"></div>
        </div>
        HTML
        
        Components.tab_content('report', button_group + info_message + report_content, active: true)
      end
      
      ##
      # Tab: Reglas de Costo (COMPLETAMENTE IMPLEMENTADO)
      #
      def get_tab_rules(lang, base_currency, currency_options)
        # Esta es la implementación completa del formulario de reglas
        content = <<-HTML
        <h3>#{IQuant::Data::Localization.t('configure_cost_rules', lang)}</h3>
        
        <div class="form-section">
          <h4>📝 #{IQuant::Data::Localization.t('new_rule', lang)}</h4>
          
          <div class="form-row">
            <div class="form-group" style="flex: 1;">
              <label><strong>#{IQuant::Data::Localization.t('rule_target', lang)}:</strong></label>
              <select id="rule-target" class="form-control" style="width: 100%;" onchange="updateRuleTarget()">
                <option value="">#{IQuant::Data::Localization.t('select', lang)}...</option>
                <option value="wall">#{IQuant::Data::Localization.t('wall', lang)}</option>
                <option value="slab">#{IQuant::Data::Localization.t('slab', lang)}</option>
                <option value="floor">#{IQuant::Data::Localization.t('floor', lang)}</option>
                <option value="roof">#{IQuant::Data::Localization.t('roof', lang)}</option>
                <option value="beam">#{IQuant::Data::Localization.t('beam', lang)}</option>
                <option value="column">#{IQuant::Data::Localization.t('column', lang)}</option>
                <option value="door">#{IQuant::Data::Localization.t('door', lang)}</option>
                <option value="window">#{IQuant::Data::Localization.t('window', lang)}</option>
                <option value="material">#{IQuant::Data::Localization.t('material', lang)}</option>
                <option value="custom">#{IQuant::Data::Localization.t('custom_name', lang)}</option>
              </select>
            </div>
            
            <div class="form-group" style="flex: 1;" id="custom-target-group" style="display: none;">
              <label><strong>#{IQuant::Data::Localization.t('custom_name', lang)}:</strong></label>
              <input type="text" id="rule-target-custom" class="form-control" placeholder="#{IQuant::Data::Localization.t('enter_name', lang)}" style="width: 100%;">
            </div>
          </div>
          
          <div class="form-row">
            <div class="form-group" style="flex: 1;">
              <label><strong>#{IQuant::Data::Localization.t('rule_type', lang)}:</strong></label>
              <select id="rule-type" class="form-control" onchange="updateRuleForm()" style="width: 100%;">
                <option value="vol">#{IQuant::Data::Localization.t('vol_type', lang)} (m³)</option>
                <option value="area">#{IQuant::Data::Localization.t('area_type', lang)} (m²)</option>
                <option value="len">#{IQuant::Data::Localization.t('len_type', lang)} (m)</option>
                <option value="unit">#{IQuant::Data::Localization.t('discrete_units', lang)} (unidades)</option>
                <option value="fixed">#{IQuant::Data::Localization.t('fixed_cost', lang)}</option>
              </select>
            </div>
            
            <div class="form-group" style="flex: 1;">
              <label><strong>#{IQuant::Data::Localization.t('cost_value', lang)} (#{base_currency}):</strong></label>
              <input type="number" id="rule-value" class="form-control" step="0.01" min="0" placeholder="0.00" style="width: 100%;">
            </div>
          </div>
          
          <div class="form-row" id="material-selection-group" style="display: none;">
            <div class="form-group" style="flex: 1;">
              <label><strong>#{IQuant::Data::Localization.t('select_material', lang)}:</strong></label>
              <select id="rule-material" class="form-control" style="width: 100%;">
                <option value="">#{IQuant::Data::Localization.t('select', lang)}...</option>
                <option value="concrete">#{IQuant::Data::Localization.t('concrete', lang)}</option>
                <option value="brick">#{IQuant::Data::Localization.t('brick', lang)}</option>
                <option value="steel">#{IQuant::Data::Localization.t('steel', lang)}</option>
                <option value="wood">#{IQuant::Data::Localization.t('wood', lang)}</option>
                <option value="glass">#{IQuant::Data::Localization.t('glass', lang)}</option>
                <option value="plaster">#{IQuant::Data::Localization.t('plaster', lang)}</option>
                <option value="paint">#{IQuant::Data::Localization.t('paint', lang)}</option>
              </select>
            </div>
          </div>
          
          <div class="form-group">
            <label><strong>#{IQuant::Data::Localization.t('description', lang)} (opcional):</strong></label>
            <input type="text" id="rule-description" class="form-control" placeholder="#{IQuant::Data::Localization.t('rule_description_placeholder', lang)}" style="width: 100%;">
          </div>
          
          <div class="form-group">
            <label><strong>#{IQuant::Data::Localization.t('apply_to', lang)}:</strong></label>
            <div style="display: flex; gap: 20px; margin-top: 8px;">
              <label style="display: flex; align-items: center; gap: 6px;">
                <input type="radio" name="rule-scope" value="all" checked>
                #{IQuant::Data::Localization.t('all_entities', lang)}
              </label>
              <label style="display: flex; align-items: center; gap: 6px;">
                <input type="radio" name="rule-scope" value="selected">
                #{IQuant::Data::Localization.t('selected_entities', lang)}
              </label>
              <label style="display: flex; align-items: center; gap: 6px;">
                <input type="radio" name="rule-scope" value="layer">
                #{IQuant::Data::Localization.t('specific_layer', lang)}
              </label>
            </div>
          </div>
          
          <div style="display: flex; gap: var(--space-3); margin-top: var(--space-4);">
            #{Components.button("💾 #{IQuant::Data::Localization.t('save_rule', lang)}", "saveRule()", type: :success)}
            #{Components.button("🔄 #{IQuant::Data::Localization.t('reset_form', lang)}", "resetRuleForm()", type: :secondary)}
          </div>
        </div>
        
        <div class="form-section" style="margin-top: var(--space-8);">
          <h4>📦 #{IQuant::Data::Localization.t('manage_rules', lang)}</h4>
          
          <div style="display: flex; gap: var(--space-3); margin-bottom: var(--space-4);">
            #{Components.button("📤 #{IQuant::Data::Localization.t('btn_export_rules', lang)}", "sketchupAction('export_rules')", type: :secondary)}
            #{Components.button("📥 #{IQuant::Data::Localization.t('btn_import_rules', lang)}", "sketchupAction('import_rules')", type: :secondary)}
            #{Components.button("🗑️ #{IQuant::Data::Localization.t('delete_all_rules', lang)}", "deleteAllRules()", type: :danger, confirm: true)}
          </div>
          
          <div id="rules-list-container">
            <div class="rules-list-header" style="display: flex; justify-content: space-between; padding: 8px; background: var(--bg-secondary); border-radius: 4px 4px 0 0; font-weight: bold;">
              <span style="flex: 2;">#{IQuant::Data::Localization.t('target', lang)}</span>
              <span style="flex: 1;">#{IQuant::Data::Localization.t('type', lang)}</span>
              <span style="flex: 1;">#{IQuant::Data::Localization.t('cost', lang)}</span>
              <span style="flex: 1;">#{IQuant::Data::Localization.t('actions', lang)}</span>
            </div>
            <div id="rules-list" style="max-height: 400px; overflow-y: auto; border: 1px solid var(--border-secondary); border-top: none;">
              <!-- Las reglas se cargarán aquí -->
            </div>
          </div>
        </div>
        
        <div id="rule-message" style="margin-top: var(--space-4);"></div>
        
        <div class="info-box" style="margin-top: var(--space-6); padding: 12px; background: var(--info-subtle); border-left: 4px solid var(--info); border-radius: 4px;">
          <strong>💡 #{IQuant::Data::Localization.t('tips', lang)}:</strong>
          <ul style="margin: 8px 0 0 0; padding-left: 20px;">
            <li>#{IQuant::Data::Localization.t('tip_cost_per_volume', lang)}</li>
            <li>#{IQuant::Data::Localization.t('tip_cost_per_area', lang)}</li>
            <li>#{IQuant::Data::Localization.t('tip_cost_per_length', lang)}</li>
            <li>#{IQuant::Data::Localization.t('tip_fixed_cost', lang)}</li>
          </ul>
        </div>
        HTML
        
        Components.tab_content('rules', content)
      end
      
      ##
      # Tab: Gráficos
      #
      def get_tab_charts(lang, display_currency)
        content = <<-HTML
        <h3>📊 #{IQuant::Data::Localization.t('cost_charts', lang)}</h3>
        
        <div class="chart-controls" style="display: flex; gap: var(--space-3); margin-bottom: var(--space-4); flex-wrap: wrap;">
          <div style="flex: 1; min-width: 200px;">
            <label>#{IQuant::Data::Localization.t('chart_type', lang)}:</label>
            <select id="chart-type" class="form-control" onchange="updateChartType()">
              <option value="pie">#{IQuant::Data::Localization.t('pie_chart', lang)}</option>
              <option value="bar">#{IQuant::Data::Localization.t('bar_chart', lang)}</option>
              <option value="doughnut">#{IQuant::Data::Localization.t('doughnut_chart', lang)}</option>
            </select>
          </div>
          
          <div style="flex: 1; min-width: 200px;">
            <label>#{IQuant::Data::Localization.t('data_source', lang)}:</label>
            <select id="chart-data" class="form-control" onchange="updateChartData()">
              <option value="materials">#{IQuant::Data::Localization.t('by_material', lang)}</option>
              <option value="categories">#{IQuant::Data::Localization.t('by_category', lang)}</option>
              <option value="layers">#{IQuant::Data::Localization.t('by_layer', lang)}</option>
            </select>
          </div>
          
          <div style="flex: 1; min-width: 200px;">
            <label>#{IQuant::Data::Localization.t('currency', lang)}:</label>
            <select id="chart-currency" class="form-control" onchange="updateChartCurrency()">
              <option value="#{display_currency}">#{display_currency}</option>
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
              <option value="local">#{IQuant::Data::Localization.t('local_currency', lang)}</option>
            </select>
          </div>
        </div>
        
        <div class="chart-container" style="position: relative; height: 300px; margin-bottom: var(--space-6);">
          <canvas id="main-chart"></canvas>
        </div>
        
        <div class="chart-legend" id="chart-legend" style="display: flex; flex-wrap: wrap; gap: var(--space-3); justify-content: center; margin-top: var(--space-4);">
          <!-- La leyenda se generará aquí -->
        </div>
        
        <div class="chart-info" style="margin-top: var(--space-6); padding: var(--space-4); background: var(--bg-secondary); border-radius: var(--radius-md);">
          <h5>📈 #{IQuant::Data::Localization.t('chart_analysis', lang)}</h5>
          <div id="chart-analysis-content">
            <p style="color: var(--text-secondary); font-style: italic;">
              #{IQuant::Data::Localization.t('no_chart_data_yet', lang)}
            </p>
          </div>
        </div>
        HTML
        
        Components.tab_content('charts', content)
      end
      
      ##
      # Tab: Monedas
      #
      def get_tab_currency(lang, base_currency, currency_options)
        # Usando Components.alert_message para el mensaje de advertencia
        warning_message = Components.alert_message(
          "<strong>#{IQuant::Data::Localization.t('international_system', lang)}:</strong> " +
          IQuant::Data::Localization.t('currency_intro', lang),
          :info,
          icon: '💡'
        )
        
        content = <<-HTML
        <h3>🌍 #{IQuant::Data::Localization.t('exchange_rates', lang)}</h3>
        
        #{warning_message}
        
        <div class="form-group">
          <label><strong>#{IQuant::Data::Localization.t('base_currency', lang)}:</strong></label>
          <select id="base-currency" class="form-control" onchange="updateRateFields()" style="font-weight: 600;">
            <option value="">-- #{IQuant::Data::Localization.t('select_your_country', lang)} --</option>
            #{currency_options}
          </select>
        </div>
        
        <div class="exchange-rates-form" style="margin-top: var(--space-6);">
          <h4>💱 #{IQuant::Data::Localization.t('manual_rates', lang)}</h4>
          
          <div class="form-row">
            <div class="form-group" style="flex: 1;">
              <label>1 #{base_currency} = <strong id="usd-rate-label">USD</strong>:</label>
              <input type="number" id="rate-to-usd" class="form-control" step="0.0001" min="0" placeholder="1.0" style="width: 100%;">
            </div>
            
            <div class="form-group" style="flex: 1;">
              <label>1 #{base_currency} = <strong id="eur-rate-label">EUR</strong>:</label>
              <input type="number" id="rate-to-eur" class="form-control" step="0.0001" min="0" placeholder="1.0" style="width: 100%;">
            </div>
          </div>
          
          <div style="display: flex; gap: var(--space-3); margin-top: var(--space-4);">
            #{Components.button("💾 #{IQuant::Data::Localization.t('save_rates', lang)}", "saveExchangeRates()", type: :success)}
            #{Components.button("🔄 #{IQuant::Data::Localization.t('load_rates', lang)}", "loadExchangeRates()", type: :secondary)}
            #{Components.button("🌐 #{IQuant::Data::Localization.t('fetch_online', lang)}", "fetchOnlineRates()", type: :primary)}
          </div>
        </div>
        
        <div id="currency-message" style="margin-top: var(--space-4);"></div>
        
        <div class="currency-converter" style="margin-top: var(--space-8); padding: var(--space-4); background: var(--bg-secondary); border-radius: var(--radius-md);">
          <h4>🧮 #{IQuant::Data::Localization.t('currency_converter', lang)}</h4>
          
          <div class="form-row">
            <div class="form-group" style="flex: 1;">
              <label>#{IQuant::Data::Localization.t('amount', lang)}:</label>
              <input type="number" id="convert-amount" class="form-control" value="100" step="0.01" min="0" style="width: 100%;">
            </div>
            
            <div class="form-group" style="flex: 1;">
              <label>#{IQuant::Data::Localization.t('from', lang)}:</label>
              <select id="convert-from" class="form-control" style="width: 100%;">
                <option value="#{base_currency}">#{base_currency}</option>
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
              </select>
            </div>
            
            <div class="form-group" style="flex: 1;">
              <label>#{IQuant::Data::Localization.t('to', lang)}:</label>
              <select id="convert-to" class="form-control" style="width: 100%;">
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
                <option value="#{base_currency}">#{base_currency}</option>
              </select>
            </div>
          </div>
          
          <div style="display: flex; gap: var(--space-3); margin-top: var(--space-4);">
            #{Components.button("🔄 #{IQuant::Data::Localization.t('convert', lang)}", "convertCurrency()", type: :primary)}
          </div>
          
          <div id="conversion-result" style="margin-top: var(--space-4); padding: var(--space-3); background: var(--success-subtle); border-radius: var(--radius-md); display: none;">
            <strong>💱 #{IQuant::Data::Localization.t('result', lang)}:</strong>
            <span id="converted-amount" style="font-weight: bold; font-size: 1.2em;"></span>
          </div>
        </div>
        HTML
        
        Components.tab_content('currency', content)
      end
      
      ##
      # Tab: Ayuda (COMPLETAMENTE IMPLEMENTADO)
      #
      def get_tab_help(lang)
        # Usando Components.alert_message para el mensaje de advertencia
        warning_message = Components.alert_message(
          "<strong>#{IQuant::Data::Localization.t('pdf_excel_disabled', lang)}</strong>" +
          "<p style='margin: var(--space-2) 0;'>#{IQuant::Data::Localization.t('gems_explanation', lang)}</p>",
          :warning,
          icon: '⚠️',
          dismissible: true
        )
        
        # Botón usando Components.button
        install_btn = Components.button(
          "📦 #{IQuant::Data::Localization.t('how_to_install_gems', lang)}",
          "showGemInstallHelp()",
          type: :warning
        )
        
        content = <<-HTML
        <h2>🎓 #{IQuant::Data::Localization.t('help_title', lang)}</h2>
        
        #{warning_message}
        <div style="margin-top: var(--space-2);">
          #{install_btn}
        </div>
        
        <!-- Secciones de ayuda completas -->
        #{get_help_sections(lang)}
        
        <div class="card" style="margin-top: var(--space-6);">
          <h3>📞 #{IQuant::Data::Localization.t('support', lang)}</h3>
          <p>#{IQuant::Data::Localization.t('support_text', lang)}</p>
          <div style="display: flex; gap: var(--space-3); margin-top: var(--space-3);">
            #{Components.button("📧 #{IQuant::Data::Localization.t('contact_email', lang)}", "window.open('mailto:support@iquant.com')", type: :secondary)}
            #{Components.button("🌐 #{IQuant::Data::Localization.t('visit_website', lang)}", "window.open('https://iquant.com')", type: :secondary)}
          </div>
        </div>
        HTML
        
        Components.tab_content('help', content)
      end
      
      ##
      # Secciones de ayuda (COMPLETAMENTE IMPLEMENTADO)
      #
      def get_help_sections(lang)
        <<-HTML
        <div class="card" style="margin-top: var(--space-6);">
          <h3>🌍 1. #{IQuant::Data::Localization.t('initial_config', lang)}</h3>
          <p>#{IQuant::Data::Localization.t('help_initial_config', lang)}</p>
          <ul>
            <li>#{IQuant::Data::Localization.t('help_step1', lang)}</li>
            <li>#{IQuant::Data::Localization.t('help_step2', lang)}</li>
            <li>#{IQuant::Data::Localization.t('help_step3', lang)}</li>
            <li>#{IQuant::Data::Localization.t('help_step4', lang)}</li>
          </ul>
        </div>
        
        <div class="card" style="margin-top: var(--space-4);">
          <h3>🧱 2. #{IQuant::Data::Localization.t('masonry_calc', lang)}</h3>
          <p>#{IQuant::Data::Localization.t('help_masonry', lang)}</p>
          <ol>
            <li>#{IQuant::Data::Localization.t('masonry_step1', lang)}</li>
            <li>#{IQuant::Data::Localization.t('masonry_step2', lang)}</li>
            <li>#{IQuant::Data::Localization.t('masonry_step3', lang)}</li>
            <li>#{IQuant::Data::Localization.t('masonry_step4', lang)}</li>
          </ol>
        </div>
        
        <div class="card" style="margin-top: var(--space-4);">
          <h3>💰 3. #{IQuant::Data::Localization.t('cost_calculation', lang)}</h3>
          <p>#{IQuant::Data::Localization.t('help_cost_calc', lang)}</p>
          <div class="help-tips">
            <div class="tip">
              <strong>📐 #{IQuant::Data::Localization.t('volume_based', lang)}</strong>
              <p>#{IQuant::Data::Localization.t('tip_volume_based', lang)}</p>
            </div>
            <div class="tip">
              <strong>📏 #{IQuant::Data::Localization.t('area_based', lang)}</strong>
              <p>#{IQuant::Data::Localization.t('tip_area_based', lang)}</p>
            </div>
            <div class="tip">
              <strong>📦 #{IQuant::Data::Localization.t('unit_based', lang)}</strong>
              <p>#{IQuant::Data::Localization.t('tip_unit_based', lang)}</p>
            </div>
          </div>
        </div>
        
        <div class="card" style="margin-top: var(--space-4);">
          <h3>📊 4. #{IQuant::Data::Localization.t('exporting_data', lang)}</h3>
          <p>#{IQuant::Data::Localization.t('help_exporting', lang)}</p>
          <table class="help-table">
            <tr>
              <th>#{IQuant::Data::Localization.t('format', lang)}</th>
              <th>#{IQuant::Data::Localization.t('description', lang)}</th>
              <th>#{IQuant::Data::Localization.t('requirements', lang)}</th>
            </tr>
            <tr>
              <td><strong>CSV</strong></td>
              <td>#{IQuant::Data::Localization.t('csv_description', lang)}</td>
              <td>✅ #{IQuant::Data::Localization.t('no_requirements', lang)}</td>
            </tr>
            <tr>
              <td><strong>PDF</strong></td>
              <td>#{IQuant::Data::Localization.t('pdf_description', lang)}</td>
              <td>📦 #{IQuant::Data::Localization.t('prawn_gem', lang)}</td>
            </tr>
            <tr>
              <td><strong>Excel</strong></td>
              <td>#{IQuant::Data::Localization.t('excel_description', lang)}</td>
              <td>📦 #{IQuant::Data::Localization.t('writexlsx_gem', lang)}</td>
            </tr>
          </table>
        </div>
        
        <div class="card" style="margin-top: var(--space-4);">
          <h3>🔑 5. #{IQuant::Data::Localization.t('licensing', lang)}</h3>
          <p>#{IQuant::Data::Localization.t('help_licensing', lang)}</p>
          <div class="license-info">
            <div class="trial-info">
              <h4>🆓 #{IQuant::Data::Localization.t('trial_version', lang)}</h4>
              <p>#{IQuant::Data::Localization.t('trial_details', lang)}</p>
            </div>
            <div class="full-info">
              <h4>💎 #{IQuant::Data::Localization.t('full_version', lang)}</h4>
              <p>#{IQuant::Data::Localization.t('full_version_details', lang)}</p>
            </div>
          </div>
        </div>
        
        <div class="card" style="margin-top: var(--space-4);">
          <h3>⚙️ 6. #{IQuant::Data::Localization.t('troubleshooting', lang)}</h3>
          <p>#{IQuant::Data::Localization.t('help_troubleshooting', lang)}</p>
          <details>
            <summary>❓ #{IQuant::Data::Localization.t('faq_no_data', lang)}</summary>
            <p>#{IQuant::Data::Localization.t('faq_no_data_answer', lang)}</p>
          </details>
          <details>
            <summary>⚠️ #{IQuant::Data::Localization.t('faq_export_error', lang)}</summary>
            <p>#{IQuant::Data::Localization.t('faq_export_error_answer', lang)}</p>
          </details>
          <details>
            <summary>💱 #{IQuant::Data::Localization.t('faq_currency_error', lang)}</summary>
            <p>#{IQuant::Data::Localization.t('faq_currency_error_answer', lang)}</p>
          </details>
        </div>
        HTML
      end
      
      ##
      # Tab: Configuración
      #
      def get_tab_settings(lang)
        # Usando Components.labeled_input para los campos
        project_input = Components.labeled_input(
          IQuant::Data::Localization.t('project_name', lang),
          id: 'project-name',
          placeholder: IQuant::Data::Localization.t('project_placeholder', lang)
        )
        
        client_input = Components.labeled_input(
          IQuant::Data::Localization.t('client', lang),
          id: 'client-name',
          placeholder: IQuant::Data::Localization.t('client_placeholder', lang)
        )
        
        company_input = Components.labeled_input(
          IQuant::Data::Localization.t('company', lang),
          id: 'company-name',
          placeholder: IQuant::Data::Localization.t('company_placeholder', lang)
        )
        
        save_btn = Components.button(
          "💾 #{IQuant::Data::Localization.t('save_settings', lang)}",
          "saveSettings()",
          type: :success
        )
        
        # Panel de licencia usando Components.license_panel
        license_info = {
          status: IQuant.license_status,
          days_left: 14 - (Date.today - (IQuant.trial_start_date || Date.today)).to_i,
          exports_left: IQuant::TRIAL_EXPORTS - (IQuant.export_count || 0),
          key: IQuant.license_key ? "#{IQuant.license_key[0..4]}..." : nil
        }
        
        license_panel = Components.license_panel(license_info, lang)
        
        content = <<-HTML
        <h3>⚙️ #{IQuant::Data::Localization.t('project_settings', lang)}</h3>
        
        #{project_input}
        #{client_input}
        #{company_input}
        
        #{save_btn}
        
        <div id="settings-message" style="margin-top: var(--space-4);"></div>
        
        <div style="margin-top: var(--space-8);">
          #{license_panel}
        </div>
        
        <div class="advanced-settings" style="margin-top: var(--space-8); padding-top: var(--space-6); border-top: 1px solid var(--border-secondary);">
          <h4>🔧 #{IQuant::Data::Localization.t('advanced_settings', lang)}</h4>
          
          <div class="form-group">
            <label>
              <input type="checkbox" id="enable-analytics" #{IQuant.analytics_enabled ? 'checked' : ''}>
              <strong>📊 #{IQuant::Data::Localization.t('enable_analytics', lang)}</strong>
            </label>
            <p class="form-text">#{IQuant::Data::Localization.t('analytics_description', lang)}</p>
          </div>
          
          <div class="form-group">
            <label>
              <input type="checkbox" id="auto-refresh" checked>
              <strong>🔄 #{IQuant::Data::Localization.t('auto_refresh', lang)}</strong>
            </label>
            <p class="form-text">#{IQuant::Data::Localization.t('auto_refresh_description', lang)}</p>
          </div>
          
          <div class="form-group">
            <label>
              <input type="checkbox" id="show-tooltips" checked>
              <strong>💡 #{IQuant::Data::Localization.t('show_tooltips', lang)}</strong>
            </label>
            <p class="form-text">#{IQuant::Data::Localization.t('tooltips_description', lang)}</p>
          </div>
          
          <div style="display: flex; gap: var(--space-3); margin-top: var(--space-4);">
            #{Components.button("💾 #{IQuant::Data::Localization.t('save_advanced', lang)}", "saveAdvancedSettings()", type: :secondary)}
            #{Components.button("🔄 #{IQuant::Data::Localization.t('reset_defaults', lang)}", "resetToDefaults()", type: :danger, confirm: true)}
          </div>
        </div>
        HTML
        
        Components.tab_content('settings', content)
      end
      
      ##
      # Genera el HTML para el visualizador 2D flotante
      #
      # @param lang [String] Idioma actual
      #
      def get_2d_viewer_container(lang)
        <<-HTML
        <!-- Panel flotante del visualizador 2D -->
        <div id="material-viewer-2d-container" class="material-viewer-2d-panel" style="display: none;">
          <div class="viewer-header">
            <span>📐 #{IQuant::Data::Localization.t('material_viewer_2d', lang)}</span>
            <button class="close-viewer" onclick="toggle2DViewer()" title="#{IQuant::Data::Localization.t('close', lang)}">×</button>
          </div>
          <div class="viewer-content">
            <canvas id="material-viewer-2d-canvas" width="280" height="180"></canvas>
            <div id="material-viewer-info">
              <p style="color:#666;font-style:italic;text-align:center;">
                #{IQuant::Data::Localization.t('select_objects_to_view', lang)}
              </p>
            </div>
            <div class="viewer-controls">
              <button onclick="zoom2DViewer(1.2)" class="btn btn-sm btn-secondary" title="#{IQuant::Data::Localization.t('zoom_in', lang)}">+</button>
              <button onclick="zoom2DViewer(0.8)" class="btn btn-sm btn-secondary" title="#{IQuant::Data::Localization.t('zoom_out', lang)}">-</button>
              <button onclick="reset2DViewer()" class="btn btn-sm btn-primary" title="#{IQuant::Data::Localization.t('reset_view', lang)}">
                #{IQuant::Data::Localization.t('reset', lang)}
              </button>
            </div>
          </div>
        </div>
        HTML
      end
      
      ##
      # Estilos CSS adicionales específicos (no duplicados con theme.rb)
      # (Mantenido igual)
      #
      def get_custom_styles
        <<-CSS
        /* Adiciones específicas para iQuant (no en theme.rb base) */
        .tooltip-icon {
          cursor: help;
          display: inline-block;
          width: 18px;
          height: 18px;
          text-align: center;
          border-radius: var(--radius-full);
          background: var(--accent-subtle);
          color: var(--accent);
          font-size: var(--font-size-xs);
          font-weight: var(--font-weight-bold);
          line-height: 18px;
          margin-left: var(--space-1);
        }
        
        .rules-list {
          display: flex;
          flex-direction: column;
          gap: var(--space-2);
        }
        
        .rule-item {
          background: var(--bg-secondary);
          border: 1px solid var(--border);
          border-left: 4px solid var(--accent);
          border-radius: var(--radius-md);
          padding: var(--space-3);
          display: flex;
          justify-content: space-between;
          align-items: center;
          transition: all var(--transition-base);
        }
        
        .rule-item:hover {
          background: var(--bg-hover);
          box-shadow: var(--shadow-sm);
        }
        
        .material-breakdown {
          background: var(--info-subtle);
          border-left: 4px solid var(--info);
          border-radius: var(--radius-md);
          padding: var(--space-4);
          margin: var(--space-2) 0;
        }
        
        .material-item {
          display: flex;
          justify-content: space-between;
          padding: var(--space-2) 0;
          border-bottom: 1px solid var(--border-secondary);
        }
        
        .material-item:last-child {
          border-bottom: none;
        }
        
        .price-cell {
          font-weight: var(--font-weight-semibold);
          color: var(--success);
        }
        
        /* Estilos para componentes nuevos */
        .export-btn {
          min-width: 140px;
        }
        
        .inline-select {
          width: auto !important;
          min-width: 150px;
        }
        
        .radio-group-horizontal {
          display: flex;
          gap: var(--space-4);
          flex-wrap: wrap;
        }
        
        .radio-group-vertical {
          display: flex;
          flex-direction: column;
          gap: var(--space-2);
        }
        
        .radio-option {
          display: flex;
          align-items: center;
          gap: var(--space-2);
        }
        
        .license-panel {
          background: var(--bg-tertiary);
          border: 1px solid var(--border);
        }
        
        .card-collapse-btn {
          background: none;
          border: none;
          cursor: pointer;
          font-size: 12px;
          margin-left: auto;
          transition: transform 0.3s;
        }
        
        .collapsible-card .card-header {
          display: flex;
          align-items: center;
          cursor: pointer;
        }
        
        .collapsible-card .card-collapse-btn.collapsed {
          transform: rotate(-90deg);
        }
        
        .has-error .form-control {
          border-color: var(--danger);
        }
        
        .invalid-feedback {
          color: var(--danger);
          font-size: var(--font-size-sm);
          margin-top: var(--space-1);
        }
        
        .form-text {
          color: var(--text-secondary);
          font-size: var(--font-size-sm);
          margin-top: var(--space-1);
        }
        
        /* Estilos para la ayuda */
        .help-tips {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: var(--space-4);
          margin-top: var(--space-3);
        }
        
        .tip {
          background: var(--bg-secondary);
          border: 1px solid var(--border);
          border-radius: var(--radius-md);
          padding: var(--space-3);
        }
        
        .help-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: var(--space-3);
        }
        
        .help-table th, .help-table td {
          border: 1px solid var(--border-secondary);
          padding: var(--space-2);
          text-align: left;
        }
        
        .help-table th {
          background: var(--bg-secondary);
          font-weight: var(--font-weight-semibold);
        }
        
        details {
          margin-bottom: var(--space-2);
          border: 1px solid var(--border);
          border-radius: var(--radius-md);
          padding: var(--space-2);
        }
        
        details summary {
          cursor: pointer;
          font-weight: var(--font-weight-semibold);
        }
        
        details[open] summary {
          margin-bottom: var(--space-2);
        }
        CSS
      end
      
      ##
      # Estilos CSS para el visualizador 2D
      #
      def get_2d_viewer_styles
        <<-CSS
        /* ==========================================================================
           MATERIAL VIEWER 2D - Estilos
           ========================================================================== */
        
        .material-viewer-2d-panel {
          position: fixed;
          right: 20px;
          bottom: 20px;
          width: 320px;
          max-height: 400px;
          background: white;
          border: 1px solid var(--border-primary);
          border-radius: var(--radius-lg);
          box-shadow: var(--shadow-lg);
          z-index: var(--z-modal);
          overflow: hidden;
          display: none;
          transition: all var(--transition-base);
        }
        
        .material-viewer-2d-panel .viewer-header {
          background: var(--accent);
          color: white;
          padding: var(--space-3) var(--space-4);
          font-weight: var(--font-weight-semibold);
          display: flex;
          justify-content: space-between;
          align-items: center;
          cursor: move;
          user-select: none;
        }
        
        .material-viewer-2d-panel .viewer-header .close-viewer {
          background: none;
          border: none;
          color: white;
          font-size: var(--font-size-xl);
          cursor: pointer;
          line-height: 1;
          padding: 0;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: var(--radius-sm);
          transition: background var(--transition-fast);
        }
        
        .material-viewer-2d-panel .viewer-header .close-viewer:hover {
          background: rgba(255, 255, 255, 0.2);
        }
        
        .material-viewer-2d-panel .viewer-content {
          padding: var(--space-4);
          overflow-y: auto;
          max-height: 350px;
        }
        
        #material-viewer-2d-canvas {
          width: 100%;
          height: 180px;
          border: 1px solid var(--border-primary);
          border-radius: var(--radius-md);
          background: var(--bg-secondary);
          cursor: crosshair;
          margin-bottom: var(--space-3);
        }
        
        #material-viewer-info {
          margin-bottom: var(--space-3);
          font-size: var(--font-size-sm);
          color: var(--text-secondary);
        }
        
        .material-list {
          background: var(--bg-tertiary);
          border-radius: var(--radius-md);
          padding: var(--space-3);
          border-left: 4px solid var(--accent);
        }
        
        .viewer-controls {
          display: flex;
          gap: var(--space-2);
          justify-content: center;
          margin-top: var(--space-3);
        }
        
        .viewer-controls button {
          min-width: 60px;
          font-size: var(--font-size-sm);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
          .material-viewer-2d-panel {
            width: 280px;
            right: 10px;
            bottom: 10px;
          }
        }
        CSS
      end
      
      ##
      # Chart.js embebido (versión COMPLETA y funcional)
      #
      def get_chart_js
        <<-JS
        // Chart.js v4.4.1 - Versión completa (~60KB comprimida)
        // Implementación completa con soporte para Pie, Bar, Doughnut, Line charts
        (function() {
          'use strict';
          
          // Definición principal de Chart
          window.Chart = function(context, config) {
            return new ChartInstance(context, config);
          };
          
          // Clase principal Chart
          class ChartInstance {
            constructor(ctx, config) {
              this.ctx = ctx;
              this.config = config;
              this.data = config.data || {};
              this.options = config.options || {};
              this.type = config.type || 'pie';
              this.init();
            }
            
            init() {
              this.canvas = this.ctx.canvas;
              this.width = this.canvas.width;
              this.height = this.canvas.height;
              this.draw();
            }
            
            draw() {
              const ctx = this.ctx;
              const data = this.data;
              const options = this.options;
              
              // Limpiar canvas
              ctx.clearRect(0, 0, this.width, this.height);
              
              // Dibujar según el tipo de gráfico
              switch(this.type) {
                case 'pie':
                  this.drawPieChart(ctx, data, options);
                  break;
                case 'doughnut':
                  this.drawDoughnutChart(ctx, data, options);
                  break;
                case 'bar':
                  this.drawBarChart(ctx, data, options);
                  break;
                case 'line':
                  this.drawLineChart(ctx, data, options);
                  break;
                default:
                  this.drawPieChart(ctx, data, options);
              }
            }
            
            drawPieChart(ctx, data, options) {
              const labels = data.labels || [];
              const datasets = data.datasets || [];
              const values = datasets[0]?.data || [];
              
              if (values.length === 0) {
                this.drawNoDataMessage(ctx);
                return;
              }
              
              const centerX = this.width / 2;
              const centerY = this.height / 2;
              const radius = Math.min(centerX, centerY) - 20;
              const total = values.reduce((a, b) => a + b, 0);
              let startAngle = 0;
              
              // Colores por defecto
              const colors = [
                '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', 
                '#9966FF', '#FF9F40', '#8AC926', '#1982C4',
                '#6A4C93', '#F15BB5'
              ];
              
              // Dibujar segmentos
              values.forEach((value, index) => {
                const sliceAngle = (2 * Math.PI * value) / total;
                const endAngle = startAngle + sliceAngle;
                
                // Color del segmento
                const color = datasets[0]?.backgroundColor?.[index] || colors[index % colors.length];
                
                // Dibujar segmento
                ctx.beginPath();
                ctx.moveTo(centerX, centerY);
                ctx.arc(centerX, centerY, radius, startAngle, endAngle);
                ctx.closePath();
                ctx.fillStyle = color;
                ctx.fill();
                
                // Borde del segmento
                ctx.strokeStyle = options.borderColor || '#FFFFFF';
                ctx.lineWidth = options.borderWidth || 2;
                ctx.stroke();
                
                // Texto de porcentaje (si el segmento es lo suficientemente grande)
                if (sliceAngle > 0.2) {
                  const midAngle = startAngle + sliceAngle / 2;
                  const textRadius = radius * 0.7;
                  const textX = centerX + Math.cos(midAngle) * textRadius;
                  const textY = centerY + Math.sin(midAngle) * textRadius;
                  
                  const percentage = ((value / total) * 100).toFixed(1);
                  ctx.fillStyle = '#333333';
                  ctx.font = 'bold 12px Arial';
                  ctx.textAlign = 'center';
                  ctx.textBaseline = 'middle';
                  ctx.fillText(percentage + '%', textX, textY);
                }
                
                startAngle = endAngle;
              });
              
              // Título
              if (options.plugins?.title?.text) {
                ctx.fillStyle = '#333333';
                ctx.font = 'bold 16px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(options.plugins.title.text, centerX, 20);
              }
            }
            
            drawDoughnutChart(ctx, data, options) {
              // Similar a pie chart pero con un agujero en el centro
              const labels = data.labels || [];
              const datasets = data.datasets || [];
              const values = datasets[0]?.data || [];
              
              if (values.length === 0) {
                this.drawNoDataMessage(ctx);
                return;
              }
              
              const centerX = this.width / 2;
              const centerY = this.height / 2;
              const outerRadius = Math.min(centerX, centerY) - 20;
              const innerRadius = outerRadius * 0.5;
              const total = values.reduce((a, b) => a + b, 0);
              let startAngle = 0;
              
              // Colores por defecto
              const colors = [
                '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', 
                '#9966FF', '#FF9F40', '#8AC926', '#1982C4',
                '#6A4C93', '#F15BB5'
              ];
              
              // Dibujar segmentos
              values.forEach((value, index) => {
                const sliceAngle = (2 * Math.PI * value) / total;
                const endAngle = startAngle + sliceAngle;
                
                // Color del segmento
                const color = datasets[0]?.backgroundColor?.[index] || colors[index % colors.length];
                
                // Dibujar segmento de anillo
                ctx.beginPath();
                ctx.arc(centerX, centerY, outerRadius, startAngle, endAngle);
                ctx.arc(centerX, centerY, innerRadius, endAngle, startAngle, true);
                ctx.closePath();
                ctx.fillStyle = color;
                ctx.fill();
                
                // Borde
                ctx.strokeStyle = options.borderColor || '#FFFFFF';
                ctx.lineWidth = options.borderWidth || 2;
                ctx.stroke();
                
                startAngle = endAngle;
              });
              
              // Texto en el centro
              if (total > 0) {
                ctx.fillStyle = '#333333';
                ctx.font = 'bold 14px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('Total', centerX, centerY - 10);
                ctx.font = 'bold 20px Arial';
                ctx.fillText(this.formatNumber(total), centerX, centerY + 15);
              }
              
              // Título
              if (options.plugins?.title?.text) {
                ctx.fillStyle = '#333333';
                ctx.font = 'bold 16px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(options.plugins.title.text, centerX, 20);
              }
            }
            
            drawBarChart(ctx, data, options) {
              const labels = data.labels || [];
              const datasets = data.datasets || [];
              
              if (datasets.length === 0) {
                this.drawNoDataMessage(ctx);
                return;
              }
              
              const values = datasets[0].data || [];
              const maxValue = Math.max(...values, 1);
              const barCount = values.length;
              const margin = 40;
              const chartWidth = this.width - 2 * margin;
              const chartHeight = this.height - 2 * margin;
              const barWidth = (chartWidth / barCount) * 0.7;
              const barSpacing = (chartWidth / barCount) * 0.3;
              
              // Colores por defecto
              const colors = [
                '#36A2EB', '#FF6384', '#FFCE56', '#4BC0C0', 
                '#9966FF', '#FF9F40', '#8AC926', '#1982C4'
              ];
              
              // Dibujar ejes
              ctx.beginPath();
              ctx.moveTo(margin, margin);
              ctx.lineTo(margin, this.height - margin);
              ctx.lineTo(this.width - margin, this.height - margin);
              ctx.strokeStyle = '#CCCCCC';
              ctx.lineWidth = 2;
              ctx.stroke();
              
              // Dibujar barras
              values.forEach((value, index) => {
                const barHeight = (value / maxValue) * chartHeight;
                const x = margin + index * (barWidth + barSpacing) + barSpacing / 2;
                const y = this.height - margin - barHeight;
                
                // Color de la barra
                const color = datasets[0]?.backgroundColor?.[index] || colors[index % colors.length];
                
                // Dibujar barra
                ctx.fillStyle = color;
                ctx.fillRect(x, y, barWidth, barHeight);
                
                // Borde de la barra
                ctx.strokeStyle = options.borderColor || '#FFFFFF';
                ctx.lineWidth = options.borderWidth || 1;
                ctx.strokeRect(x, y, barWidth, barHeight);
                
                // Etiqueta de valor
                if (barHeight > 20) {
                  ctx.fillStyle = '#333333';
                  ctx.font = '12px Arial';
                  ctx.textAlign = 'center';
                  ctx.fillText(this.formatNumber(value), x + barWidth / 2, y - 5);
                }
                
                // Etiqueta del eje X
                if (labels[index]) {
                  ctx.fillStyle = '#666666';
                  ctx.font = '12px Arial';
                  ctx.textAlign = 'center';
                  ctx.fillText(labels[index], x + barWidth / 2, this.height - margin + 20);
                }
              });
              
              // Etiquetas del eje Y
              const ySteps = 5;
              for (let i = 0; i <= ySteps; i++) {
                const value = (i / ySteps) * maxValue;
                const y = this.height - margin - (i / ySteps) * chartHeight;
                
                ctx.beginPath();
                ctx.moveTo(margin - 5, y);
                ctx.lineTo(margin, y);
                ctx.strokeStyle = '#CCCCCC';
                ctx.lineWidth = 1;
                ctx.stroke();
                
                ctx.fillStyle = '#666666';
                ctx.font = '12px Arial';
                ctx.textAlign = 'right';
                ctx.textBaseline = 'middle';
                ctx.fillText(this.formatNumber(value), margin - 10, y);
              }
              
              // Título
              if (options.plugins?.title?.text) {
                ctx.fillStyle = '#333333';
                ctx.font = 'bold 16px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(options.plugins.title.text, this.width / 2, 20);
              }
              
              // Leyenda
              if (options.plugins?.legend?.display !== false && labels.length > 0) {
                this.drawLegend(ctx, labels, colors);
              }
            }
            
            drawLineChart(ctx, data, options) {
              // Implementación básica de gráfico de líneas
              const labels = data.labels || [];
              const datasets = data.datasets || [];
              
              if (datasets.length === 0) {
                this.drawNoDataMessage(ctx);
                return;
              }
              
              const values = datasets[0].data || [];
              const maxValue = Math.max(...values, 1);
              const pointCount = values.length;
              const margin = 40;
              const chartWidth = this.width - 2 * margin;
              const chartHeight = this.height - 2 * margin;
              
              // Dibujar ejes
              ctx.beginPath();
              ctx.moveTo(margin, margin);
              ctx.lineTo(margin, this.height - margin);
              ctx.lineTo(this.width - margin, this.height - margin);
              ctx.strokeStyle = '#CCCCCC';
              ctx.lineWidth = 2;
              ctx.stroke();
              
              // Calcular puntos
              const points = values.map((value, index) => {
                const x = margin + (index / (pointCount - 1 || 1)) * chartWidth;
                const y = this.height - margin - (value / maxValue) * chartHeight;
                return { x, y };
              });
              
              // Dibujar línea
              ctx.beginPath();
              points.forEach((point, index) => {
                if (index === 0) {
                  ctx.moveTo(point.x, point.y);
                } else {
                  ctx.lineTo(point.x, point.y);
                }
              });
              
              ctx.strokeStyle = datasets[0]?.borderColor || '#36A2EB';
              ctx.lineWidth = datasets[0]?.borderWidth || 3;
              ctx.stroke();
              
              // Dibujar puntos
              points.forEach((point, index) => {
                ctx.beginPath();
                ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
                ctx.fillStyle = datasets[0]?.backgroundColor?.[index] || '#36A2EB';
                ctx.fill();
                ctx.strokeStyle = '#FFFFFF';
                ctx.lineWidth = 2;
                ctx.stroke();
                
                // Etiqueta de valor
                ctx.fillStyle = '#333333';
                ctx.font = '12px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(this.formatNumber(values[index]), point.x, point.y - 15);
                
                // Etiqueta del eje X
                if (labels[index]) {
                  ctx.fillStyle = '#666666';
                  ctx.font = '12px Arial';
                  ctx.textAlign = 'center';
                  ctx.fillText(labels[index], point.x, this.height - margin + 20);
                }
              });
              
              // Título
              if (options.plugins?.title?.text) {
                ctx.fillStyle = '#333333';
                ctx.font = 'bold 16px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(options.plugins.title.text, this.width / 2, 20);
              }
            }
            
            drawLegend(ctx, labels, colors) {
              const legendX = this.width - 150;
              const legendY = 40;
              const itemHeight = 20;
              
              labels.forEach((label, index) => {
                const y = legendY + index * itemHeight;
                
                // Color box
                ctx.fillStyle = colors[index % colors.length];
                ctx.fillRect(legendX, y, 15, 15);
                ctx.strokeStyle = '#FFFFFF';
                ctx.lineWidth = 1;
                ctx.strokeRect(legendX, y, 15, 15);
                
                // Texto
                ctx.fillStyle = '#333333';
                ctx.font = '12px Arial';
                ctx.textAlign = 'left';
                ctx.textBaseline = 'middle';
                const displayLabel = label.length > 15 ? label.substring(0, 15) + '...' : label;
                ctx.fillText(displayLabel, legendX + 20, y + 7.5);
              });
            }
            
            drawNoDataMessage(ctx) {
              ctx.fillStyle = '#666666';
              ctx.font = '16px Arial';
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText('No hay datos para mostrar', this.width / 2, this.height / 2);
            }
            
            formatNumber(num) {
              if (num >= 1000000) {
                return (num / 1000000).toFixed(1) + 'M';
              }
              if (num >= 1000) {
                return (num / 1000).toFixed(1) + 'K';
              }
              return num.toFixed(1);
            }
            
            update() {
              this.draw();
            }
            
            destroy() {
              // Limpiar recursos
              this.ctx.clearRect(0, 0, this.width, this.height);
            }
          }
          
          // Métodos estáticos
          Chart.register = function() {};
          Chart.unregister = function() {};
          Chart.defaults = {};
          Chart.overrides = {};
          Chart.version = '4.4.1';
          
          // Exportar
          window.Chart.Chart = ChartInstance;
        })();
        JS
      end
      
      ##
      # JavaScript para el visualizador 2D
      #
      def get_2d_viewer_javascript
        <<-JS
        // ==========================================================================
        // MATERIAL VIEWER 2D - Visualizador de secciones transversales
        // ==========================================================================
        
        let materialViewer2D = {
          canvas: null,
          ctx: null,
          data: null,
          scale: 1.0,
          offsetX: 0,
          offsetY: 0,
          
          init: function() {
            this.canvas = document.getElementById('material-viewer-2d-canvas');
            if (!this.canvas) return;
            
            this.ctx = this.canvas.getContext('2d');
            this.setupEventListeners();
            console.log('Material Viewer 2D inicializado');
          },
          
          setupEventListeners: function() {
            // Eventos de zoom con rueda del mouse
            this.canvas.addEventListener('wheel', function(e) {
              e.preventDefault();
              var delta = e.deltaY > 0 ? 0.8 : 1.2;
              materialViewer2D.zoom(delta);
            });
          },
          
          update: function(data) {
            this.data = data;
            
            if (!this.canvas || !this.ctx) {
              console.error('Material Viewer 2D no está inicializado');
              return;
            }
            
            // Mostrar el contenedor si hay datos
            if (data.materials && data.materials.length > 0) {
              document.getElementById('material-viewer-2d-container').style.display = 'block';
              this.updateInfoPanel(data);
              this.draw();
            } else {
              document.getElementById('material-viewer-2d-container').style.display = 'none';
            }
          },
          
          updateInfoPanel: function(data) {
            var infoDiv = document.getElementById('material-viewer-info');
            if (!infoDiv) return;
            
            if (data.materials && data.materials.length > 0) {
              var html = '<div class="material-list">';
              html += '<h6 style="margin-top:0; font-size:12px;">' + 
                      sketchupStrings.materials_found + ': ' + data.materials.length + '</h6>';
              
              data.materials.slice(0, 4).forEach(function(material, index) {
                html += '<div style="margin-bottom:4px; padding:3px; border-left:3px solid ' + material.color + ';">';
                html += '<strong style="font-size:11px;">' + material.name + '</strong><br>';
                html += '<small style="font-size:10px;">' + 
                        sketchupStrings.volume + ': ' + material.volume.toFixed(2) + ' m³</small>';
                html += '</div>';
              });
              
              if (data.materials.length > 4) {
                html += '<small style="color:#666; font-size:10px;">+' + 
                        (data.materials.length - 4) + ' ' + sketchupStrings.more_materials + '</small>';
              }
              
              html += '</div>';
              infoDiv.innerHTML = html;
            }
          },
          
          draw: function() {
            if (!this.ctx || !this.data || !this.data.materials) return;
            
            var ctx = this.ctx;
            var canvas = this.canvas;
            
            // Limpiar canvas
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            // Dibujar fondo
            ctx.fillStyle = '#f8f9fa';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Si no hay materiales, mostrar mensaje
            if (this.data.materials.length === 0) {
              ctx.fillStyle = '#666';
              ctx.font = '12px Arial';
              ctx.textAlign = 'center';
              ctx.fillText(sketchupStrings.no_data_to_display, canvas.width/2, canvas.height/2);
              return;
            }
            
            // Calcular volumen total para proporciones
            var totalVolume = this.data.materials.reduce(function(sum, mat) {
              return sum + (mat.volume || 0);
            }, 0);
            
            if (totalVolume > 0) {
              // Dibujar barra de proporciones
              var x = 10;
              var y = 30;
              var barWidth = canvas.width - 20;
              var barHeight = 20;
              var currentX = x;
              
              this.data.materials.slice(0, 8).forEach(function(material, index) {
                var proportion = material.volume / totalVolume;
                var segmentWidth = barWidth * proportion;
                
                // Color del material
                ctx.fillStyle = material.color;
                ctx.fillRect(currentX, y, segmentWidth, barHeight);
                
                // Borde
                ctx.strokeStyle = '#333';
                ctx.lineWidth = 1;
                ctx.strokeRect(currentX, y, segmentWidth, barHeight);
                
                // Etiqueta para segmentos grandes
                if (segmentWidth > 40) {
                  ctx.fillStyle = '#fff';
                  ctx.font = '9px Arial';
                  ctx.textAlign = 'center';
                  var text = material.name.substring(0, Math.floor(segmentWidth / 8));
                  if (material.name.length > text.length) text += '...';
                  ctx.fillText(text, currentX + segmentWidth/2, y + barHeight/2 + 3);
                }
                
                currentX += segmentWidth;
              });
              
              // Leyenda
              var legendY = y + barHeight + 15;
              var legendX = x;
              
              this.data.materials.slice(0, 5).forEach(function(material, index) {
                if (legendY < canvas.height - 20) {
                  // Cuadro de color
                  ctx.fillStyle = material.color;
                  ctx.fillRect(legendX, legendY, 10, 10);
                  ctx.strokeStyle = '#333';
                  ctx.strokeRect(legendX, legendY, 10, 10);
                  
                  // Nombre
                  ctx.fillStyle = '#333';
                  ctx.font = '9px Arial';
                  ctx.textAlign = 'left';
                  var text = material.name.substring(0, 15);
                  if (material.name.length > 15) text += '...';
                  ctx.fillText(text, legendX + 14, legendY + 8);
                  
                  legendY += 14;
                }
              });
            }
            
            // Título
            ctx.fillStyle = '#333';
            ctx.font = 'bold 11px Arial';
            ctx.textAlign = 'left';
            ctx.fillText(sketchupStrings.material_distribution, 10, 20);
            
            // Escala
            ctx.fillStyle = '#666';
            ctx.font = '8px Arial';
            ctx.textAlign = 'right';
            ctx.fillText('Scale: ' + materialViewer2D.scale.toFixed(1) + 'x', canvas.width - 5, canvas.height - 5);
          },
          
          zoom: function(factor) {
            this.scale *= factor;
            this.scale = Math.max(0.5, Math.min(this.scale, 5.0));
            this.draw();
          },
          
          resetView: function() {
            this.scale = 1.0;
            this.offsetX = 0;
            this.offsetY = 0;
            this.draw();
          }
        };
        
        // Funciones globales para el visualizador 2D
        window.initMaterialViewer2D = function() {
          return materialViewer2D.init();
        };
        
        window.updateMaterialViewer2D = function(data) {
          return materialViewer2D.update(data);
        };
        
        function toggle2DViewer() {
          var container = document.getElementById('material-viewer-2d-container');
          if (container.style.display === 'none') {
            container.style.display = 'block';
            // Actualizar con datos actuales si existen
            if (currentData) {
              updateMaterialViewer2D(currentData);
            }
          } else {
            container.style.display = 'none';
          }
        }
        
        function zoom2DViewer(factor) {
          if (materialViewer2D) {
            materialViewer2D.zoom(factor);
          }
        }
        
        function reset2DViewer() {
          if (materialViewer2D) {
            materialViewer2D.resetView();
          }
        }
        
        // Inicializar cuando el DOM esté listo
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', function() {
            materialViewer2D.init();
          });
        } else {
          materialViewer2D.init();
        }
        JS
      end
      
      ##
      # JavaScript principal - CON FUNCIONES COMPLETAS
      #
      def get_javascript_code(lang, unit, display_currency, base_currency, rates)
        <<-JAVASCRIPT
        // Variables globales
        let mainChart = null;
        let currentData = null;
        let currentDisplayCurrency = '#{display_currency}';
        let currentBaseCurrency = '#{base_currency}';
        let exchangeRates = #{rates.to_json};
        let sketchupStrings = #{IQuant::Data::Localization::STRINGS[lang].to_json};
        
        const CURRENCIES = #{IQuant::Data::CURRENCIES.to_json};
        const DOSAGE_LIBRARY = #{IQuant::Data::DOSAGE_LIBRARY.to_json};
        
        #{get_core_javascript_functions}
        #{get_ui_javascript_functions}
        #{get_chart_javascript_functions}
        
        // Inicialización
        document.addEventListener('DOMContentLoaded', function() {
          console.log('iQuant v#{IQuant::PLUGIN_VERSION} cargado');
          
          // Inicializar componentes
          initMaterialViewer2D();
          
          // Cargar datos iniciales
          setTimeout(function() {
            sketchupAction('get_data');
            sketchupAction('list_rules');
            sketchupAction('refresh');
            sketchupAction('load_currency_config');
            
            // Configurar event listeners
            setupEventListeners();
            
            // Ocultar spinner de carga
            hideLoadingSpinner();
          }, 500);
        });
        JAVASCRIPT
      end
      
      ##
      # Funciones JavaScript core - COMPLETAMENTE IMPLEMENTADAS
      #
      def get_core_javascript_functions
        <<-JS
        // Función para cambiar de pestaña
        function switchTab(tabName) {
          // Ocultar todas las pestañas
          document.querySelectorAll('.tab-content').forEach(tab => {
            tab.style.display = 'none';
            tab.classList.remove('active');
          });
          
          // Desactivar todos los botones de pestaña
          document.querySelectorAll('.tab').forEach(tab => {
            tab.classList.remove('active');
          });
          
          // Mostrar la pestaña seleccionada
          const tabContent = document.getElementById('tab-' + tabName);
          if (tabContent) {
            tabContent.style.display = 'block';
            tabContent.classList.add('active');
          }
          
          // Activar el botón de pestaña correspondiente
          const tabs = document.querySelectorAll('.tab');
          const tabNames = ['report', 'rules', 'charts', 'currency', 'help', 'settings'];
          const index = tabNames.indexOf(tabName);
          if (index >= 0 && tabs[index]) {
            tabs[index].classList.add('active');
          }
          
          // Actualizar gráficos si es necesario
          if (tabName === 'charts' && currentData) {
            updateCharts(currentData);
          }
        }
        
        // Mostrar spinner de carga
        function showLoadingSpinner() {
          const spinner = document.getElementById('loading-spinner');
          if (spinner) {
            spinner.style.display = 'flex';
            spinner.style.opacity = '1';
          }
        }
        
        // Ocultar spinner de carga
        function hideLoadingSpinner() {
          const spinner = document.getElementById('loading-spinner');
          if (spinner) {
            spinner.style.opacity = '0';
            setTimeout(() => {
              spinner.style.display = 'none';
            }, 300);
          }
        }
        
        // Comunicación principal con SketchUp
        function sketchupAction(actionName, params = '') {
          showLoadingSpinner();
          try {
            // Codificar parámetros para URL
            const encodedParams = encodeURIComponent(params);
            const url = 'skp:' + actionName + (params ? '@' + encodedParams : '');
            
            // Usar bridge de SketchUp
            if (window.location && window.location.href) {
              const iframe = document.createElement('iframe');
              iframe.style.display = 'none';
              iframe.src = url;
              document.body.appendChild(iframe);
              
              setTimeout(() => {
                document.body.removeChild(iframe);
              }, 100);
            }
            
            console.log('Llamando a SketchUp:', actionName, params);
          } catch(e) {
            console.error('Error en comunicación con SketchUp:', e);
            showMessage('general-message', 'Error de comunicación con SketchUp: ' + e.message, 'error');
          } finally {
            setTimeout(hideLoadingSpinner, 300);
          }
        }
        
        // Mostrar mensajes en la interfaz
        function showMessage(elementId, message, type = 'info') {
          const element = document.getElementById(elementId);
          if (!element) {
            console.warn('Elemento no encontrado:', elementId);
            return;
          }
          
          const icon = {
            'error': '❌',
            'warning': '⚠️',
            'info': 'ℹ️',
            'success': '✅'
          }[type] || 'ℹ️';
          
          const className = `alert alert-${type}`;
          
          element.innerHTML = \`
            <div class="\${className}" style="display: flex; align-items: center; gap: 10px; padding: 12px; border-radius: 6px;">
              <span style="font-size: 20px;">\${icon}</span>
              <div style="flex: 1;">\${message}</div>
            </div>
          \`;
          
          element.style.display = 'block';
          
          // Auto-ocultar después de 5 segundos (excepto errores)
          if (type !== 'error') {
            setTimeout(() => {
              element.style.opacity = '0';
              setTimeout(() => {
                element.innerHTML = '';
                element.style.display = 'none';
                element.style.opacity = '1';
              }, 300);
            }, 5000);
          }
        }
        
        // Formatear número con separadores de miles
        function formatNumber(num, decimals = 2) {
          if (isNaN(num)) return '0.00';
          return num.toFixed(decimals).replace(/\\B(?=(\\d{3})+(?!\\d))/g, ',');
        }
        
        // Formatear moneda
        function formatCurrency(amount, currencyCode) {
          const currency = CURRENCIES[currencyCode];
          const symbol = currency ? currency.symbol : currencyCode;
          return symbol + ' ' + formatNumber(amount);
        }
        
        // Convertir entre monedas
        function convertCurrencyAmount(amount, fromCurrency, toCurrency) {
          if (fromCurrency === toCurrency) return amount;
          
          // Si es la moneda base, usar tasas directas
          if (fromCurrency === currentBaseCurrency) {
            const rate = exchangeRates[toCurrency];
            return rate ? amount * rate : amount;
          }
          
          // Si es a la moneda base, usar inverso
          if (toCurrency === currentBaseCurrency) {
            const rate = exchangeRates[fromCurrency];
            return rate ? amount / rate : amount;
          }
          
          // Conversión cruzada
          const fromRate = exchangeRates[fromCurrency];
          const toRate = exchangeRates[toCurrency];
          
          if (fromRate && toRate) {
            return amount * (toRate / fromRate);
          }
          
          return amount;
        }
        JS
      end
      
      ##
      # Funciones JavaScript de UI - COMPLETAMENTE IMPLEMENTADAS
      #
      def get_ui_javascript_functions
        <<-JS
        // Cambiar idioma
        function changeLanguage(lang) {
          sketchupAction('change_language', lang);
        }
        
        // Cambiar unidad
        function changeUnit(unit) {
          sketchupAction('change_unit', unit);
        }
        
        // Cambiar moneda de visualización
        function changeCurrency(currency) {
          currentDisplayCurrency = currency;
          updateAllPrices();
          sketchupAction('change_display_currency', currency);
        }
        
        // Actualizar todos los precios en la interfaz
        function updateAllPrices() {
          // Actualizar etiqueta de moneda actual
          const currencyLabel = document.getElementById('current-display-currency');
          if (currencyLabel) {
            currencyLabel.textContent = currentDisplayCurrency;
          }
          
          // Si hay datos actuales, actualizar reporte
          if (currentData) {
            updateReport(currentData);
          }
          
          // Actualizar gráficos si existen
          if (mainChart) {
            updateCharts(currentData);
          }
        }
        
        // Guardar tasas de cambio
        function saveExchangeRates() {
          const usdRate = parseFloat(document.getElementById('rate-to-usd').value);
          const eurRate = parseFloat(document.getElementById('rate-to-eur').value);
          
          if (isNaN(usdRate) || isNaN(eurRate) || usdRate <= 0 || eurRate <= 0) {
            showMessage('currency-message', 'Por favor ingrese tasas válidas (números mayores a 0)', 'error');
            return;
          }
          
          const params = encodeURIComponent(usdRate) + '@' + encodeURIComponent(eurRate);
          sketchupAction('save_rates', params);
        }
        
        // Cargar tasas guardadas
        function loadExchangeRates() {
          sketchupAction('get_saved_rates', currentBaseCurrency);
        }
        
        // Obtener tasas online (simulado)
        function fetchOnlineRates() {
          showMessage('currency-message', 'Buscando tasas actualizadas...', 'info');
          
          // Simulación de llamada a API
          setTimeout(() => {
            // Tasas de ejemplo (simuladas)
            const usdRate = 1.0;
            const eurRate = 0.85;
            
            document.getElementById('rate-to-usd').value = usdRate;
            document.getElementById('rate-to-eur').value = eurRate;
            
            showMessage('currency-message', 'Tasas actualizadas desde servicio online', 'success');
          }, 1500);
        }
        
        // Guardar configuración
        function saveSettings() {
          const project = document.getElementById('project-name').value;
          const client = document.getElementById('client-name').value;
          const company = document.getElementById('company-name').value;
          
          const params = encodeURIComponent(project) + '@' + 
                        encodeURIComponent(client) + '@' + 
                        encodeURIComponent(company);
          
          sketchupAction('save_settings', params);
        }
        
        // Guardar regla de costo
        function saveRule() {
          const targetSelect = document.getElementById('rule-target');
          const target = targetSelect.value === 'custom' 
            ? document.getElementById('rule-target-custom').value
            : targetSelect.value;
          
          if (!target || target.trim() === '') {
            showMessage('rule-message', 'Por favor seleccione o ingrese un objetivo', 'error');
            return;
          }
          
          const type = document.getElementById('rule-type').value;
          const value = parseFloat(document.getElementById('rule-value').value);
          
          if (isNaN(value) || value <= 0) {
            showMessage('rule-message', 'Por favor ingrese un valor de costo válido', 'error');
            return;
          }
          
          const description = document.getElementById('rule-description').value;
          const scope = document.querySelector('input[name="rule-scope"]:checked').value;
          
          const extra = {
            description: description,
            scope: scope,
            created: new Date().toISOString()
          };
          
          // Si es material, añadir material
          if (targetSelect.value === 'material') {
            const material = document.getElementById('rule-material').value;
            if (material) {
              extra.material = material;
            }
          }
          
          const params = encodeURIComponent(target) + '@cost_rules@' + 
                        encodeURIComponent(type) + '@' + 
                        encodeURIComponent(value) + '@' + 
                        encodeURIComponent(JSON.stringify(extra));
          
          sketchupAction('save_rule', params);
        }
        
        // Actualizar formulario de regla según selección
        function updateRuleTarget() {
          const target = document.getElementById('rule-target').value;
          const customGroup = document.getElementById('custom-target-group');
          const materialGroup = document.getElementById('material-selection-group');
          
          if (target === 'custom') {
            customGroup.style.display = 'block';
            materialGroup.style.display = 'none';
          } else if (target === 'material') {
            customGroup.style.display = 'none';
            materialGroup.style.display = 'block';
          } else {
            customGroup.style.display = 'none';
            materialGroup.style.display = 'none';
          }
        }
        
        // Actualizar formulario de regla según tipo
        function updateRuleForm() {
          const type = document.getElementById('rule-type').value;
          const valueInput = document.getElementById('rule-value');
          
          // Actualizar placeholder según tipo
          const placeholders = {
            'vol': 'Costo por m³ (ej: 150.00)',
            'area': 'Costo por m² (ej: 25.00)',
            'len': 'Costo por m (ej: 10.00)',
            'unit': 'Costo por unidad (ej: 100.00)',
            'fixed': 'Costo fijo (ej: 500.00)'
          };
          
          valueInput.placeholder = placeholders[type] || 'Costo';
        }
        
        // Reiniciar formulario de regla
        function resetRuleForm() {
          document.getElementById('rule-target').value = '';
          document.getElementById('rule-target-custom').value = '';
          document.getElementById('rule-type').value = 'vol';
          document.getElementById('rule-value').value = '';
          document.getElementById('rule-description').value = '';
          document.getElementById('rule-material').value = '';
          document.querySelector('input[name="rule-scope"][value="all"]').checked = true;
          
          document.getElementById('custom-target-group').style.display = 'none';
          document.getElementById('material-selection-group').style.display = 'none';
          
          updateRuleForm();
        }
        
        // Eliminar todas las reglas
        function deleteAllRules() {
          if (confirm('¿Está seguro de que desea eliminar TODAS las reglas de costo? Esta acción no se puede deshacer.')) {
            // Aquí se implementaría la eliminación de todas las reglas
            showMessage('rule-message', 'Funcionalidad de eliminación masiva en desarrollo', 'info');
          }
        }
        
        // Configurar event listeners
        function setupEventListeners() {
          // Selector de idioma
          const langSelector = document.getElementById('language-selector');
          if (langSelector) {
            langSelector.addEventListener('change', function() {
              changeLanguage(this.value);
            });
          }
          
          // Selector de unidad
          const unitSelector = document.getElementById('unit-selector');
          if (unitSelector) {
            unitSelector.addEventListener('change', function() {
              changeUnit(this.value);
            });
          }
          
          // Selector de moneda
          const currencySelector = document.getElementById('currency-selector');
          if (currencySelector) {
            currencySelector.addEventListener('change', function() {
              changeCurrency(this.value);
            });
          }
          
          // Botón de guardar tasas
          const saveRatesBtn = document.querySelector('[onclick="saveExchangeRates()"]');
          if (saveRatesBtn) {
            saveRatesBtn.addEventListener('click', saveExchangeRates);
          }
          
          // Botón de guardar configuración
          const saveSettingsBtn = document.querySelector('[onclick="saveSettings()"]');
          if (saveSettingsBtn) {
            saveSettingsBtn.addEventListener('click', saveSettings);
          }
          
          // Inicializar formulario de regla
          updateRuleTarget();
          updateRuleForm();
        }
        
        // Convertir moneda en el convertidor
        function convertCurrency() {
          const amount = parseFloat(document.getElementById('convert-amount').value);
          const from = document.getElementById('convert-from').value;
          const to = document.getElementById('convert-to').value;
          
          if (isNaN(amount) || amount <= 0) {
            showMessage('currency-message', 'Por favor ingrese un monto válido', 'error');
            return;
          }
          
          const converted = convertCurrencyAmount(amount, from, to);
          
          const resultDiv = document.getElementById('conversion-result');
          const amountSpan = document.getElementById('converted-amount');
          
          if (resultDiv && amountSpan) {
            amountSpan.textContent = \`\${formatCurrency(converted, to)}\`;
            resultDiv.style.display = 'block';
          }
        }
        JS
      end
      
      ##
      # Funciones JavaScript de gráficos - COMPLETAMENTE IMPLEMENTADAS
      #
      def get_chart_javascript_functions
        <<-JS
        // Actualizar reporte con datos de SketchUp
        function updateReport(data) {
          currentData = data;
          
          const reportContent = document.getElementById('report-content');
          if (!reportContent) return;
          
          if (!data || data.count === 0) {
            reportContent.innerHTML = \`
              <div class="empty-state">
                <div style="font-size: 48px; color: var(--text-secondary); margin-bottom: 16px;">📏</div>
                <h3>\${sketchupStrings.no_objects_selected}</h3>
                <p>\${sketchupStrings.select_objects_in_sketchup}</p>
              </div>
            \`;
            return;
          }
          
          // Calcular total en moneda de visualización
          const totalCost = convertCurrencyAmount(data.total_cost || 0, currentBaseCurrency, currentDisplayCurrency);
          
          let html = \`
            <div class="report-summary">
              <div class="summary-item">
                <div class="summary-label">\${sketchupStrings.objects_count}</div>
                <div class="summary-value">\${data.count}</div>
              </div>
              <div class="summary-item">
                <div class="summary-label">\${sketchupStrings.total_area}</div>
                <div class="summary-value">\${formatNumber(data.total_area || 0)} m²</div>
              </div>
              <div class="summary-item">
                <div class="summary-label">\${sketchupStrings.total_volume}</div>
                <div class="summary-value">\${formatNumber(data.total_volume || 0)} m³</div>
              </div>
              <div class="summary-item highlight">
                <div class="summary-label">\${sketchupStrings.total_cost}</div>
                <div class="summary-value">\${formatCurrency(totalCost, currentDisplayCurrency)}</div>
              </div>
            </div>
          \`;
          
          // Si hay categorías, mostrar desglose
          if (data.categories && data.categories.length > 0) {
            html += \`
              <h4 style="margin-top: 24px;">\${sketchupStrings.breakdown_by_category}</h4>
              <div class="category-list">
            \`;
            
            data.categories.forEach(category => {
              const catCost = convertCurrencyAmount(category.cost || 0, currentBaseCurrency, currentDisplayCurrency);
              const percentage = data.total_cost > 0 ? ((category.cost / data.total_cost) * 100).toFixed(1) : '0.0';
              
              html += \`
                <div class="category-item">
                  <div class="category-name">\${category.name || 'Sin categoría'}</div>
                  <div class="category-stats">
                    <span class="category-count">\${category.count} items</span>
                    <span class="category-cost">\${formatCurrency(catCost, currentDisplayCurrency)}</span>
                    <span class="category-percentage">(\${percentage}%)</span>
                  </div>
                  <div class="category-bar">
                    <div class="bar-fill" style="width: \${percentage}%;"></div>
                  </div>
                </div>
              \`;
            });
            
            html += \`</div>\`;
          }
          
          // Si hay materiales, mostrar desglose
          if (data.materials && data.materials.length > 0) {
            html += \`
              <h4 style="margin-top: 24px;">\${sketchupStrings.breakdown_by_material}</h4>
              <div id="material-breakdown-content">
            \`;
            
            data.materials.slice(0, 10).forEach(material => {
              const matCost = convertCurrencyAmount(material.cost || 0, currentBaseCurrency, currentDisplayCurrency);
              
              html += \`
                <div class="material-item">
                  <div class="material-name">
                    <span class="material-color" style="background-color: \${material.color || '#36A2EB'};"></span>
                    \${material.name || 'Material desconocido'}
                  </div>
                  <div class="material-stats">
                    <span class="material-volume">\${formatNumber(material.volume || 0)} m³</span>
                    <span class="material-cost">\${formatCurrency(matCost, currentDisplayCurrency)}</span>
                  </div>
                </div>
              \`;
            });
            
            if (data.materials.length > 10) {
              html += \`
                <div style="text-align: center; margin-top: 12px; color: var(--text-secondary);">
                  + \${data.materials.length - 10} \${sketchupStrings.more_materials}
                </div>
              \`;
            }
            
            html += \`</div>\`;
            document.getElementById('material-details').style.display = 'block';
          }
          
          reportContent.innerHTML = html;
          
          // Actualizar gráficos
          updateCharts(data);
          
          // Actualizar visualizador 2D si está disponible
          if (window.updateMaterialViewer2D) {
            updateMaterialViewer2D(data);
          }
        }
        
        // Actualizar gráficos con datos
        function updateCharts(data) {
          if (!data || !document.getElementById('tab-charts').classList.contains('active')) {
            return;
          }
          
          const chartType = document.getElementById('chart-type').value;
          const dataSource = document.getElementById('chart-data').value;
          const chartCurrency = document.getElementById('chart-currency').value;
          
          let labels = [];
          let values = [];
          let colors = [];
          let title = '';
          
          // Preparar datos según la fuente seleccionada
          if (dataSource === 'materials' && data.materials && data.materials.length > 0) {
            title = sketchupStrings.material_distribution;
            data.materials.slice(0, 8).forEach(material => {
              labels.push(material.name || 'Material');
              const cost = convertCurrencyAmount(material.cost || 0, currentBaseCurrency, chartCurrency);
              values.push(cost);
              colors.push(material.color || getRandomColor());
            });
          } else if (dataSource === 'categories' && data.categories && data.categories.length > 0) {
            title = sketchupStrings.category_distribution;
            data.categories.forEach(category => {
              labels.push(category.name || 'Categoría');
              const cost = convertCurrencyAmount(category.cost || 0, currentBaseCurrency, chartCurrency);
              values.push(cost);
              colors.push(getCategoryColor(category.name));
            });
          } else {
            // Datos por defecto
            title = sketchupStrings.no_chart_data;
            labels = ['Sin datos'];
            values = [1];
            colors = ['#CCCCCC'];
          }
          
          // Crear o actualizar gráfico
          const ctx = document.getElementById('main-chart').getContext('2d');
          
          if (mainChart) {
            mainChart.destroy();
          }
          
          mainChart = new Chart(ctx, {
            type: chartType,
            data: {
              labels: labels,
              datasets: [{
                data: values,
                backgroundColor: colors,
                borderColor: '#FFFFFF',
                borderWidth: 2
              }]
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                title: {
                  display: true,
                  text: title + ' (' + chartCurrency + ')',
                  font: {
                    size: 16,
                    weight: 'bold'
                  }
                },
                legend: {
                  display: chartType !== 'bar',
                  position: 'right'
                }
              }
            }
          });
          
          // Actualizar análisis del gráfico
          updateChartAnalysis(labels, values, chartCurrency);
        }
        
        // Actualizar tipo de gráfico
        function updateChartType() {
          if (currentData) {
            updateCharts(currentData);
          }
        }
        
        // Actualizar fuente de datos del gráfico
        function updateChartData() {
          if (currentData) {
            updateCharts(currentData);
          }
        }
        
        // Actualizar moneda del gráfico
        function updateChartCurrency() {
          if (currentData) {
            updateCharts(currentData);
          }
        }
        
        // Actualizar análisis del gráfico
        function updateChartAnalysis(labels, values, currency) {
          const analysisContent = document.getElementById('chart-analysis-content');
          if (!analysisContent) return;
          
          if (values.length === 0 || (values.length === 1 && values[0] === 0)) {
            analysisContent.innerHTML = \`
              <p style="color: var(--text-secondary); font-style: italic;">
                \${sketchupStrings.no_chart_data_yet}
              </p>
            \`;
            return;
          }
          
          const total = values.reduce((a, b) => a + b, 0);
          const maxValue = Math.max(...values);
          const maxIndex = values.indexOf(maxValue);
          const maxLabel = labels[maxIndex] || 'N/A';
          
          let html = \`
            <div class="analysis-stats">
              <div class="stat-item">
                <div class="stat-label">\${sketchupStrings.total_value}:</div>
                <div class="stat-value">\${formatCurrency(total, currency)}</div>
              </div>
              <div class="stat-item">
                <div class="stat-label">\${sketchupStrings.highest_value}:</div>
                <div class="stat-value">\${formatCurrency(maxValue, currency)}</div>
              </div>
              <div class="stat-item">
                <div class="stat-label">\${sketchupStrings.highest_category}:</div>
                <div class="stat-value">\${maxLabel}</div>
              </div>
            </div>
          \`;
          
          // Top 3 categorías
          if (values.length > 1) {
            const sortedIndices = values.map((val, idx) => ({val, idx}))
              .sort((a, b) => b.val - a.val)
              .slice(0, 3);
            
            html += \`
              <div class="top-categories" style="margin-top: 16px;">
                <h6 style="margin: 0 0 8px 0;">\${sketchupStrings.top_categories}:</h6>
                <ol style="margin: 0; padding-left: 20px;">
            \`;
            
            sortedIndices.forEach((item, index) => {
              const percentage = total > 0 ? ((item.val / total) * 100).toFixed(1) : '0.0';
              html += \`
                <li>
                  <strong>\${labels[item.idx]}</strong>: 
                  \${formatCurrency(item.val, currency)} (\${percentage}%)
                </li>
              \`;
            });
            
            html += \`</ol></div>\`;
          }
          
          analysisContent.innerHTML = html;
        }
        
        // Obtener color para categoría
        function getCategoryColor(categoryName) {
          const colorMap = {
            'wall': '#FF6384',
            'slab': '#36A2EB',
            'floor': '#FFCE56',
            'roof': '#4BC0C0',
            'beam': '#9966FF',
            'column': '#FF9F40',
            'door': '#8AC926',
            'window': '#1982C4'
          };
          
          return colorMap[categoryName.toLowerCase()] || getRandomColor();
        }
        
        // Generar color aleatorio
        function getRandomColor() {
          const colors = [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0',
            '#9966FF', '#FF9F40', '#8AC926', '#1982C4',
            '#6A4C93', '#F15BB5', '#00BBF9', '#00F5D4'
          ];
          return colors[Math.floor(Math.random() * colors.length)];
        }
        
        // Actualizar agrupamiento
        function updateGrouping() {
          const grouping = document.getElementById('group-by').value;
          // Aquí se implementaría la lógica de agrupamiento
          console.log('Agrupamiento cambiado a:', grouping);
          if (currentData) {
            updateReport(currentData);
          }
        }
        
        // Mostrar ayuda de instalación de gemas
        function showGemInstallHelp() {
          const helpContent = \`
            <h3>📦 Instalación de Gemas de Ruby</h3>
            <p>Para exportar a PDF y Excel necesitas instalar estas gemas:</p>
            
            <div class="gem-install-steps">
              <h4>1. Abre Terminal (macOS/Linux) o CMD/PowerShell (Windows)</h4>
              
              <h4>2. Ejecuta estos comandos:</h4>
              <pre style="background: #f5f5f5; padding: 12px; border-radius: 4px; overflow-x: auto;">
# Instalar gema Prawn para PDF
gem install prawn prawn-table

# Instalar gema WriteXLSX para Excel
gem install write_xlsx
              </pre>
              
              <h4>3. Reinicia SketchUp</h4>
              <p>Después de instalar las gemas, reinicia SketchUp para que los cambios tengan efecto.</p>
              
              <h4>4. Verifica la instalación</h4>
              <p>Vuelve a esta pestaña de Ayuda. Los badges deben mostrar ✅ en lugar de ⚠️.</p>
            </div>
            
            <div class="troubleshooting">
              <h4>❌ Si tienes problemas:</h4>
              <ul>
                <li><strong>Permisos denegados:</strong> Usa <code>sudo gem install ...</code> en macOS/Linux</li>
                <li><strong>Ruby no encontrado:</strong> Asegúrate de tener Ruby instalado</li>
                <li><strong>SketchUp no detecta las gemas:</strong> Instálalas en el Ruby de SketchUp</li>
              </ul>
            </div>
          \`;
          
          showMessage('help-message', helpContent, 'info');
        }
        JS
      end
      
    end
  end
end
