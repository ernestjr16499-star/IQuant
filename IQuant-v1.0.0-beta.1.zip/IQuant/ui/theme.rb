# encoding: UTF-8

module IQuant
  module UI
    module Theme
      extend self
      
      ##
      # Genera el CSS completo del tema
      #
      # @param mode [Symbol] :light o :dark
      # @return [String] CSS completo
      #
      def get_css(mode = :light)
        <<-CSS
        #{get_variables(mode)}
        #{get_reset}
        #{get_typography}
        #{get_layout}
        #{get_header}
        #{get_tabs}
        #{get_buttons}
        #{get_cards}
        #{get_forms}
        #{get_tables}
        #{get_messages}
        #{get_alerts}
        #{get_badges}
        #{get_charts}
        #{get_dialogs}
        #{get_animations}
        #{get_utilities}
        #{get_components}
        #{get_license_styles}
        CSS
      end
      
      private
      
      ##
      # Variables CSS según el modo (claro/oscuro)
      #
      def get_variables(mode)
        colors = mode == :light ? light_colors : dark_colors
        
        <<-CSS
        :root {
          /* ============================================
             COLORES - Inspirado en Grok/X/Linear
             ============================================ */
          #{colors}
          
          /* ============================================
             TIPOGRAFÍA - System Fonts
             ============================================ */
          --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, 
                         "Helvetica Neue", Arial, sans-serif;
          --font-family-mono: "SF Mono", Monaco, "Cascadia Code", "Roboto Mono", 
                              Consolas, "Courier New", monospace;
          
          --font-size-xs: 11px;
          --font-size-sm: 13px;
          --font-size-base: 15px;
          --font-size-lg: 17px;
          --font-size-xl: 20px;
          --font-size-2xl: 24px;
          --font-size-3xl: 30px;
          
          --font-weight-normal: 400;
          --font-weight-medium: 500;
          --font-weight-semibold: 600;
          --font-weight-bold: 700;
          
          --line-height-tight: 1.25;
          --line-height-normal: 1.5;
          --line-height-relaxed: 1.75;
          
          /* ============================================
             ESPACIADO - 8px Grid System
             ============================================ */
          --space-0: 0;
          --space-1: 4px;
          --space-2: 8px;
          --space-3: 12px;
          --space-4: 16px;
          --space-5: 20px;
          --space-6: 24px;
          --space-8: 32px;
          --space-10: 40px;
          --space-12: 48px;
          --space-16: 64px;
          
          /* ============================================
             BORDER RADIUS
             ============================================ */
          --radius-none: 0;
          --radius-sm: 4px;
          --radius-md: 8px;
          --radius-lg: 12px;
          --radius-xl: 16px;
          --radius-full: 9999px;
          
          /* ============================================
             SOMBRAS - Sutiles y modernas
             ============================================ */
          --shadow-xs: 0 1px 2px rgba(0, 0, 0, 0.05);
          --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
          --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.1);
          --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
          --shadow-xl: 0 20px 25px rgba(0, 0, 0, 0.15);
          
          /* ============================================
             TRANSICIONES - Cubic Bezier Suaves
             ============================================ */
          --transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1);
          --transition-base: 200ms cubic-bezier(0.4, 0, 0.2, 1);
          --transition-slow: 300ms cubic-bezier(0.4, 0, 0.2, 1);
          
          /* ============================================
             Z-INDEX
             ============================================ */
          --z-base: 1;
          --z-dropdown: 100;
          --z-sticky: 200;
          --z-overlay: 300;
          --z-modal: 400;
          --z-tooltip: 500;
        }
        CSS
      end
      
      ##
      # Colores del modo claro
      #
      def light_colors
        <<-CSS
        /* Backgrounds */
        --bg-primary: #FFFFFF;
        --bg-secondary: #F8F9FA;
        --bg-tertiary: #E9ECEF;
        --bg-hover: #F1F3F5;
        --bg-active: #E9ECEF;
        
        /* Text */
        --text-primary: #1A1A1A;
        --text-secondary: #6C757D;
        --text-tertiary: #ADB5BD;
        --text-disabled: #CED4DA;
        --text-inverse: #FFFFFF;
        
        /* Borders */
        --border-primary: #DEE2E6;
        --border-secondary: #E9ECEF;
        --border-focus: #0A84FF;
        
        /* Accent (Blue - iOS style) */
        --accent: #0A84FF;
        --accent-hover: #0077ED;
        --accent-active: #006BE0;
        --accent-subtle: rgba(10, 132, 255, 0.1);
        
        /* Semantic Colors */
        --success: #28A745;
        --success-subtle: rgba(40, 167, 69, 0.1);
        --warning: #FFC107;
        --warning-subtle: rgba(255, 193, 7, 0.1);
        --error: #DC3545;
        --error-subtle: rgba(220, 53, 69, 0.1);
        --info: #17A2B8;
        --info-subtle: rgba(23, 162, 184, 0.1);
        CSS
      end
      
      ##
      # Colores del modo oscuro
      #
      def dark_colors
        <<-CSS
        /* Backgrounds */
        --bg-primary: #000000;
        --bg-secondary: #1A1A1A;
        --bg-tertiary: #2D2D2D;
        --bg-hover: #242424;
        --bg-active: #2D2D2D;
        
        /* Text */
        --text-primary: #F5F5F5;
        --text-secondary: #AAAAAA;
        --text-tertiary: #6C6C6C;
        --text-disabled: #4D4D4D;
        --text-inverse: #000000;
        
        /* Borders */
        --border-primary: #404040;
        --border-secondary: #2D2D2D;
        --border-focus: #0A84FF;
        
        /* Accent (Blue - iOS style) */
        --accent: #0A84FF;
        --accent-hover: #409CFF;
        --accent-active: #006BE0;
        --accent-subtle: rgba(10, 132, 255, 0.15);
        
        /* Semantic Colors */
        --success: #30D158;
        --success-subtle: rgba(48, 209, 88, 0.15);
        --warning: #FFD60A;
        --warning-subtle: rgba(255, 214, 10, 0.15);
        --error: #FF453A;
        --error-subtle: rgba(255, 69, 58, 0.15);
        --info: #64D2FF;
        --info-subtle: rgba(100, 210, 255, 0.15);
        CSS
      end
      
      ##
      # Reset CSS
      #
      def get_reset
        <<-CSS
        /* ============================================
           RESET CSS
           ============================================ */
        *, *::before, *::after {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }
        
        html {
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }
        CSS
      end
      
      ##
      # Tipografía base
      #
      def get_typography
        <<-CSS
        /* ============================================
           TIPOGRAFÍA
           ============================================ */
        body {
          font-family: var(--font-family);
          font-size: var(--font-size-base);
          font-weight: var(--font-weight-normal);
          line-height: var(--line-height-normal);
          color: var(--text-primary);
          background: var(--bg-primary);
        }
        
        h1, h2, h3, h4, h5, h6 {
          font-weight: var(--font-weight-semibold);
          line-height: var(--line-height-tight);
          color: var(--text-primary);
          margin-bottom: var(--space-4);
        }
        
        h1 { font-size: var(--font-size-3xl); }
        h2 { font-size: var(--font-size-2xl); }
        h3 { font-size: var(--font-size-xl); }
        h4 { font-size: var(--font-size-lg); }
        h5 { font-size: var(--font-size-base); }
        h6 { font-size: var(--font-size-sm); }
        
        p {
          margin-bottom: var(--space-3);
          color: var(--text-secondary);
        }
        
        strong, b {
          font-weight: var(--font-weight-semibold);
        }
        
        code {
          font-family: var(--font-family-mono);
          font-size: 0.9em;
          background: var(--bg-tertiary);
          padding: 2px 6px;
          border-radius: var(--radius-sm);
        }
        
        small {
          font-size: var(--font-size-sm);
          color: var(--text-tertiary);
        }
        CSS
      end
      
      ##
      # Layout general
      #
      def get_layout
        <<-CSS
        /* ============================================
           LAYOUT
           ============================================ */
        .container {
          padding: var(--space-6);
          max-width: 1600px;
          margin: 0 auto;
        }
        
        .content {
          padding: var(--space-6);
        }
        
        .section {
          margin-bottom: var(--space-8);
        }
        
        .grid {
          display: grid;
          gap: var(--space-4);
        }
        
        .grid-cols-2 { grid-template-columns: repeat(2, 1fr); }
        .grid-cols-3 { grid-template-columns: repeat(3, 1fr); }
        .grid-cols-4 { grid-template-columns: repeat(4, 1fr); }
        
        .flex {
          display: flex;
        }
        
        .flex-col { flex-direction: column; }
        .items-center { align-items: center; }
        .justify-between { justify-content: space-between; }
        .gap-2 { gap: var(--space-2); }
        .gap-4 { gap: var(--space-4); }
        CSS
      end
      
      ##
      # Header moderno
      #
      def get_header
        <<-CSS
        /* ============================================
           HEADER - Estilo minimalista
           ============================================ */
        .header {
          background: var(--bg-primary);
          border-bottom: 1px solid var(--border-primary);
          padding: var(--space-4) var(--space-6);
          display: flex;
          justify-content: space-between;
          align-items: center;
          position: sticky;
          top: 0;
          z-index: var(--z-sticky);
          backdrop-filter: blur(10px);
          background: rgba(255, 255, 255, 0.95);
        }
        
        .header-title {
          font-size: var(--font-size-lg);
          font-weight: var(--font-weight-semibold);
          color: var(--text-primary);
          display: flex;
          align-items: center;
          gap: var(--space-3);
        }
        
        .header-badge {
          font-size: var(--font-size-xs);
          font-weight: var(--font-weight-medium);
          background: var(--accent-subtle);
          color: var(--accent);
          padding: var(--space-1) var(--space-2);
          border-radius: var(--radius-full);
        }
        
        .header-controls {
          display: flex;
          gap: var(--space-3);
          align-items: center;
        }
        
        .header-controls select {
          padding: var(--space-2) var(--space-3);
          border: 1px solid var(--border-primary);
          border-radius: var(--radius-md);
          background: var(--bg-primary);
          color: var(--text-primary);
          font-size: var(--font-size-sm);
          font-weight: var(--font-weight-medium);
          cursor: pointer;
          transition: all var(--transition-base);
        }
        
        .header-controls select:hover {
          border-color: var(--accent);
        }
        
        .header-controls select:focus {
          outline: none;
          border-color: var(--accent);
          box-shadow: 0 0 0 3px var(--accent-subtle);
        }
        CSS
      end
      
      ##
      # Tabs estilo underline (como Grok/Linear)
      #
      def get_tabs
        <<-CSS
        /* ============================================
           TABS - Underline Style (Grok/Linear)
           ============================================ */
        .tabs {
          display: flex;
          gap: var(--space-2);
          border-bottom: 1px solid var(--border-primary);
          background: transparent;
          margin-bottom: var(--space-6);
        }
        
        .tab, .tab-btn {
          padding: var(--space-3) var(--space-4);
          background: transparent;
          border: none;
          border-bottom: 2px solid transparent;
          color: var(--text-secondary);
          font-size: var(--font-size-base);
          font-weight: var(--font-weight-medium);
          cursor: pointer;
          transition: all var(--transition-base);
          margin-bottom: -1px;
          white-space: nowrap;
        }
        
        .tab:hover, .tab-btn:hover {
          color: var(--text-primary);
          background: var(--bg-hover);
        }
        
        .tab.active, .tab-btn.active {
          color: var(--accent);
          border-bottom-color: var(--accent);
        }
        
        .tab-content {
          display: none;
        }
        
        .tab-content.active {
          display: block;
          animation: fadeIn var(--transition-base);
        }
        CSS
      end
      
      ##
      # Botones flat modernos
      #
      def get_buttons
        <<-CSS
        /* ============================================
           BOTONES - Flat & Modern
           ============================================ */
        button, .btn {
          background: var(--accent);
          color: white;
          border: none;
          padding: var(--space-3) var(--space-5);
          border-radius: var(--radius-md);
          font-size: var(--font-size-base);
          font-weight: var(--font-weight-medium);
          cursor: pointer;
          transition: all var(--transition-base);
          box-shadow: var(--shadow-sm);
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: var(--space-2);
        }
        
        button:hover:not(:disabled), .btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: var(--shadow-md);
          filter: brightness(1.05);
        }
        
        button:active:not(:disabled), .btn:active:not(:disabled) {
          transform: translateY(0);
        }
        
        button:disabled, .btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
          transform: none;
          box-shadow: none;
        }
        
        /* Variantes de botones */
        .btn-primary {
          background: var(--accent);
          color: white;
        }
        
        .btn-secondary {
          background: var(--bg-tertiary);
          color: var(--text-primary);
          box-shadow: none;
        }
        
        .btn-secondary:hover:not(:disabled) {
          background: var(--bg-hover);
        }
        
        .btn-success {
          background: var(--success);
          color: white;
        }
        
        .btn-warning {
          background: var(--warning);
          color: var(--text-primary);
        }
        
        .btn-danger {
          background: var(--error);
          color: white;
        }
        
        .btn-info {
          background: var(--info);
          color: white;
        }
        
        .btn-light {
          background: var(--bg-secondary);
          color: var(--text-primary);
          box-shadow: none;
        }
        
        .btn-dark {
          background: var(--text-primary);
          color: white;
        }
        
        .btn-ghost {
          background: transparent;
          color: var(--accent);
          box-shadow: none;
        }
        
        .btn-ghost:hover:not(:disabled) {
          background: var(--accent-subtle);
        }
        
        /* Botones de exportación */
        .export-btn {
          background: linear-gradient(135deg, var(--success) 0%, var(--success) 100%);
          color: white;
          font-weight: var(--font-weight-semibold);
          border: 2px solid transparent;
        }
        
        .export-btn:hover:not(:disabled) {
          border-color: var(--success);
          background: transparent;
          color: var(--success);
        }
        
        /* Tamaños */
        .btn-sm {
          padding: var(--space-2) var(--space-3);
          font-size: var(--font-size-sm);
        }
        
        .btn-lg {
          padding: var(--space-4) var(--space-6);
          font-size: var(--font-size-lg);
        }
        
        /* Icon buttons */
        .btn-icon {
          width: 40px;
          height: 40px;
          padding: 0;
          border-radius: var(--radius-md);
        }
        CSS
      end
      
      ##
      # Cards sutiles
      #
      def get_cards
        <<-CSS
        /* ============================================
           CARDS - Elevación sutil
           ============================================ */
        .card {
          background: var(--bg-secondary);
          border: 1px solid var(--border-primary);
          border-radius: var(--radius-lg);
          padding: var(--space-6);
          box-shadow: var(--shadow-xs);
          transition: all var(--transition-base);
        }
        
        .card:hover {
          box-shadow: var(--shadow-sm);
        }
        
        .card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: var(--space-4);
          padding-bottom: var(--space-3);
          border-bottom: 1px solid var(--border-secondary);
        }
        
        .card-title {
          font-size: var(--font-size-lg);
          font-weight: var(--font-weight-semibold);
          color: var(--text-primary);
          margin: 0;
        }
        
        .card-body {
          color: var(--text-secondary);
        }
        
        .card-footer {
          margin-top: var(--space-4);
          padding-top: var(--space-3);
          border-top: 1px solid var(--border-secondary);
          display: flex;
          justify-content: flex-end;
          gap: var(--space-2);
        }
        
        /* Card colapsable */
        .collapsible-card .card-collapse-btn {
          background: none;
          border: none;
          cursor: pointer;
          padding: var(--space-1);
          transition: transform var(--transition-base);
        }
        
        .collapsible-card .card-collapse-btn[aria-expanded="true"] {
          transform: rotate(180deg);
        }
        CSS
      end
      
      ##
      # Forms modernos
      #
      def get_forms
        <<-CSS
        /* ============================================
           FORMS - Clean & Modern
           ============================================ */
        .form-group {
          margin-bottom: var(--space-5);
        }
        
        .form-group.has-error input,
        .form-group.has-error select,
        .form-group.has-error textarea {
          border-color: var(--error);
        }
        
        .form-group.has-error .invalid-feedback {
          display: block;
        }
        
        .form-select {
          width: 100%;
          padding: var(--space-3);
          border: 1px solid var(--border-primary);
          border-radius: var(--radius-md);
          background: var(--bg-primary);
          color: var(--text-primary);
          font-size: var(--font-size-base);
          font-family: var(--font-family);
          transition: all var(--transition-base);
          cursor: pointer;
        }
        
        .form-select:hover {
          border-color: var(--border-focus);
        }
        
        .form-select:focus {
          outline: none;
          border-color: var(--accent);
          box-shadow: 0 0 0 3px var(--accent-subtle);
        }
        
        .form-control {
          width: 100%;
          padding: var(--space-3);
          border: 1px solid var(--border-primary);
          border-radius: var(--radius-md);
          background: var(--bg-primary);
          color: var(--text-primary);
          font-size: var(--font-size-base);
          font-family: var(--font-family);
          transition: all var(--transition-base);
        }
        
        .form-control:hover {
          border-color: var(--border-focus);
        }
        
        .form-control:focus {
          outline: none;
          border-color: var(--accent);
          box-shadow: 0 0 0 3px var(--accent-subtle);
        }
        
        .form-control:disabled, .form-select:disabled {
          background: var(--bg-tertiary);
          cursor: not-allowed;
          opacity: 0.6;
        }
        
        .form-control[readonly] {
          background: var(--bg-tertiary);
          cursor: default;
        }
        
        .form-control.error, .form-select.error {
          border-color: var(--error);
        }
        
        .form-control.error:focus, .form-select.error:focus {
          box-shadow: 0 0 0 3px var(--error-subtle);
        }
        
        label {
          display: block;
          margin-bottom: var(--space-2);
          font-size: var(--font-size-sm);
          font-weight: var(--font-weight-medium);
          color: var(--text-primary);
        }
        
        .form-text {
          font-size: var(--font-size-sm);
          color: var(--text-tertiary);
          margin-top: var(--space-1);
        }
        
        .invalid-feedback {
          font-size: var(--font-size-sm);
          color: var(--error);
          margin-top: var(--space-1);
          display: none;
        }
        
        /* Checkboxes & Radios modernos */
        input[type="checkbox"],
        input[type="radio"] {
          width: auto;
          margin-right: var(--space-2);
          cursor: pointer;
        }
        
        /* Radio groups */
        .radio-group {
          display: flex;
          gap: var(--space-4);
        }
        
        .radio-group-vertical {
          flex-direction: column;
          gap: var(--space-2);
        }
        
        .radio-group-horizontal {
          flex-direction: row;
          gap: var(--space-4);
        }
        
        .radio-option {
          display: flex;
          align-items: center;
          gap: var(--space-2);
        }
        
        .radio-option input[type="radio"] {
          width: 18px;
          height: 18px;
        }
        
        /* Form row */
        .form-row {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: var(--space-4);
        }
        CSS
      end
      
      ##
      # Tablas limpias
      #
      def get_tables
        <<-CSS
        /* ============================================
           TABLES - Clean & Minimal
           ============================================ */
        table {
          width: 100%;
          border-collapse: collapse;
          font-size: var(--font-size-base);
        }
        
        th {
          background: transparent;
          color: var(--text-secondary);
          text-align: left;
          padding: var(--space-3);
          font-weight: var(--font-weight-semibold);
          font-size: var(--font-size-sm);
          text-transform: uppercase;
          letter-spacing: 0.5px;
          border-bottom: 2px solid var(--border-primary);
        }
        
        td {
          padding: var(--space-3);
          border-bottom: 1px solid var(--border-secondary);
          color: var(--text-primary);
        }
        
        tr:hover {
          background: var(--bg-hover);
        }
        
        tr:last-child td {
          border-bottom: none;
        }
        
        tfoot tr {
          background: var(--bg-secondary);
          font-weight: var(--font-weight-semibold);
        }
        
        tfoot td {
          border-top: 2px solid var(--border-primary);
          border-bottom: none;
        }
        CSS
      end
      
      ##
      # Mensajes y alertas
      #
      def get_messages
        <<-CSS
        /* ============================================
           MESSAGES & ALERTS
           ============================================ */
        .message {
          padding: var(--space-4);
          border-radius: var(--radius-md);
          margin-bottom: var(--space-4);
          display: flex;
          align-items: flex-start;
          gap: var(--space-3);
          font-size: var(--font-size-base);
        }
        
        .message-icon {
          font-size: var(--font-size-lg);
          flex-shrink: 0;
        }
        
        .success-message {
          background: var(--success-subtle);
          color: var(--success);
          border-left: 4px solid var(--success);
        }
        
        .error-message {
          background: var(--error-subtle);
          color: var(--error);
          border-left: 4px solid var(--error);
        }
        
        .warning-message {
          background: var(--warning-subtle);
          color: var(--warning);
          border-left: 4px solid var(--warning);
        }
        
        .info-message {
          background: var(--info-subtle);
          color: var(--info);
          border-left: 4px solid var(--info);
        }
        CSS
      end
      
      ##
      # Alertas de componentes
      #
      def get_alerts
        <<-CSS
        /* ============================================
           ALERTS - Para componentes
           ============================================ */
        .alert {
          padding: var(--space-4);
          border-radius: var(--radius-md);
          margin-bottom: var(--space-4);
          display: flex;
          align-items: flex-start;
          gap: var(--space-3);
          border: 1px solid transparent;
          position: relative;
        }
        
        .alert-icon {
          font-size: var(--font-size-lg);
          flex-shrink: 0;
        }
        
        .alert-content {
          flex: 1;
        }
        
        .alert.alert-info {
          background: var(--info-subtle);
          color: var(--info);
          border-color: var(--info);
        }
        
        .alert.alert-success {
          background: var(--success-subtle);
          color: var(--success);
          border-color: var(--success);
        }
        
        .alert.alert-warning {
          background: var(--warning-subtle);
          color: var(--warning);
          border-color: var(--warning);
        }
        
        .alert.alert-danger {
          background: var(--error-subtle);
          color: var(--error);
          border-color: var(--error);
        }
        
        .alert-dismissible {
          padding-right: var(--space-10);
        }
        
        .alert-dismissible .btn-close {
          position: absolute;
          right: var(--space-3);
          top: var(--space-3);
          background: none;
          border: none;
          font-size: var(--font-size-lg);
          cursor: pointer;
          color: inherit;
          opacity: 0.7;
          transition: opacity var(--transition-fast);
        }
        
        .alert-dismissible .btn-close:hover {
          opacity: 1;
        }
        CSS
      end
      
      ##
      # Badges para componentes
      #
      def get_badges
        <<-CSS
        /* ============================================
           BADGES
           ============================================ */
        .badge {
          display: inline-block;
          padding: var(--space-1) var(--space-3);
          font-size: var(--font-size-xs);
          font-weight: var(--font-weight-medium);
          line-height: 1;
          text-align: center;
          white-space: nowrap;
          vertical-align: baseline;
          border-radius: var(--radius-full);
        }
        
        .badge-pill {
          border-radius: var(--radius-full);
          padding: var(--space-1) var(--space-3);
        }
        
        .badge-primary {
          background: var(--accent);
          color: white;
        }
        
        .badge-secondary {
          background: var(--bg-tertiary);
          color: var(--text-primary);
        }
        
        .badge-success {
          background: var(--success);
          color: white;
        }
        
        .badge-danger {
          background: var(--error);
          color: white;
        }
        
        .badge-warning {
          background: var(--warning);
          color: var(--text-primary);
        }
        
        .badge-info {
          background: var(--info);
          color: white;
        }
        
        .badge-light {
          background: var(--bg-secondary);
          color: var(--text-primary);
        }
        
        .badge-dark {
          background: var(--text-primary);
          color: white;
        }
        CSS
      end
      
      ##
      # Contenedores de gráficos
      #
      def get_charts
        <<-CSS
        /* ============================================
           CHARTS
           ============================================ */
        .chart-container {
          width: 100%;
          height: 400px;
          position: relative;
          margin-bottom: var(--space-8);
          background: var(--bg-secondary);
          border-radius: var(--radius-lg);
          padding: var(--space-6);
          border: 1px solid var(--border-primary);
        }
        
        .chart-header {
          margin-bottom: var(--space-4);
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .chart-title {
          font-size: var(--font-size-lg);
          font-weight: var(--font-weight-semibold);
          color: var(--text-primary);
        }
        CSS
      end
      
      ##
      # Dialogs y overlays
      #
      def get_dialogs
        <<-CSS
        /* ============================================
           DIALOGS & OVERLAYS
           ============================================ */
        .loading-spinner {
          display: none;
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          background: rgba(0, 0, 0, 0.9);
          color: white;
          padding: var(--space-6) var(--space-8);
          border-radius: var(--radius-lg);
          z-index: var(--z-modal);
          box-shadow: var(--shadow-xl);
          font-size: var(--font-size-lg);
          font-weight: var(--font-weight-semibold);
        }
        
        .overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          z-index: var(--z-overlay);
          backdrop-filter: blur(4px);
        }
        
        .modal {
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          background: var(--bg-primary);
          border-radius: var(--radius-xl);
          padding: var(--space-8);
          max-width: 600px;
          width: 90%;
          z-index: var(--z-modal);
          box-shadow: var(--shadow-xl);
        }
        
        .tooltip {
          position: absolute;
          background: rgba(0, 0, 0, 0.9);
          color: white;
          padding: var(--space-2) var(--space-3);
          border-radius: var(--radius-md);
          font-size: var(--font-size-sm);
          z-index: var(--z-tooltip);
          pointer-events: none;
          white-space: nowrap;
        }
        
        .tooltip-icon {
          display: inline-block;
          cursor: help;
          margin-left: var(--space-1);
          color: var(--text-tertiary);
        }
        CSS
      end
      
      ##
      # Animaciones
      #
      def get_animations
        <<-CSS
        /* ============================================
           ANIMATIONS
           ============================================ */
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes slideIn {
          from {
            transform: translateX(-20px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
        
        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn var(--transition-base);
        }
        
        .animate-slideIn {
          animation: slideIn var(--transition-base);
        }
        
        .animate-spin {
          animation: spin 1s linear infinite;
        }
        CSS
      end
      
      ##
      # Utilidades
      #
      def get_utilities
        <<-CSS
        /* ============================================
           UTILITIES
           ============================================ */
        .hidden { display: none !important; }
        .block { display: block !important; }
        .inline-block { display: inline-block !important; }
        .flex { display: flex !important; }
        .inline-flex { display: inline-flex !important; }
        
        .text-left { text-align: left; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        
        .font-bold { font-weight: var(--font-weight-bold); }
        .font-semibold { font-weight: var(--font-weight-semibold); }
        .font-medium { font-weight: var(--font-weight-medium); }
        
        .text-xs { font-size: var(--font-size-xs); }
        .text-sm { font-size: var(--font-size-sm); }
        .text-base { font-size: var(--font-size-base); }
        .text-lg { font-size: var(--font-size-lg); }
        .text-xl { font-size: var(--font-size-xl); }
        
        .text-primary { color: var(--text-primary); }
        .text-secondary { color: var(--text-secondary); }
        .text-accent { color: var(--accent); }
        .text-error { color: var(--error); }
        .text-success { color: var(--success); }
        
        .w-full { width: 100%; }
        .h-full { height: 100%; }
        
        .mb-0 { margin-bottom: 0 !important; }
        .mb-2 { margin-bottom: var(--space-2); }
        .mb-4 { margin-bottom: var(--space-4); }
        .mb-6 { margin-bottom: var(--space-6); }
        
        .mt-0 { margin-top: 0 !important; }
        .mt-2 { margin-top: var(--space-2); }
        .mt-4 { margin-top: var(--space-4); }
        .mt-6 { margin-top: var(--space-6); }
        
        .p-0 { padding: 0 !important; }
        .p-2 { padding: var(--space-2); }
        .p-4 { padding: var(--space-4); }
        .p-6 { padding: var(--space-6); }
        CSS
      end
      
      ##
      # Estilos específicos para componentes
      #
      def get_components
        <<-CSS
        /* ============================================
           COMPONENTES ESPECÍFICOS
           ============================================ */
        /* License panel */
        .license-status {
          display: flex;
          align-items: center;
          gap: var(--space-2);
        }
        
        .license-info small {
          display: block;
          line-height: 1.4;
        }
        
        /* Form row con gap personalizable */
        .form-row {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: var(--space-3);
        }
        
        /* Mejoras en cards */
        .card .card-header {
          background: transparent;
        }
        
        /* Selectores específicos */
        select.form-select option[style*="background:var(--success)"] {
          background: var(--success) !important;
          color: white !important;
        }
        CSS
      end
      
      ##
      # Estilos relacionados con licencia
      #
      def get_license_styles
        <<-CSS
        /* ============================================
           ESTILOS DE LICENCIA
           ============================================ */
        .license-watermark {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%) rotate(-45deg);
          font-size: 48px;
          color: rgba(255, 0, 0, 0.1);
          pointer-events: none;
          user-select: none;
          font-weight: bold;
          z-index: 1000;
        }
        
        .trial-export {
          position: relative;
          overflow: hidden;
        }
        
        .trial-export::before {
          content: "TRIAL VERSION";
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%) rotate(-45deg);
          font-size: 36px;
          color: rgba(255, 0, 0, 0.15);
          pointer-events: none;
          user-select: none;
          font-weight: bold;
          z-index: 999;
        }
        CSS
      end
      
    end
  end
end
