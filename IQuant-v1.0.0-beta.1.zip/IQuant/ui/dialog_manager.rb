# encoding: UTF-8

module IQuant
  module UI
    module DialogManager
      extend self
      
      ##
      # Muestra el diálogo principal
      #
      def show_dialog
        safe_execute('Mostrar diálogo') do
          model = Sketchup.active_model
          
          # Migrar datos antiguos si es necesario
          IQuant.migrate_old_data if IQuant.respond_to?(:migrate_old_data)
          
          # Inicializar variables si no existen
          IQuant.current_lang ||= detect_language
          IQuant.current_unit ||= detect_unit
          IQuant.base_currency ||= model.get_attribute(IQuant::PREFS_KEY, "base_currency") || 'USD'
          IQuant.display_currency ||= model.get_attribute(IQuant::PREFS_KEY, "display_currency") || IQuant.base_currency
          IQuant.analytics_enabled = model.get_attribute(IQuant::PREFS_KEY, "analytics_enabled", false)
          
          # Crear o reutilizar diálogo
          if IQuant.dialog && IQuant.dialog.visible?
            IQuant.dialog.bring_to_front
            refresh_dialog
            return
          end
          
          # Generar HTML
          html = IQuant::UI::HtmlGenerator.get_html_content
          
          # Configurar diálogo
          dialog = ::UI::HtmlDialog.new(
            dialog_title: IQuant::Data::Localization.t('title'),
            preferences_key: IQuant::PREFS_KEY,
            scrollable: true,
            resizable: true,
            width: 900,
            height: 700,
            left: 100,
            top: 100,
            min_width: 600,
            min_height: 500,
            style: ::UI::HtmlDialog::STYLE_DIALOG
          )
          
          dialog.set_html(html)
          
          # Configurar callbacks
          IQuant::UI::Callbacks.setup_callbacks(dialog)
          
          # Observers para refresh automático
          model.selection.add_observer(SelectionObserver.new(dialog))
          
          # Mostrar y centrar
          dialog.show
          dialog.center
          
          # Guardar referencia
          IQuant.dialog = dialog
          
          # Cargar datos iniciales
          load_initial_data(dialog)
          
          # Iniciar onboarding si es primer uso (con delay para asegurar que el DOM esté listo)
          if is_first_use?
            if defined?(IQuant::Features::Onboarding)
              UI.start_timer(1.5, false) do  # Esperar 1.5 segundos para que el dialog cargue completamente
                begin
                  IQuant::Features::Onboarding.start_tutorial(dialog)
                  IQuant::Utils::Logger.log("Tutorial de onboarding iniciado automáticamente", :info)
                rescue => e
                  IQuant::Utils::Logger.log("Error iniciando tutorial: #{e.message}", :error)
                end
              end
            end
          end
          
          # Cargar preview 3D y 2D si aplicable
          if defined?(IQuant::Features::Preview3D) && IQuant::Features::Preview3D.enabled?
            IQuant::Features::Preview3D.init_viewer(dialog)
          end
          
          # ACTUALIZADO: Inicializar visualizador 2D de materiales
          if defined?(IQuant::Features::MaterialViewer2D) && IQuant::Features::MaterialViewer2D.enabled?
            IQuant::Features::MaterialViewer2D.init_viewer(dialog)
          end
          
          # Verificar licencia
          if defined?(IQuant::Features::Licensing)
            license_status = IQuant::Features::Licensing.check_license_status
            if license_status[:status] == :expired
              IQuant::Features::Licensing.show_activation_dialog(dialog)
            end
          end
          
          # Track apertura si analytics opt-in
          if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
            IQuant::Features::Analytics.track_event('dialog_opened')
          end
          
          IQuant::Utils::Logger.log("Diálogo mostrado correctamente", :info)
        end
      end
      
      ##
      # Refresca el contenido del diálogo
      #
      def refresh_dialog
        return unless IQuant.dialog && IQuant.dialog.visible?
        
        safe_execute('Refrescar diálogo') do
          IQuant.dialog.execute_script("sketchupAction('refresh')")
          
          # ACTUALIZADO: Actualizar visualizador 2D si está disponible
          if defined?(IQuant::Features::MaterialViewer2D) && IQuant::Features::MaterialViewer2D.enabled?
            update_2d_viewer
          end
          
          IQuant::Utils::Logger.log("Diálogo refrescado", :debug)
        end
      end
      
      ##
      # Actualiza el visualizador 2D con la selección actual
      #
      def update_2d_viewer
        return unless IQuant.dialog && IQuant.dialog.visible?
        return unless defined?(IQuant::Features::MaterialViewer2D) && IQuant::Features::MaterialViewer2D.enabled?
        
        safe_execute('Actualizar visualizador 2D') do
          # Obtener datos de la selección actual
          model = Sketchup.active_model
          selection_data = IQuant::Core::Calculator.get_selection_data(model.selection)
          
          # Actualizar el visualizador 2D
          IQuant::Features::MaterialViewer2D.update_viewer(IQuant.dialog, selection_data)
          
          IQuant::Utils::Logger.log("Visualizador 2D actualizado", :debug)
        end
      end
      
      ##
      # Cierra el diálogo
      #
      def close_dialog
        if IQuant.dialog
          IQuant.dialog.close
          IQuant.dialog = nil
          IQuant::Utils::Logger.log("Diálogo cerrado", :info)
        end
      end
      
      ##
      # Verifica si es el primer uso
      #
      # @return [Boolean]
      #
      def is_first_use?
        model = Sketchup.active_model
        !model.get_attribute(IQuant::PREFS_KEY, "has_run_onboarding", false)
      end
      
      ##
      # Carga datos iniciales en el diálogo
      #
      # @param dialog [::UI::HtmlDialog] El diálogo activo
      #
      def load_initial_data(dialog)
        safe_execute('Cargar datos iniciales') do
          # Capas y materiales
          data = IQuant::Core::Calculator.get_layers_and_materials
          json_data = JSON.generate(data).gsub("'", "\\\\'")
          dialog.execute_script("populateSelects(#{json_data})")
          
          # Reglas existentes
          rules = IQuant::Core::CostCalculator.list_rules(IQuant::DICT_COST)
          json_rules = JSON.generate(rules).gsub("'", "\\\\'")
          dialog.execute_script("displayRules(#{json_rules})")
          
          # Configuración del proyecto
          model = Sketchup.active_model
          project = model.get_attribute(IQuant::PREFS_KEY, "project", "").gsub("'", "\\\\'")
          client = model.get_attribute(IQuant::PREFS_KEY, "client", "").gsub("'", "\\\\'")
          company = model.get_attribute(IQuant::PREFS_KEY, "company", "").gsub("'", "\\\\'")
          
          dialog.execute_script("document.getElementById('project-name').value = '#{project}'")
          dialog.execute_script("document.getElementById('client-name').value = '#{client}'")
          dialog.execute_script("document.getElementById('company-name').value = '#{company}'")
          
          # Refrescar reporte
          refresh_dialog
          
          # Configuración de moneda
          dialog.execute_script("sketchupAction('load_currency_config')")
          
          # Cargar info de licencia
          if defined?(IQuant::Features::Licensing)
            license_info = IQuant::Features::Licensing.get_license_info
            json_license = JSON.generate(license_info).gsub("'", "\\\\'")
            dialog.execute_script("updateLicensePanel(#{json_license})")
          end
          
          # ACTUALIZADO: Cargar visualizador 2D si hay selección
          if model.selection && !model.selection.empty?
            if defined?(IQuant::Features::MaterialViewer2D) && IQuant::Features::MaterialViewer2D.enabled?
              selection_data = IQuant::Core::Calculator.get_selection_data(model.selection)
              IQuant::Features::MaterialViewer2D.update_viewer(dialog, selection_data)
            end
          end
          
          IQuant::Utils::Logger.log("Datos iniciales cargados en diálogo", :info)
        end
      end
      
      ##
      # Detecta idioma del sistema
      #
      # @return [String] Código de idioma
      #
      def detect_language
        model = Sketchup.active_model
        saved = model.get_attribute(IQuant::PREFS_KEY, "language")
        
        if saved && IQuant::Data::Localization::LANGUAGES.key?(saved)
          saved
        else
          locale = Sketchup.get_locale.downcase
          IQuant::Data::Localization::LANGUAGES.key?(locale[0..1]) ? locale[0..1] : 'en'
        end
      end
      
      ##
      # Detecta unidad del modelo
      #
      # @return [String] Código de unidad
      #
      def detect_unit
        model = Sketchup.active_model
        saved = model.get_attribute(IQuant::PREFS_KEY, "unit")
        
        if saved && IQuant::UNIT_FACTORS.key?(saved)
          saved
        else
          options = model.options["UnitsOptions"]
          case options["LengthUnit"]
          when 0 then 'in'
          when 1 then 'ft'
          when 2 then 'mm'
          when 3 then 'cm'
          when 4 then 'm'
          else 'm'
          end
        end
      end
      
      ##
      # Observer para selección con debounce
      #
      class SelectionObserver < Sketchup::SelectionObserver
        def initialize(dialog)
          @dialog = dialog
          @timer = nil
          @pending = false
        end
        
        def onSelectionBulkChange(selection)
          return unless @dialog.visible?
          
          @pending = true
          
          if @timer
            UI.stop_timer(@timer)
          end
          
          @timer = UI.start_timer(0.3, false) do
            if @pending
              # Refrescar diálogo principal
              IQuant::UI::DialogManager.refresh_dialog
              
              # ACTUALIZADO: Actualizar visualizador 2D específicamente
              if defined?(IQuant::Features::MaterialViewer2D) && IQuant::Features::MaterialViewer2D.enabled?
                selection_data = IQuant::Core::Calculator.get_selection_data(selection)
                IQuant::Features::MaterialViewer2D.update_viewer(@dialog, selection_data)
              end
              
              @pending = false
            end
            @timer = nil
          end
        end
        
        def onSelectionCleared(selection)
          onSelectionBulkChange(selection)
        end
      end
      
      # Ejecución segura con manejo de errores
      def safe_execute(operation, &block)
        IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
      end
      
    end
  end
end
