# encoding: UTF-8

module IQuant
  module UI
    module Components
      extend self
      
      # ==========================================================================
      # CONSTANTES
      # ==========================================================================
      
      # Estilos CSS predefinidos
      CSS_CLASSES = {
        primary: 'btn-primary',
        secondary: 'btn-secondary',
        success: 'btn-success',
        danger: 'btn-danger',
        warning: 'btn-warning',
        info: 'btn-info',
        light: 'btn-light',
        dark: 'btn-dark'
      }.freeze
      
      # Tamaños de botones
      SIZES = {
        sm: 'btn-sm',
        md: '',
        lg: 'btn-lg'
      }.freeze
      
      # Tipos de alerta
      ALERT_TYPES = {
        info: 'alert-info',
        success: 'alert-success',
        warning: 'alert-warning',
        danger: 'alert-danger'
      }.freeze
      
      # Tipos de badge
      BADGE_TYPES = {
        primary: 'badge-primary',
        secondary: 'badge-secondary',
        success: 'badge-success',
        danger: 'badge-danger',
        warning: 'badge-warning',
        info: 'badge-info',
        light: 'badge-light',
        dark: 'badge-dark'
      }.freeze
      
      # ==========================================================================
      # COMPONENTES DE BOTÓN
      # ==========================================================================
      
      ##
      # Genera un botón HTML
      #
      # @param text [String] Texto del botón
      # @param onclick [String] Función JavaScript onclick
      # @param options [Hash] Opciones adicionales
      #   :type - Tipo de botón (primary, secondary, etc.)
      #   :size - Tamaño (sm, md, lg)
      #   :id - ID del elemento
      #   :class - Clases CSS adicionales
      #   :disabled - Si está deshabilitado
      #   :icon - Clase de icono FontAwesome
      #   :title - Tooltip
      #   :style - Estilos inline
      #   :data - Hash de atributos data-*
      #
      # @return [String] HTML del botón
      #
      def button(text, onclick = nil, options = {})
        type = options[:type] || :primary
        size = options[:size] || :md
        btn_class = options[:class] || ''
        disabled = options[:disabled] ? 'disabled' : ''
        icon = options[:icon] ? "<span class='#{options[:icon]}'></span> " : ''
        title = options[:title] ? "title='#{options[:title]}'" : ''
        style = options[:style] ? "style='#{options[:style]}'" : ''
        id = options[:id] ? "id='#{options[:id]}'" : ''
        
        # Atributos data
        data_attrs = ''
        if options[:data] && options[:data].is_a?(Hash)
          options[:data].each do |key, value|
            data_attrs << " data-#{key}='#{value}'"
          end
        end
        
        css_classes = [
          'btn',
          CSS_CLASSES[type] || CSS_CLASSES[:primary],
          SIZES[size],
          btn_class
        ].join(' ').strip
        
        onclick_attr = onclick ? "onclick=\"#{onclick}\"" : ''
        
        <<-HTML
        <button #{id} class="#{css_classes}" #{onclick_attr} #{disabled} #{title} #{style}#{data_attrs}>
          #{icon}#{text}
        </button>
        HTML
      end
      
      ##
      # Genera un botón de exportación
      #
      # @param type [Symbol] Tipo de exportación (:csv, :pdf, :excel)
      # @param lang [String] Idioma para textos
      # @param disabled [Boolean] Si está deshabilitado
      # @param options [Hash] Opciones adicionales
      #
      # @return [String] HTML del botón de exportación
      #
      def export_button(type, lang = 'en', disabled = false, options = {})
        texts = {
          csv: IQuant::Data::Localization.t('btn_export_csv', lang),
          pdf: IQuant::Data::Localization.t('btn_export_pdf', lang),
          excel: IQuant::Data::Localization.t('btn_export_excel', lang)
        }
        
        icons = {
          csv: '📊',
          pdf: '📄',
          excel: '📈'
        }
        
        classes = {
          csv: 'btn-success',
          pdf: 'btn-secondary',
          excel: 'btn-secondary'
        }
        
        onclick = "sketchupAction('export_#{type}')"
        
        button(
          "#{icons[type]} #{texts[type]}",
          disabled ? nil : onclick,
          options.merge(
            type: :custom,
            class: "#{classes[type]} export-btn #{options[:class]}",
            disabled: disabled,
            title: disabled ? IQuant::Data::Localization.t("requires_#{type}_gem", lang) : nil
          )
        )
      end
      
      ##
      # Genera una tarjeta (card) HTML
      #
      # @param content [String] Contenido de la tarjeta
      # @param options [Hash] Opciones
      #   :title - Título de la tarjeta
      #   :header - HTML personalizado para el encabezado
      #   :footer - HTML personalizado para el pie
      #   :id - ID del elemento
      #   :class - Clases CSS adicionales
      #   :style - Estilos inline
      #   :collapsible - Si es colapsable
      #   :collapsed - Si inicialmente está colapsado
      #
      # @return [String] HTML de la tarjeta
      #
      def card(content, options = {})
        id = options[:id] ? "id='#{options[:id]}'" : ''
        css_class = "card #{options[:class] || ''}".strip
        
        # Encabezado
        header = ''
        if options[:header]
          header = "<div class='card-header'>#{options[:header]}</div>"
        elsif options[:title]
          collapsible_icon = ''
          if options[:collapsible]
            collapsible_id = options[:id] ? "#{options[:id]}-collapse" : "card-#{rand(1000)}"
            collapsed = options[:collapsed] ? 'collapsed' : ''
            collapsible_icon = "<button class='card-collapse-btn' data-bs-toggle='collapse' data-bs-target='##{collapsible_id}' aria-expanded='#{!options[:collapsed]}'>▼</button>"
            css_class += ' collapsible-card'
          end
          header = "<div class='card-header'><h4 class='card-title'>#{options[:title]}</h4>#{collapsible_icon}</div>"
        end
        
        # Pie
        footer = options[:footer] ? "<div class='card-footer'>#{options[:footer]}</div>" : ''
        
        # Contenido
        content_div = "<div class='card-body'>#{content}</div>"
        if options[:collapsible]
          collapsible_id = options[:id] ? "#{options[:id]}-collapse" : "card-#{rand(1000)}"
          collapse_class = options[:collapsed] ? 'collapse' : 'collapse show'
          content_div = "<div class='#{collapse_class}' id='#{collapsible_id}'><div class='card-body'>#{content}</div></div>"
        end
        
        style = options[:style] ? "style='#{options[:style]}'" : ''
        
        <<-HTML
        <div #{id} class="#{css_class}" #{style}>
          #{header}
          #{content_div}
          #{footer}
        </div>
        HTML
      end
      
      ##
      # Genera un selector de idioma
      #
      # @param current_lang [String] Idioma actual
      # @param options [Hash] Opciones
      #   :id - ID del elemento
      #   :class - Clases CSS adicionales
      #   :onchange - Función JavaScript onchange
      #
      # @return [String] HTML del selector
      #
      def language_selector(current_lang = 'en', options = {})
        id = options[:id] || 'language-selector'
        css_class = "form-select #{options[:class] || ''}".strip
        onchange = options[:onchange] || "changeLanguage(this.value)"
        
        options_html = ''
        IQuant::Data::Localization::LANGUAGES.each do |code, data|
          selected = current_lang == code ? 'selected' : ''
          options_html << "<option value='#{code}' #{selected}>#{data[:flag]} #{data[:name]}</option>\n"
        end
        
        <<-HTML
        <select id="#{id}" class="#{css_class}" onchange="#{onchange}">
          #{options_html}
        </select>
        HTML
      end
      
      ##
      # Genera un selector de unidades
      #
      # @param current_unit [String] Unidad actual
      # @param lang [String] Idioma para textos
      # @param options [Hash] Opciones
      #   :id - ID del elemento
      #   :class - Clases CSS adicionales
      #   :onchange - Función JavaScript onchange
      #
      # @return [String] HTML del selector
      #
      def unit_selector(current_unit = 'm', lang = 'en', options = {})
        id = options[:id] || 'unit-selector'
        css_class = "form-select #{options[:class] || ''}".strip
        onchange = options[:onchange] || "changeUnit(this.value)"
        
        units = {
          'm' => IQuant::Data::Localization.t('meters', lang),
          'cm' => IQuant::Data::Localization.t('centimeters', lang),
          'mm' => IQuant::Data::Localization.t('millimeters', lang),
          'in' => IQuant::Data::Localization.t('inches', lang),
          'ft' => IQuant::Data::Localization.t('feet', lang)
        }
        
        options_html = ''
        units.each do |code, name|
          selected = current_unit == code ? 'selected' : ''
          options_html << "<option value='#{code}' #{selected}>#{name} (#{code})</option>\n"
        end
        
        <<-HTML
        <select id="#{id}" class="#{css_class}" onchange="#{onchange}">
          #{options_html}
        </select>
        HTML
      end
      
      ##
      # Genera un selector de moneda
      #
      # @param display_currency [String] Moneda actual para mostrar
      # @param base_currency [String] Moneda base
      # @param lang [String] Idioma para textos
      # @param options [Hash] Opciones
      #   :id - ID del elemento
      #   :class - Clases CSS adicionales
      #   :onchange - Función JavaScript onchange
      #   :include_base_option - Si incluir opción especial para moneda base
      #
      # @return [String] HTML del selector
      #
      def currency_selector(display_currency = 'USD', base_currency = 'USD', lang = 'en', options = {})
        id = options[:id] || 'currency-selector'
        css_class = "form-select #{options[:class] || ''}".strip
        onchange = options[:onchange] || "changeCurrency(this.value)"
        include_base = options.fetch(:include_base_option, true)
        
        options_html = ''
        
        if include_base
          selected = display_currency == base_currency ? 'selected' : ''
          options_html << "<option value='#{base_currency}' #{selected} style='background:var(--success); color:white; font-weight:600;'>#{base_currency} (#{IQuant::Data::Localization.t('base', lang)})</option>\n"
        end
        
        # Monedas comunes
        common_currencies = %w[USD EUR GBP JPY CNY]
        common_currencies.each do |code|
          next if code == base_currency && include_base
          selected = display_currency == code ? 'selected' : ''
          options_html << "<option value='#{code}' #{selected}>#{code}</option>\n"
        end
        
        <<-HTML
        <select id="#{id}" class="#{css_class}" onchange="#{onchange}">
          #{options_html}
        </select>
        HTML
      end
      
      ##
      # Genera un badge
      #
      # @param text [String] Texto del badge
      # @param type [Symbol] Tipo de badge (primary, success, etc.)
      # @param options [Hash] Opciones
      #   :id - ID del elemento
      #   :class - Clases CSS adicionales
      #   :style - Estilos inline
      #   :pill - Si tiene forma de píldora
      #
      # @return [String] HTML del badge
      #
      def badge(text, type = :primary, options = {})
        id = options[:id] ? "id='#{options[:id]}'" : ''
        css_class = "badge #{BADGE_TYPES[type] || BADGE_TYPES[:primary]} #{options[:class] || ''}".strip
        css_class += ' badge-pill' if options[:pill]
        style = options[:style] ? "style='#{options[:style]}'" : ''
        
        <<-HTML
        <span #{id} class="#{css_class}" #{style}>#{text}</span>
        HTML
      end
      
      ##
      # Genera un mensaje de alerta
      #
      # @param message [String] Mensaje de alerta
      # @param type [Symbol] Tipo de alerta (info, success, warning, danger)
      # @param options [Hash] Opciones
      #   :id - ID del elemento
      #   :class - Clases CSS adicionales
      #   :style - Estilos inline
      #   :icon - Icono personalizado
      #   :dismissible - Si se puede cerrar
      #
      # @return [String] HTML de la alerta
      #
      def alert_message(message, type = :info, options = {})
        id = options[:id] ? "id='#{options[:id]}'" : ''
        css_class = "alert #{ALERT_TYPES[type] || ALERT_TYPES[:info]} #{options[:class] || ''}".strip
        style = options[:style] ? "style='#{options[:style]}'" : ''
        
        # Icono por defecto según tipo
        default_icons = {
          info: 'ℹ️',
          success: '✅',
          warning: '⚠️',
          danger: '❌'
        }
        icon = options[:icon] || default_icons[type] || default_icons[:info]
        
        # Botón para cerrar si es descartable
        dismiss_btn = ''
        if options[:dismissible]
          dismiss_btn = "<button type='button' class='btn-close' onclick=\"this.parentElement.style.display='none';\"></button>"
          css_class += ' alert-dismissible'
        end
        
        <<-HTML
        <div #{id} class="#{css_class}" role="alert" #{style}>
          <span class="alert-icon" style="font-size:20px;">#{icon}</span>
          <div class="alert-content">#{message}</div>
          #{dismiss_btn}
        </div>
        HTML
      end
      
      ##
      # Genera un input con etiqueta
      #
      # @param label [String] Texto de la etiqueta
      # @param options [Hash] Opciones del input
      #   :type - Tipo de input (text, number, email, password, etc.)
      #   :id - ID del input
      #   :name - Nombre del input
      #   :value - Valor por defecto
      #   :placeholder - Placeholder
      #   :required - Si es requerido
      #   :disabled - Si está deshabilitado
      #   :readonly - Si es de solo lectura
      #   :min - Valor mínimo (para number)
      #   :max - Valor máximo (para number)
      #   :step - Paso (para number)
      #   :class - Clases CSS adicionales
      #   :style - Estilos inline
      #   :help - Texto de ayuda
      #   :error - Mensaje de error
      #
      # @return [String] HTML del input etiquetado
      #
      def labeled_input(label, options = {})
        input_id = options[:id] || "input-#{rand(10000)}"
        input_type = options[:type] || 'text'
        input_class = "form-control #{options[:class] || ''}".strip
        input_style = options[:style] ? "style='#{options[:style]}'" : ''
        
        # Atributos comunes
        attrs = []
        attrs << "id='#{input_id}'"
        attrs << "name='#{options[:name]}'" if options[:name]
        attrs << "type='#{input_type}'"
        attrs << "value='#{options[:value]}'" if options[:value]
        attrs << "placeholder='#{options[:placeholder]}'" if options[:placeholder]
        attrs << 'required' if options[:required]
        attrs << 'disabled' if options[:disabled]
        attrs << 'readonly' if options[:readonly]
        attrs << "min='#{options[:min]}'" if options[:min]
        attrs << "max='#{options[:max]}'" if options[:max]
        attrs << "step='#{options[:step]}'" if options[:step]
        attrs << "class='#{input_class}'"
        attrs << input_style
        
        # Texto de ayuda
        help_text = options[:help] ? "<small class='form-text'>#{options[:help]}</small>" : ''
        
        # Mensaje de error
        error_text = options[:error] ? "<div class='invalid-feedback'>#{options[:error]}</div>" : ''
        
        # Clase extra para el grupo si hay error
        group_class = 'form-group'
        group_class += ' has-error' if options[:error]
        
        <<-HTML
        <div class="#{group_class}">
          <label for="#{input_id}">#{label}</label>
          <input #{attrs.join(' ')}>
          #{help_text}
          #{error_text}
        </div>
        HTML
      end
      
      ##
      # Genera botones de pestañas (tabs)
      #
      # @param tabs [Array<Hash>] Array de pestañas con :id, :text, :active
      # @param options [Hash] Opciones
      #   :id - ID del contenedor
      #   :class - Clases CSS adicionales
      #   :style - Estilos inline
      #   :onclick_prefix - Prefijo para la función onclick
      #
      # @return [String] HTML de los botones de pestañas
      #
      def tab_buttons(tabs, options = {})
        container_id = options[:id] ? "id='#{options[:id]}'" : ''
        container_class = "tabs #{options[:class] || ''}".strip
        container_style = options[:style] ? "style='#{options[:style]}'" : ''
        onclick_prefix = options[:onclick_prefix] || 'switchTab'
        
        tabs_html = ''
        tabs.each do |tab|
          active_class = tab[:active] ? 'active' : ''
          onclick = "#{onclick_prefix}('#{tab[:id]}')"
          tabs_html << "<div class='tab #{active_class}' onclick=\"#{onclick}\">#{tab[:text]}</div>\n"
        end
        
        <<-HTML
        <div #{container_id} class="#{container_class}" #{container_style}>
          #{tabs_html}
        </div>
        HTML
      end
      
      ##
      # Genera un contenedor de contenido de pestaña
      #
      # @param tab_id [String] ID de la pestaña
      # @param content [String] Contenido HTML
      # @param options [Hash] Opciones
      #   :active - Si la pestaña está activa
      #   :class - Clases CSS adicionales
      #   :style - Estilos inline
      #
      # @return [String] HTML del contenido de pestaña
      #
      def tab_content(tab_id, content, options = {})
        active_class = options[:active] ? 'active' : ''
        css_class = "tab-content #{options[:class] || ''} #{active_class}".strip
        style = options[:style] ? "style='#{options[:style]}'" : ''
        
        <<-HTML
        <div id="tab-#{tab_id}" class="#{css_class}" #{style}>
          #{content}
        </div>
        HTML
      end
      
      ##
      # Genera un grupo de formulario en fila
      #
      # @param inputs [Array<String>] HTML de los inputs
      # @param options [Hash] Opciones
      #   :class - Clases CSS adicionales
      #   :style - Estilos inline
      #   :gap - Espacio entre inputs (ej: 'var(--space-3)')
      #
      # @return [String] HTML del grupo en fila
      #
      def form_row(inputs, options = {})
        css_class = "form-row #{options[:class] || ''}".strip
        style = options[:style] || "gap: #{options[:gap] || 'var(--space-3)'};"
        
        <<-HTML
        <div class="#{css_class}" style="#{style}">
          #{inputs.join("\n")}
        </div>
        HTML
      end
      
      ##
      # Genera un selector (dropdown)
      #
      # @param label [String] Etiqueta
      # @param options_list [Array<Hash>] Opciones con :value, :text, :selected
      # @param select_options [Hash] Opciones del select
      #   :id - ID del select
      #   :name - Nombre del select
      #   :class - Clases CSS adicionales
      #   :onchange - Función onchange
      #   :disabled - Si está deshabilitado
      #   :multiple - Si es múltiple
      #   :size - Tamaño (número de opciones visibles)
      #   :help - Texto de ayuda
      #   :error - Mensaje de error
      #
      # @return [String] HTML del selector
      #
      def select_input(label, options_list, select_options = {})
        select_id = select_options[:id] || "select-#{rand(10000)}"
        select_class = "form-select #{select_options[:class] || ''}".strip
        
        # Atributos del select
        attrs = []
        attrs << "id='#{select_id}'"
        attrs << "name='#{select_options[:name]}'" if select_options[:name]
        attrs << "class='#{select_class}'"
        attrs << "onchange='#{select_options[:onchange]}'" if select_options[:onchange]
        attrs << 'disabled' if select_options[:disabled]
        attrs << 'multiple' if select_options[:multiple]
        attrs << "size='#{select_options[:size]}'" if select_options[:size]
        
        # Opciones
        options_html = ''
        options_list.each do |option|
          selected = option[:selected] ? 'selected' : ''
          disabled = option[:disabled] ? 'disabled' : ''
          value = option[:value] ? "value='#{option[:value]}'" : ''
          options_html << "<option #{value} #{selected} #{disabled}>#{option[:text]}</option>\n"
        end
        
        # Texto de ayuda
        help_text = select_options[:help] ? "<small class='form-text'>#{select_options[:help]}</small>" : ''
        
        # Mensaje de error
        error_text = select_options[:error] ? "<div class='invalid-feedback'>#{select_options[:error]}</div>" : ''
        
        # Clase extra para el grupo si hay error
        group_class = 'form-group'
        group_class += ' has-error' if select_options[:error]
        
        <<-HTML
        <div class="#{group_class}">
          <label for="#{select_id}">#{label}</label>
          <select #{attrs.join(' ')}>
            #{options_html}
          </select>
          #{help_text}
          #{error_text}
        </div>
        HTML
      end
      
      ##
      # Genera un grupo de radio buttons
      #
      # @param label [String] Etiqueta del grupo
      # @param name [String] Nombre del grupo (atributo name)
      # @param options_list [Array<Hash>] Opciones con :value, :text, :checked
      # @param radio_options [Hash] Opciones del grupo
      #   :id - ID del contenedor
      #   :class - Clases CSS adicionales
      #   :style - Estilos inline
      #   :vertical - Si se muestran verticalmente (por defecto false)
      #   :help - Texto de ayuda
      #
      # @return [String] HTML del grupo de radios
      #
      def radio_group(label, name, options_list, radio_options = {})
        container_id = radio_options[:id] ? "id='#{radio_options[:id]}'" : ''
        container_class = "radio-group #{radio_options[:class] || ''}".strip
        container_style = radio_options[:style] ? "style='#{radio_options[:style]}'" : ''
        
        direction_class = radio_options[:vertical] ? 'radio-group-vertical' : 'radio-group-horizontal'
        
        radios_html = ''
        options_list.each do |option|
          checked = option[:checked] ? 'checked' : ''
          radio_id = "radio-#{name}-#{option[:value]}-#{rand(1000)}"
          
          radios_html << <<-HTML
          <div class="radio-option">
            <input type="radio" id="#{radio_id}" name="#{name}" value="#{option[:value]}" #{checked}>
            <label for="#{radio_id}">#{option[:text]}</label>
          </div>
          HTML
        end
        
        # Texto de ayuda
        help_text = radio_options[:help] ? "<small class='form-text'>#{radio_options[:help]}</small>" : ''
        
        <<-HTML
        <div #{container_id} class="form-group #{container_class}">
          <label>#{label}</label>
          <div class="#{direction_class}" #{container_style}>
            #{radios_html}
          </div>
          #{help_text}
        </div>
        HTML
      end
      
      ##
      # Genera un icono de tooltip
      #
      # @param text [String] Texto del tooltip
      # @param options [Hash] Opciones
      #   :position - Posición (top, bottom, left, right)
      #   :class - Clases CSS adicionales
      #   :icon - Icono personalizado (por defecto 'ⓘ')
      #
      # @return [String] HTML del tooltip
      #
      def tooltip(text, options = {})
        position = options[:position] || 'top'
        css_class = "tooltip-icon #{options[:class] || ''}".strip
        icon = options[:icon] || 'ⓘ'
        
        <<-HTML
        <span class="#{css_class}" data-tooltip-position="#{position}" title="#{text}">#{icon}</span>
        HTML
      end
      
      ##
      # Genera un panel de información de licencia
      #
      # @param license_info [Hash] Información de la licencia
      #   :status - Estado (:trial, :licensed, :expired)
      #   :days_left - Días restantes de prueba
      #   :exports_left - Exportaciones restantes
      #   :key - Clave de licencia (parcial)
      #   :expires - Fecha de expiración
      # @param lang [String] Idioma
      # @param options [Hash] Opciones
      #
      # @return [String] HTML del panel de licencia
      #
      def license_panel(license_info, lang = 'en', options = {})
        status = license_info[:status] || :trial
        
        # Determinar color y texto según estado
        case status
        when :trial
          status_text = IQuant::Data::Localization.t('trial_version', lang)
          status_color = 'var(--warning)'
          days_left = license_info[:days_left] || IQuant::TRIAL_DAYS
          exports_left = license_info[:exports_left] || IQuant::TRIAL_EXPORTS
          info_text = "#{IQuant::Data::Localization.t('days_left', lang)}: #{days_left} | #{IQuant::Data::Localization.t('exports_left', lang)}: #{exports_left}"
          
        when :licensed
          status_text = IQuant::Data::Localization.t('licensed', lang)
          status_color = 'var(--success)'
          expires = license_info[:expires] ? " | #{IQuant::Data::Localization.t('expires', lang)}: #{license_info[:expires]}" : ''
          info_text = "#{IQuant::Data::Localization.t('license_key', lang)}: #{license_info[:key]}#{expires}"
          
        when :expired
          status_text = IQuant::Data::Localization.t('license_expired', lang)
          status_color = 'var(--danger)'
          info_text = IQuant::Data::Localization.t('please_renew', lang)
          
        else
          status_text = IQuant::Data::Localization.t('unknown', lang)
          status_color = 'var(--secondary)'
          info_text = ''
        end
        
        content = <<-HTML
        <div class="license-status" style="margin-bottom: var(--space-3);">
          <strong>#{IQuant::Data::Localization.t('status', lang)}:</strong>
          <span class="badge" style="background:#{status_color}; color:white;">#{status_text}</span>
        </div>
        <div class="license-info">
          <small>#{info_text}</small>
        </div>
        HTML
        
        # Botón para activar licencia si está en trial
        if status == :trial
          content += <<-HTML
          <div class="form-row" style="margin-top: var(--space-4);">
            #{labeled_input(IQuant::Data::Localization.t('license_key', lang), type: 'text', id: 'license-key-input', placeholder: 'XXXX-XXXX-XXXX-XXXX')}
          </div>
          <button onclick="sketchupAction('activate_license', document.getElementById('license-key-input').value)" class="btn-success" style="width:100%;">
            🔑 #{IQuant::Data::Localization.t('activate_license', lang)}
          </button>
          HTML
        end
        
        card(content, options.merge(title: '🔒 ' + IQuant::Data::Localization.t('license_info', lang)))
      end
      
    end
  end
end
