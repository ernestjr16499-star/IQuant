# encoding: UTF-8

module IQuant
  module UI
    module Callbacks
      extend self

      ##
      # Configura todos los callbacks del diálogo
      #
      # @param dialog [UI::HtmlDialog] El diálogo activo
      #
      def setup_callbacks(dialog)
        safe_execute('Configurar callbacks') do
          IQuant::Utils::Logger.log("Configurando callbacks Ruby-JS", :info)

          # ============================================
          # CALLBACKS BÁSICOS DE CONFIGURACIÓN
          # ============================================

          # Cambio de idioma
          dialog.add_action_callback("change_language") do |action_context, lang|
            safe_execute('Cambiar idioma') do
              IQuant.current_lang = lang
              model = Sketchup.active_model
              model.set_attribute(IQuant::PREFS_KEY, "language", lang)
              refresh_dialog
              IQuant::Utils::Logger.log("Idioma cambiado a: #{lang}", :info)
              
              # Analytics solo si está disponible
              if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                IQuant::Features::Analytics.track_event('language_changed', { lang: lang })
              end
            end
          end

          # Cambio de unidad
          dialog.add_action_callback("change_unit") do |action_context, unit|
            safe_execute('Cambiar unidad') do
              if IQuant::UNIT_FACTORS.key?(unit)
                IQuant.current_unit = unit
                model = Sketchup.active_model
                model.set_attribute(IQuant::PREFS_KEY, "unit", unit)
                refresh_dialog
                IQuant::Utils::Logger.log("Unidad cambiada a: #{unit}", :info)
                
                # Analytics solo si está disponible
                if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                  IQuant::Features::Analytics.track_event('unit_changed', { unit: unit })
                end
              else
                IQuant::Utils::Logger.log("Unidad inválida: #{unit}", :warn)
                dialog.execute_script("showMessage('general-message', 'Unidad inválida', 'error')")
              end
            end
          end

          # Cambio de moneda de visualización
          dialog.add_action_callback("change_display_currency") do |action_context, currency|
            safe_execute('Cambiar moneda display') do
              if ['USD', 'EUR'].include?(currency) || currency == IQuant.base_currency
                IQuant.display_currency = currency
                model = Sketchup.active_model
                model.set_attribute(IQuant::PREFS_KEY, "display_currency", currency)
                refresh_dialog
                IQuant::Utils::Logger.log("Moneda display cambiada a: #{currency}", :info)
                
                # Analytics solo si está disponible
                if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                  IQuant::Features::Analytics.track_event('display_currency_changed', { currency: currency })
                end
              else
                IQuant::Utils::Logger.log("Moneda display inválida: #{currency}", :warn)
                dialog.execute_script("showMessage('currency-message', 'Moneda inválida', 'error')")
              end
            end
          end

          # ============================================
          # CALLBACKS DE TASAS DE CAMBIO
          # ============================================

          # Guardar tasas de cambio
          dialog.add_action_callback("save_rates") do |action_context, params_string|
            safe_execute('Guardar tasas') do
              parts = params_string.to_s.split('@')
              usd_rate = URI.decode_www_form_component(parts[0] || '1').to_f
              eur_rate = URI.decode_www_form_component(parts[1] || '1').to_f

              if IQuant::Utils::Validator.valid_rate?(usd_rate) && IQuant::Utils::Validator.valid_rate?(eur_rate)
                IQuant::Core::CurrencyConverter.set_exchange_rates(usd_rate, eur_rate)
                dialog.execute_script("showMessage('currency-message', 'Tipos de cambio guardados', 'success')")
                dialog.execute_script("exchangeRates = {USD: #{usd_rate}, EUR: #{eur_rate}}")
                refresh_dialog
                IQuant::Utils::Logger.log("Tasas guardadas: USD=#{usd_rate}, EUR=#{eur_rate}", :info)
                
                # Analytics solo si está disponible
                if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                  IQuant::Features::Analytics.track_event('exchange_rates_saved', {
                    usd_rate: usd_rate,
                    eur_rate: eur_rate
                  })
                end
              else
                IQuant::Utils::Logger.log("Tasas inválidas: USD=#{usd_rate}, EUR=#{eur_rate}", :warn)
                dialog.execute_script("showMessage('currency-message', 'Valores inválidos', 'error')")
              end
            end
          end

          # ============================================
          # CALLBACKS DE CONFIGURACIÓN DEL PROYECTO
          # ============================================

          # Guardar configuración del proyecto
          dialog.add_action_callback("save_settings") do |action_context, params_string|
            safe_execute('Guardar settings') do
              parts = params_string.to_s.split('@')
              project = URI.decode_www_form_component(parts[0] || '')
              client = URI.decode_www_form_component(parts[1] || '')
              company = URI.decode_www_form_component(parts[2] || '')

              model = Sketchup.active_model
              model.set_attribute(IQuant::PREFS_KEY, "project", project)
              model.set_attribute(IQuant::PREFS_KEY, "client", client)
              model.set_attribute(IQuant::PREFS_KEY, "company", company)

              dialog.execute_script("showMessage('settings-message', 'Configuración guardada correctamente', 'success')")
              IQuant::Utils::Logger.log("Settings guardados: project=#{project}, client=#{client}, company=#{company}", :info)

              # Analytics solo si está disponible
              if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                IQuant::Features::Analytics.track_event('settings_saved', {
                  has_project: !project.empty?,
                  has_client: !client.empty?,
                  has_company: !company.empty?
                })
              end
            end
          end

          # ============================================
          # CALLBACKS DE REGLAS DE COSTOS
          # ============================================

          # Guardar regla de costos
          dialog.add_action_callback("save_rule") do |action_context, params_string|
            safe_execute('Guardar regla') do
              parts = params_string.to_s.split('@')
              target = parts[0]
              dict = parts[1]
              type = parts[2]
              value = parts[3].to_f
              extra = JSON.parse(parts[4] || '{}') rescue {}

              if IQuant::Utils::Validator.valid_rule?(target, type, value, extra)
                IQuant::Core::CostCalculator.save_rule(target, dict, type, value, extra)
                dialog.execute_script("showMessage('rule-message', 'Regla guardada correctamente', 'success')")
                dialog.execute_script("sketchupAction('list_rules')")
                refresh_dialog
                IQuant::Utils::Logger.log("Regla guardada para #{target}: type=#{type}, value=#{value}", :info)

                # Analytics solo si está disponible
                if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                  IQuant::Features::Analytics.track_event('rule_saved', {
                    target: target,
                    rule_type: type,
                    dict: dict
                  })
                end
              else
                IQuant::Utils::Logger.log("Regla inválida para #{target}", :warn)
                dialog.execute_script("showMessage('rule-message', 'Datos inválidos en la regla', 'error')")
              end
            end
          end

          # Importar reglas desde archivo
          dialog.add_action_callback("import_rules") do |action_context|
            safe_execute('Importar reglas') do
              file = UI.openpanel("Importar Reglas", "", "JSON Files|*.json||")
              if file && IQuant::Core::CostCalculator.import_rules(IQuant::DICT_COST, file)
                dialog.execute_script("showMessage('rule-message', 'Reglas importadas correctamente', 'success')")
                dialog.execute_script("sketchupAction('list_rules')")
                refresh_dialog
                IQuant::Utils::Logger.log("Reglas importadas desde: #{file}", :info)

                # Analytics solo si está disponible
                if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                  IQuant::Features::Analytics.track_event('rules_imported', { file_size: File.size(file) })
                end
              end
            end
          end

          # ============================================
          # CALLBACKS DE REPORTES Y CÁLCULOS
          # ============================================

          # Refrescar reporte
          dialog.add_action_callback("refresh") do |action_context|
            safe_execute('Refrescar reporte') do
              sel = Sketchup.active_model.selection
              stats = IQuant::Core::Calculator.get_selection_stats(sel)
              json_stats = JSON.generate(stats).gsub("'", "\\\\'")
              dialog.execute_script("updateReport(#{json_stats})")
              IQuant::Utils::Logger.log("Reporte refrescado: #{stats[:count]} items", :debug)

              # Analytics solo si está disponible
              if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                IQuant::Features::Analytics.track_event('report_refreshed', {
                  item_count: stats[:count],
                  has_cost: stats[:total_cost] > 0
                })
              end
            end
          end

          # Detectar espesor de muro
          dialog.add_action_callback("detect_wall_thickness") do |action_context|
            safe_execute('Detectar espesor de muro') do
              sel = Sketchup.active_model.selection
              result = IQuant::Core::GeometryAnalyzer.analyze_wall_thickness(sel)
              json_result = JSON.generate(result).gsub("'", "\\\\'")
              dialog.execute_script("showWallThicknessResult(#{json_result})")
              IQuant::Utils::Logger.log("Detección de espesor: #{result[:success] ? 'Éxito' : 'Error'}", :info)

              # Analytics solo si está disponible
              if IQuant.analytics_enabled && defined?(IQuant::Features::Analytics)
                IQuant::Features::Analytics.track_event('wall_thickness_detected', {
                  success: result[:success],
                  thickness: result[:thickness]
                })
              end
            end
          end

          # ============================================
          # CALLBACKS DE ANALYTICS
          # ============================================

          # Obtener estadísticas de analytics
          dialog.add_action_callback("get_analytics_stats") do |action_context|
            safe_execute('Obtener estadísticas analytics') do
              stats = if defined?(IQuant::Features::Analytics)
                IQuant::Features::Analytics.get_analytics_status
              else
                { enabled: false, pending_events: 0, session_id: nil, version: '0.0' }
              end
              
              json_stats = JSON.generate(stats).gsub("'", "\\\\'")
              dialog.execute_script("updateAnalyticsStats(#{json_stats})")
            end
          end

          # Enviar eventos pendientes de analytics
          dialog.add_action_callback("flush_analytics") do |action_context|
            safe_execute('Enviar eventos analytics pendientes') do
              if defined?(IQuant::Features::Analytics)
                IQuant::Features::Analytics.flush_events
                dialog.execute_script("showMessage('analytics-message', 'Eventos enviados al servidor', 'success')")
              else
                dialog.execute_script("showMessage('analytics-message', 'Módulo de analytics no disponible', 'warning')")
              end
            end
          end

          IQuant::Utils::Logger.log("Todos los callbacks configurados", :success)
        end
      end

      # ============================================
      # MÉTODOS AUXILIARES
      # ============================================

      # Ejecución segura con manejo de errores
      def safe_execute(operation, &block)
        IQuant::Utils::ErrorHandler.safe_execute(operation, &block)
      end

      # Refrescar el diálogo
      def refresh_dialog
        if IQuant.dialog && IQuant.dialog.visible?
          IQuant::UI::DialogManager.refresh_dialog
        else
          IQuant::Utils::Logger.log("Dialog not available for refresh", :warn) if defined?(IQuant::Utils::Logger)
        end
      end
    end
  end
end
