# encoding: UTF-8

# =============================================================================
# IQuant - Plugin de Cuantificación para SketchUp
# =============================================================================

require 'sketchup.rb'
require 'extensions.rb'

# Evitar cargar múltiples veces
unless file_loaded?(__FILE__)

  # ========================================================================
  # PASO 1: Definir rutas y namespace
  # ========================================================================
  
  module IQuant
    # Directorio principal del plugin
    PLUGIN_DIR = File.dirname(__FILE__).freeze
    PLUGIN_MAIN_DIR = File.join(PLUGIN_DIR, 'IQuant').freeze
    
    # Información del plugin
    PLUGIN_NAME = 'IQuant'.freeze
    PLUGIN_VERSION = '1.0.0-beta.1'.freeze
    PLUGIN_AUTHOR = 'IQuant Team'.freeze
    PLUGIN_DESC = 'Herramientas profesionales de cuantificación para construcción'.freeze
  end # module IQuant

  # ========================================================================
  # VARIABLES DE MÓDULO (attr_accessor debe estar AQUÍ, no en config.rb)
  # ========================================================================
  
  class << IQuant
    attr_accessor :current_lang, :current_unit, :dialog,
                  :base_currency, :display_currency, 
                  :analytics_enabled, :auto_refresh_enabled,
                  :license_status, :trial_start_date, 
                  :export_count, :license_key
  end

  # ========================================================================
  # PASO 2: Cargar archivos esenciales
  # ========================================================================
  
  # Función auxiliar para carga segura
  def safe_require(file, base_dir)
    path = File.join(base_dir, file)
    require path
    true
  rescue LoadError => e
    puts "⚠️ No se pudo cargar: #{file}"
    puts "   Error: #{e.message}"
    false
  rescue => e
    puts "❌ Error al cargar #{file}:"
    puts "   #{e.message}"
    puts "   #{e.backtrace.first(3).join("\n   ")}"
    false
  end

  # Orden de carga de archivos
  LOAD_ORDER = [
    'config.rb',
    'utils/logger.rb',
    'utils/error_handler.rb',
    'utils/validator.rb',
    'utils/file_manager.rb',
    'utils/config_manager.rb',
    'data/currencies.rb',
    'data/dosages.rb',
    'data/localization.rb',
    'data/standard_terms.rb',
    'core/unit_converter.rb',
    'core/currency_converter.rb',
    'core/geometry_helper.rb',
    'core/geometry_analyzer.rb',
    'core/calculator.rb',
    'core/cost_calculator.rb',
    'ui/theme.rb',
    'ui/components.rb',
    'ui/html_generator.rb',
    'ui/callbacks.rb',
    'ui/dialog_manager.rb',
    'features/analytics.rb',
    'features/licensing.rb',
    'features/onboarding.rb',
    'features/preview_3d.rb',
    'features/material_viewer_2d.rb',
    'exporters/csv_exporter.rb',
    'exporters/excel_exporter.rb',
    'exporters/pdf_exporter.rb',
    'exporters/obj_exporter.rb',
    'main.rb'
  ].freeze

  # ========================================================================
  # PASO 3: Cargar módulos
  # ========================================================================
#   
#   puts "\n" + "="*60
#   puts "🚀 Cargando IQuant v#{IQuant::PLUGIN_VERSION}..."
#   puts "="*60
  
  loaded_count = 0
  failed_count = 0
  
  LOAD_ORDER.each do |file|
    if safe_require(file, IQuant::PLUGIN_MAIN_DIR)
      loaded_count += 1
    else
      failed_count += 1
    end
  end
  
  puts "\n📊 Resumen de carga:"
  puts "   ✅ Archivos cargados: #{loaded_count}"
  puts "   ❌ Archivos fallidos: #{failed_count}" if failed_count > 0
  puts "="*60 + "\n"

  # Mostrar mensaje de bienvenida (ahora que config.rb ya se cargó)
  puts "\n" + "="*60
  puts "🚀 IQuant v#{IQuant::PLUGIN_VERSION} cargado correctamente"
  puts "="*60 + "\n"

  # ========================================================================
  # PASO 4: Registrar extensión en SketchUp
  # ========================================================================
  
  extension = SketchupExtension.new(
    IQuant::PLUGIN_NAME,
    File.join(IQuant::PLUGIN_MAIN_DIR, 'main.rb')
  )
  
  extension.description = IQuant::PLUGIN_DESC
  extension.version     = IQuant::PLUGIN_VERSION
  extension.creator     = IQuant::PLUGIN_AUTHOR
  extension.copyright   = "© 2024 #{IQuant::PLUGIN_AUTHOR}"
  
  Sketchup.register_extension(extension, true)

  # ========================================================================
  # PASO 5: Inicializar plugin (CREAR MENÚ)
  # ========================================================================
  
  file_loaded(__FILE__)
end # unless file_loaded?
